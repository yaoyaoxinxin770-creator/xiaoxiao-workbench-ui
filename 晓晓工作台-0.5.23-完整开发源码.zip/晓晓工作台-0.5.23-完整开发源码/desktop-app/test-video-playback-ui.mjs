import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';

const require = createRequire(import.meta.url);
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'xiaoxiao-video-playback-ui-'));
const env = { ...process.env, DREAMINA_UI_TEST_ROOT: temp, WORKBENCH_PROFILE_DIR: temp };
delete env.ELECTRON_RUN_AS_NODE;

try {
  const r = spawnSync(require('electron'), ['--disable-gpu', path.join(import.meta.dirname, 'video-playback-ui-check.cjs')], {
    env,
    encoding: 'utf8',
    timeout: 120000,
    windowsHide: true,
  });
  process.stdout.write(r.stdout || '');
  process.stderr.write(r.stderr || '');
  if (r.error) throw r.error;
  assert.equal(r.status, 0);
  assert.match(r.stdout, /视频播放恢复验证：.*PASS/);
} finally {
  assert.ok(path.resolve(temp).startsWith(path.resolve(os.tmpdir()) + path.sep) && path.basename(temp).startsWith('xiaoxiao-video-playback-ui-'));
  fs.rmSync(temp, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 });
}
