const path=require('node:path'),fs=require('node:fs/promises'),{createHash,randomUUID}=require('node:crypto');
const uuid=value=>typeof value==='string'&&/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(value);
const digest=value=>createHash('sha256').update(value).digest('hex');
const referenceName=value=>String(value||'').normalize('NFKC').trim().replace(/\.(png|jpe?g|webp|mp4|webm|mov|wav|mp3|m4a)$/i,'').toLowerCase();
// Asset names may carry an enumeration prefix the canvas title lacks (B05 黄皮子小妖 vs 黄皮子小妖). Strip it for a second-pass match; content verification still decides reuse.
const codeName=value=>referenceName(value).replace(/^[a-z]?\d+\s+/,'');
function canvasId(value){if(uuid(value))return value.toLowerCase();let url;try{url=new URL(value);}catch{throw Error('请输入即梦画布链接或画布编号');}const match=/^\/ai-tool\/(?:ai-canvas|canvas)\/([a-f0-9-]+)\/?$/i.exec(url.pathname);if(url.protocol!=='https:'||url.hostname!=='jimeng.jianying.com'||url.username||url.password||url.port||!uuid(match?.[1]))throw Error('请输入有效的即梦官网画布链接');return match[1].toLowerCase();}
class DreaminaCanvasTargets{
 constructor(service){this.service=service;this.pending=new Map();}
 directory(projectKey,account){if(typeof projectKey!=='string'||!projectKey||projectKey.length>160)throw Error('请先选择工作台项目');return path.join(this.service.dataDir,'projects',digest(account+'\0'+projectKey));}
 serial(dir,action){const work=(this.pending.get(dir)||Promise.resolve()).catch(()=>{}).then(action);this.pending.set(dir,work);return work.finally(()=>{if(this.pending.get(dir)===work)this.pending.delete(dir);});}
 async settings(projectKey){
  if(this.service.expectedAccount){
   const local=await this.service.read(this.directory(projectKey,this.service.expectedAccount));
   if(local)return local;
  }
  const account=await this.service.account().catch(()=>this.service.expectedAccount||'');
  if(account){
   const local=await this.service.read(this.directory(projectKey,account));
   if(local)return local;
  }
  try{
   const pDir=path.join(this.service.dataDir,'projects');
   const entries=await fs.readdir(pDir,{withFileTypes:true}).catch(()=>[]);
   for(const ent of entries){
    if(ent.isDirectory()){
     const candidate=await this.service.read(path.join(pDir,ent.name));
     if(candidate&&candidate.projectKey===projectKey)return candidate;
    }
   }
  }catch{}
  return null;
 }
 async list(){let cursor;const items=[],seen=new Set();for(let i=0;i<100;i++){const page=await this.service.command(['canvas','ls','--limit','100',...(cursor?['--cursor',cursor]:[])]);if(!Array.isArray(page.items))throw Error('官网画布列表不完整');for(const p of page.items){if(!uuid(p.projectId)||canvasId(p.webUrl)!==p.projectId.toLowerCase())throw Error('官网返回的画布身份不匹配');if(!seen.has(p.projectId)){seen.add(p.projectId);items.push({projectId:p.projectId,name:p.name||p.projectId,webUrl:p.webUrl});}}if(!page.hasMore)return items;if(!page.nextCursor||page.nextCursor===cursor)throw Error('官网画布分页没有推进');cursor=page.nextCursor;}throw Error('画布数量过多，请在官网核对');}
 async bind({projectKey,url}){const account=await this.service.account(),dir=this.directory(projectKey,account),id=canvasId(url);return this.serial(dir,async()=>{const target=(await this.list()).find(p=>p.projectId.toLowerCase()===id);if(!target)throw Error('当前 CLI 账号无法访问这个画布，请核对账号和链接');if(await this.service.account()!==account)throw Error('即梦账号已变化，已阻止绑定');const prior=await this.service.read(dir);const value={...target,account,projectKey,locked:true,existingOnly:false,bindings:prior?.projectId===target.projectId?prior.bindings||[]:[]};await this.service.save(dir,value);return value;});}
 async project(projectKey,account){const current=account||await this.service.account().catch(()=>this.service.expectedAccount||'');if(!current)throw Error('新版即梦未登录，请先登录账号');const dir=this.directory(projectKey,current);return this.serial(dir,async()=>{const prior=await this.service.read(dir);// New requests automatically fill missing media; keep stored settings and old captures intact.
 if(prior?.webUrl)return {...prior,existingOnly:false};const target=prior||{projectId:randomUUID(),account,projectKey};await this.service.save(dir,target);const r=await this.service.command(['canvas','create','工作台 · '+projectKey,'--project-id',target.projectId]);if(r.project?.projectId!==target.projectId||canvasId(r.project.webUrl)!==target.projectId.toLowerCase())throw Error('新版即梦画布身份不匹配');Object.assign(target,{webUrl:r.project.webUrl,name:r.project.name||'工作台 · '+projectKey});await this.service.save(dir,target);return target;});}
 async capture(projectKey){const account=await this.service.account(),target=await this.project(projectKey,account),token=randomUUID();await this.service.save(path.join(this.service.dataDir,'_canvas-captures',token),target);return {token,...target};}
 async captured(token,projectKey,account){if(!uuid(token))throw Error('无效的画布锁定记录');const target=await this.service.read(path.join(this.service.dataDir,'_canvas-captures',token));if(!target||target.account!==account||target.projectKey!==projectKey||!uuid(target.projectId))throw Error('画布锁定记录与项目或账号不匹配');return target;}
 async nodes(projectId){if(!uuid(projectId))throw Error('无效的画布编号');const items=[],seen=new Set();for(let offset=0;offset<=1000;offset+=50){const r=await this.service.command(['node','find','--project-id',projectId,'--limit','50','--offset',String(offset)]);if(r.projectId!==projectId||!Array.isArray(r.items))throw Error('官网节点列表身份不匹配');for(const node of r.items)if(!seen.has(node.nodeId)&&['image','video','audio'].includes(node.type)){seen.add(node.nodeId);items.push(node);}if(!r.hasMore)return items;}throw Error('画布节点过多，无法完整读取，请缩小画布后重试');}
 async node(projectId,id,kind){const r=await this.service.command(['node','show','--project-id',projectId,'--node-id',id]),n=r.nodes?.find(x=>x.result==='FOUND'&&x.node?.nodeId===id)?.node;if(!n||n.type!==kind||!n.resources?.some(x=>x.type===kind&&x.status==='success'))throw Object.assign(Error('画布素材节点不存在、类型不符或尚未就绪，请重新绑定'),{code:'workbench.canvas_reference_unavailable'});return n;}
 async configure({projectKey,projectId,existingOnly,bindings}){const account=await this.service.account(),dir=this.directory(projectKey,account);return this.serial(dir,async()=>{const target=await this.service.read(dir);if(!target||target.projectId!==projectId)throw Error('当前项目画布已切换，请重新打开画布管理');if(typeof existingOnly!=='boolean'||!Array.isArray(bindings)||bindings.length>500)throw Error('画布素材设置无效');const known=new Set((await this.nodes(projectId)).map(n=>n.nodeId)),keys=new Set();for(const b of bindings){if(!['image','video','audio'].includes(b.kind)||typeof b.name!=='string'||!b.name.trim()||b.name.length>100||typeof b.nodeId!=='string'||!known.has(b.nodeId))throw Error('素材绑定无效，请选择当前画布里的节点');const key=b.kind+'\0'+referenceName(b.name);if(keys.has(key))throw Error('同一种类型的素材名称不能重复绑定');keys.add(key);await this.node(projectId,b.nodeId,b.kind);}target.existingOnly=existingOnly;target.bindings=bindings.map(b=>({kind:b.kind,name:b.name.trim(),nodeId:b.nodeId}));await this.service.save(dir,target);return target;});}
 async resolve(target,media,{preferCurrent=false}={}){const binding=target.bindings?.find(b=>b.kind===media.kind&&referenceName(b.name)===referenceName(media.name));if(binding&&!preferCurrent){await this.node(target.projectId,binding.nodeId,media.kind);return {kind:media.kind,name:media.name,nodeId:binding.nodeId,origin:'canvas-binding'};}if(!binding&&!target.locked&&!target.existingOnly)return null;
  // Names only narrow the candidates. Reuse requires identical file content.
  const named=(await this.nodes(target.projectId)).filter(n=>n.type===media.kind&&(referenceName(n.title)===referenceName(media.name)||(codeName(n.title)!==''&&codeName(n.title)===codeName(media.name)))).sort((a,b)=>a.nodeId.localeCompare(b.nodeId));
  const candidates=[...new Map([...(binding?[{nodeId:binding.nodeId}]:[]),...named].map(n=>[n.nodeId,n])).values()],matches=[];
  for(const candidate of candidates){let n;try{n=await this.node(target.projectId,candidate.nodeId,media.kind);}catch(error){if(preferCurrent&&!target.existingOnly&&error.code==='workbench.canvas_reference_unavailable')continue;throw error;}const resources=n.resources.filter(r=>r.type===media.kind&&r.status==='success');if(resources.length!==1)continue;const resource=resources[0];if(!uuid(resource.resourceId))continue;const dir=path.join(this.service.dataDir,'_canvas-fingerprints',digest(target.account+'\0'+target.projectId+'\0'+resource.resourceId));const stored=await this.serial(dir,async()=>{let stored=await this.service.read(dir);if(!stored){await fs.mkdir(dir,{recursive:true});const file=path.join(dir,'verify.'+media.ext);try{const r=await this.service.command(['resource','download',resource.resourceId,'--project-id',target.projectId,'--output',file]);const real=await fs.realpath(r.path),base=await fs.realpath(dir),relative=path.relative(base,real);if(relative.startsWith('..')||path.isAbsolute(relative)||r.resourceId!==resource.resourceId||!Number.isInteger(r.size)||r.size<=0||r.size>128*1024*1024||(await fs.stat(real)).size!==r.size)throw Error('已有素材下载校验失败');const sha=digest(await fs.readFile(real));if(sha!==r.sha256)throw Error('已有素材内容校验失败');stored={resourceId:resource.resourceId,sha256:sha};await this.service.save(dir,stored);}finally{await fs.unlink(file).catch(e=>{if(e.code!=='ENOENT')throw e;});}}return stored;});if(stored.resourceId!==resource.resourceId)throw Error('已有素材校验记录不匹配');if(stored.sha256===digest(media.bytes)){const current=await this.node(target.projectId,n.nodeId,media.kind);if(current.resources.filter(r=>r.type===media.kind&&r.status==='success').length===1&&current.resources.some(r=>r.resourceId===resource.resourceId&&r.status==='success'))matches.push(n.nodeId);}if(matches.length)break;}
  if(matches.length)return {kind:media.kind,name:media.name,nodeId:matches[0],origin:'canvas-content'};if(target.existingOnly)throw Error('锁定画布中未核对到「'+media.name+'」，请在即梦画布管理中绑定已有素材，或允许上传缺失素材');return null;
 }
}
module.exports={DreaminaCanvasTargets,canvasId,referenceName,codeName};
