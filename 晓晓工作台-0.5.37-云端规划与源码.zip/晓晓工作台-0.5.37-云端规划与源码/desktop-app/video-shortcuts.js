const fs=require('node:fs'),path=require('node:path');
function sameInode(a,b){try{const sa=fs.statSync(a,{bigint:true}),sb=fs.statSync(b,{bigint:true});return sa.ino>0n&&sa.ino===sb.ino&&sa.dev===sb.dev;}catch{return false;}}
class VideoShortcuts{
 constructor({file,videos,shell,choose}){Object.assign(this,{file,videos,shell,choose});this.queue=Promise.resolve();}
 read(){try{return JSON.parse(fs.readFileSync(this.file,'utf8'));}catch(e){if(e.code==='ENOENT')return {};throw e;}}
 create(payload){const work=this.queue.then(()=>this.createOnce(payload));this.queue=work.catch(()=>{});return work;}
 async createOnce({projectId,ids}){
  this.videos.id(projectId);if(!Array.isArray(ids)||!ids.length||ids.length>2000)throw Error('请选择已完成的视频');
  const sources=[...new Set(ids)].map(id=>{const video=this.videos.videoInfo({projectId,videoId:id});if(!video)throw Error('视频尚未保存到工作台，请先等待归档完成');if(!fs.statSync(video.path).isFile())throw Error('原视频不是可读取文件');return {id,target:fs.realpathSync(video.path)};});
  const settings=this.read(),last=settings[projectId]?.directory;const selected=await this.choose(last);if(!selected)return {canceled:true,created:0};
  const directory=fs.realpathSync(selected);if(!fs.statSync(directory).isDirectory())throw Error('请选择文件夹');
  let created=0,existing=0,hardlinked=0,fallbackShortcut=0;
  for(const source of sources){
   const ext=path.extname(source.target)||'.mp4',stem=path.basename(source.target,ext);
   let n=0,file=null,legacyLnk=null;
   for(;;){
    const suffix=n?' ('+n+')':'';
    const mp4Candidate=path.join(directory,stem+suffix+ext);
    const lnkCandidate=path.join(directory,stem+suffix+'.lnk');
    if(fs.existsSync(mp4Candidate)){
     if(sameInode(mp4Candidate,source.target)){
      if(fs.existsSync(lnkCandidate)){try{if(path.resolve(this.shell?.readShortcutLink?.(lnkCandidate)?.target||'').toLowerCase()===path.resolve(source.target).toLowerCase())fs.unlinkSync(lnkCandidate);}catch{}}
      existing++;file=null;break;
     }
     n++;continue;
    }
    if(fs.existsSync(lnkCandidate)){
     try{
      if(path.resolve(this.shell?.readShortcutLink?.(lnkCandidate)?.target||'').toLowerCase()===path.resolve(source.target).toLowerCase()){
       legacyLnk=lnkCandidate;file=mp4Candidate;break;
      }
     }catch{}
     n++;continue;
    }
    file=mp4Candidate;break;
   }
   if(!file)continue;
   try{
    fs.linkSync(source.target,file);
    if(legacyLnk){try{fs.unlinkSync(legacyLnk);}catch{}}
    created++;hardlinked++;
   }catch(err){
    if(err&&err.code==='EXDEV'){
     const lnkFile=legacyLnk||file.slice(0,-ext.length)+'.lnk';
     if(legacyLnk){existing++;continue;}
     if(!this.shell?.writeShortcutLink?.(lnkFile,'create',{target:source.target,cwd:path.dirname(source.target),description:'晓晓工作台视频快捷方式；跨盘自动降级为快捷方式'}))throw Error('跨盘不支持直接创建 .mp4 硬链接分身，且创建快捷方式失败：'+lnkFile);
     created++;fallbackShortcut++;
    }else{
     throw Error('创建视频硬链接分身失败：'+(err?.message||file));
    }
   }
  }
  fs.mkdirSync(path.dirname(this.file),{recursive:true});fs.writeFileSync(this.file+'.tmp',JSON.stringify({...settings,[projectId]:{directory}}));fs.renameSync(this.file+'.tmp',this.file);
  return {path:directory,created,existing,hardlinked,fallbackShortcut,canceled:false};
 }
}
module.exports={VideoShortcuts,sameInode};
