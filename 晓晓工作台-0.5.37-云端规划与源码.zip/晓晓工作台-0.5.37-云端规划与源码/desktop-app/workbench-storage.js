const fs=require('node:fs'),path=require('node:path');
const NO_PROXY_DOMAINS='localhost,127.0.0.1,.jianying.com,jimeng.jianying.com,.bytedance.com,.volces.com,.byteimg.com,.snssdk.com,.feishu.cn';
function mergeNoProxy(existing){
  if(!existing)return NO_PROXY_DOMAINS;
  const set=new Set(existing.split(',').map(s=>s.trim()).filter(Boolean));
  for(const d of NO_PROXY_DOMAINS.split(','))set.add(d);
  return Array.from(set).join(',');
}
function storagePaths(home,profile){
  if(!path.isAbsolute(home)||profile&&!path.isAbsolute(profile))throw Error('工作台数据位置必须是绝对路径');
  const data=path.resolve(profile||path.join(home,'工作台数据'));
  return {home:path.resolve(home),data,temp:path.join(data,'临时文件'),logs:path.join(data,'logs'),crashDumps:path.join(data,'crashes'),cliRoaming:path.join(data,'cli','roaming'),cliLocal:path.join(data,'cli','local'),cliState:path.join(data,'cli','dreamina-business-state')};
}
function configureStorage(app,env=process.env){
  const current=app.getPath('userData'),normal=path.join(app.getPath('appData'),app.getName());
  // Native test fixtures may already have set their own profile before loading main.
  const profile=env.WORKBENCH_PROFILE_DIR||(path.resolve(current)!==path.resolve(normal)?current:null);
  const home=env.WORKBENCH_HOME_DIR||require('./assets/storage-home.json').home;
  const paths=storagePaths(home,profile);
  for(const dir of [paths.data,paths.temp,paths.logs,paths.crashDumps,paths.cliRoaming,paths.cliLocal])fs.mkdirSync(dir,{recursive:true});
  app.setPath('userData',paths.data);app.setPath('sessionData',paths.data);app.setPath('temp',paths.temp);app.setPath('crashDumps',paths.crashDumps);app.setAppLogsPath(paths.logs);
  env.TEMP=env.TMP=paths.temp;env.WORKBENCH_CLI_ROAMING_DIR=paths.cliRoaming;env.WORKBENCH_CLI_LOCAL_DIR=paths.cliLocal;env.WORKBENCH_DREAMINA_STATE_DIR=paths.cliState;
  return paths;
}
function cliEnvironment(storage,extraEnv={},profile=''){
  const base=storage&&typeof storage==='object'&&!storage.WORKBENCH_CLI_ROAMING_DIR&&!storage.PATH&&!storage.Path&&storage.cliRoaming
    ?{APPDATA:storage.cliRoaming,LOCALAPPDATA:storage.cliLocal,DREAMINA_CANVAS_STATE_DIR:storage.cliState,...extraEnv}
    :{...(storage||process.env),...extraEnv};
  const roaming=base.WORKBENCH_CLI_ROAMING_DIR||(storage&&storage.cliRoaming);
  const local=base.WORKBENCH_CLI_LOCAL_DIR||(storage&&storage.cliLocal);
  const state=base.WORKBENCH_DREAMINA_STATE_DIR||(storage&&storage.cliState);
  const noProxy=mergeNoProxy(base.NO_PROXY||base.no_proxy||process.env.NO_PROXY||process.env.no_proxy);
  return {
    ...base,
    ...(roaming?{APPDATA:roaming}:{}),
    ...(local?{LOCALAPPDATA:local}:{}),
    ...(state?{DREAMINA_CANVAS_STATE_DIR:state}:{}),
    NO_PROXY:noProxy,
    no_proxy:noProxy
  };
}
module.exports={storagePaths,configureStorage,cliEnvironment};
