export type AgentModelInfo={id:string;name:string;contextWindow?:number;maxOutputTokens?:number;inputModalities:string[];reasoningEfforts:string[];defaultEffort?:string;tools?:boolean;web?:boolean;reasoning?:boolean;source?:string};
export type AgentModelOverride=Partial<AgentModelInfo>;
export type AgentProvider={id:string;name:string;enabled:boolean;baseUrl:string;apiKey:string;hasKey?:boolean;useSavedKey?:boolean;model:string;modelDetails:AgentModelInfo[];modelIds?:string[];modelOverrides?:Record<string,AgentModelOverride>;efforts?:Record<string,string>;reasoningEffort?:string};
export type AgentSettings={provider:'codex'|'agy'|'custom';codexModel?:string;agyModel?:string;codexEfforts?:Record<string,string>;agyEfforts?:Record<string,string>;providers?:AgentProvider[];activeProviderId?:string;customApi?:Partial<AgentProvider>&{baseUrl:string;apiKey:string;model:string}};
export const AGY_DEFAULT_MODELS=[{slug:'gemini-4-argon',name:'Gemini 4 Argon（原 3.1 Pro 升级版）· Antigravity',efforts:['low','medium','high'],defaultEffort:'medium'},{slug:'gemini-3.8-flash',name:'Gemini 3.8 Flash · Antigravity',efforts:['low','medium','high'],defaultEffort:'high'},{slug:'claude-opus-5-5',name:'Claude Opus 5.5 · Antigravity',efforts:['low','medium','high'],defaultEffort:'medium'},{slug:'claude-sonnet-5-5',name:'Claude Sonnet 5.5 · Antigravity',efforts:['low','medium','high'],defaultEffort:'medium'},{slug:'gpt-oss-120b',name:'GPT-OSS 120B · Antigravity',efforts:[],defaultEffort:'medium'}];
export const effortLabel=(v:string)=>({off:'关闭',default:'默认',minimal:'极低',low:'低',medium:'中',high:'高',xhigh:'超高',max:'极致',ultra:'极高',none:'关闭'}[v]||v);
const EFFORT_RANK:Record<string,number>={off:0,none:0,default:1,minimal:2,low:3,medium:4,high:5,xhigh:6,max:7,ultra:8};
export function sortReasoningEfforts(list:string[]){return [...new Set(list)].sort((a,b)=>(EFFORT_RANK[a]??99)-(EFFORT_RANK[b]??99));}
export const MODEL_RULES=[{match:/(?:reasoner|thinking|(?:^|[-/])r1(?:$|-))/i,values:{reasoning:true}},{match:/(?:vision|(?:^|[-/])vl(?:$|-))/i,values:{inputModalities:['text','image']}},{match:/^deepseek-(?:chat|flash|v4-pro|v4-flash)(?:$|-)/i,values:{reasoning:true,tools:true,reasoningEfforts:['low','medium','high','max']}},{match:/^deepseek-reasoner$/i,values:{reasoning:true,reasoningEfforts:[]}},{match:/^gemini-(?:2\.5|3|4|pro|flash)/i,values:{reasoning:true,tools:true,inputModalities:['text','image'],reasoningEfforts:['low','medium','high']}}];
export function resolveAgentModel(model:AgentModelInfo,override:AgentModelOverride={}):AgentModelInfo{let inferred:Partial<AgentModelInfo>={};for(const rule of MODEL_RULES)if(rule.match.test(model.id))inferred={...inferred,...rule.values};const rawEfforts=override.reasoningEfforts??((model.reasoningEfforts?.length||model.source==='接口声明')?model.reasoningEfforts:inferred.reasoningEfforts)??[];return {...inferred,...model,...override,id:model.id,name:override.name||model.name||model.id,inputModalities:override.inputModalities??((model.inputModalities?.length||model.source==='接口声明')?model.inputModalities:inferred.inputModalities)??['text'],reasoningEfforts:sortReasoningEfforts(rawEfforts),source:Object.keys(override).length?'手动覆盖':model.source||'按名称推断'} as AgentModelInfo;}
export function normalizeAgentModels(data:unknown):AgentModelInfo[]{if(!Array.isArray(data))return [];return data.slice(0,1000).filter(m=>m&&typeof m.id==='string'&&m.id.length<=200).map(m=>{const x:any={id:m.id,name:typeof m.name==='string'?m.name:m.id,source:'按名称推断'};if(Number.isFinite(m.context_window))x.contextWindow=m.context_window;if(Number.isFinite(m.max_output_tokens))x.maxOutputTokens=m.max_output_tokens;if(Array.isArray(m.input_modalities))x.inputModalities=m.input_modalities.filter((s:unknown)=>s==='text'||s==='image');if(Array.isArray(m.effort?.supported_levels))x.reasoningEfforts=m.effort.supported_levels.filter((s:unknown)=>typeof s==='string'&&/^[a-z0-9_-]{1,32}$/.test(s));if(typeof m.effort?.default_level==='string')x.defaultEffort=m.effort.default_level;for(const [key,field] of Object.entries({tools:'tool_calls',web:'web_search',reasoning:'reasoning'})){const v=m.capabilities?.[field]??m[field];if(typeof v==='boolean')x[key]=v;}if(x.reasoningEfforts)x.reasoning=x.reasoningEfforts.length>0;if(x.inputModalities||x.reasoningEfforts)x.source='接口声明';return resolveAgentModel(x);});}
export function providerModel(p?:Partial<AgentProvider>){if(!p)return undefined;return resolveAgentModel(p.modelDetails?.find(m=>m.id===p.model)||{id:p.model||'',name:p.model||''} as AgentModelInfo,p.modelOverrides?.[p.model||'']);}
export function reasoningLevels(model?:AgentModelInfo,deepseek=false){if(!model?.reasoning&&!model?.reasoningEfforts?.length)return [];return sortReasoningEfforts([...(deepseek?['off']:[]),'default',...(model.reasoningEfforts||[])]);}
export function agentThinkingOptions(baseUrl:string,effort='off',model?:AgentModelInfo){const host=new URL(baseUrl).hostname;const deepseek=host==='api.deepseek.com';const gemini=host==='generativelanguage.googleapis.com';const allowed=model?reasoningLevels(model,deepseek):['off','default','minimal','low','medium','high','xhigh','max'];const fallback=deepseek?'off':'default';const chosen=allowed.includes(effort)?effort:fallback;if(deepseek){const thinkingOff=chosen==='off'||!allowed.length;const dsEffort=chosen==='xhigh'?'max':chosen==='minimal'?'low':chosen;const canSendEffort=!thinkingOff&&dsEffort!=='default'&&(!model||model.reasoningEfforts.includes(dsEffort));return {thinking:{type:thinkingOff?'disabled':'enabled'},...(canSendEffort?{reasoning_effort:dsEffort}:{}),...(thinkingOff?{response_format:{type:'json_object'}}:{})};}if(!allowed.length||chosen==='off'||chosen==='default')return {};if(gemini){const gemAllowed=model?model.reasoningEfforts:['low','medium','high'];return gemAllowed.includes(chosen)?{reasoning_effort:chosen}:{};}if(model&&!model.reasoningEfforts.includes(chosen))return {};return {reasoning_effort:chosen};}
export const CODEX_FALLBACK_EFFORTS:string[]=[];
export function codexEffort(value:string|undefined,allowed:string[]=CODEX_FALLBACK_EFFORTS){if(!value||value==='default'||value==='off')return undefined;return Array.isArray(allowed)&&allowed.includes(value)?value:undefined;}
export function agyEffort(value:string|undefined,modelSlug?:string,models:{slug:string;efforts?:string[]}[]=AGY_DEFAULT_MODELS){if(!value||value==='default'||value==='off')return undefined;const found=models.find(m=>m.slug===(modelSlug||'gemini-4-argon'));const allowed=found?.efforts||[];return allowed.includes(value)?value:undefined;}

export function sanitizeModel(m:any):AgentModelInfo{const clean:any={id:String(m.id||'').slice(0,200),name:String(m.name||m.id||'').slice(0,200),inputModalities:Array.isArray(m.inputModalities)?m.inputModalities.filter((v:unknown)=>v==='text'||v==='image'):['text'],reasoningEfforts:Array.isArray(m.reasoningEfforts)?m.reasoningEfforts.filter((v:unknown)=>typeof v==='string'&&/^[a-z0-9_-]{1,32}$/.test(v)).slice(0,10):[]};for(const k of ['reasoning','tools','web'])if(typeof m[k]==='boolean')clean[k]=m[k];for(const k of ['contextWindow','maxOutputTokens'])if(Number.isInteger(m[k])&&m[k]>0&&m[k]<=10000000)clean[k]=m[k];if(typeof m.defaultEffort==='string')clean.defaultEffort=m.defaultEffort.slice(0,32);clean.source=['接口声明','按名称推断','手动覆盖'].includes(m.source)?m.source:'按名称推断';return clean;}

export function isDeepseekApi(url?:string){try{return new URL(url||'').hostname==='api.deepseek.com';}catch{return false;}}

export function clientAgentSettings(s:AgentSettings){return {provider:s.provider,codexModel:s.codexModel,agyModel:s.agyModel,codexEfforts:s.codexEfforts,agyEfforts:s.agyEfforts,activeProviderId:s.activeProviderId};}

export function normalizeAgentProvider(p:any,index=0):AgentProvider{const modelDetails=Array.isArray(p?.modelDetails)?p.modelDetails.filter((m:any)=>m&&typeof m.id==='string').map(sanitizeModel):[];const modelIds=Array.isArray(p?.modelIds)?p.modelIds.filter((id:any)=>typeof id==='string'):undefined;const rawModel=typeof p?.model==='string'?p.model:'deepseek-flash';const model=modelIds?.length&&modelDetails.some((m:any)=>m.id===rawModel)&&!modelIds.includes(rawModel)?modelIds[0]:rawModel;const rawEfforts=p?.efforts&&typeof p.efforts==='object'?{...p.efforts}:{};if(Object.keys(rawEfforts).length===0&&typeof p?.reasoningEffort==='string'&&p.reasoningEffort&&rawModel){rawEfforts[rawModel]=p.reasoningEffort;}const {reasoningEffort:_legacyEffort,...rest}=p||{};return {...rest,id:typeof p?.id==='string'&&p.id?p.id:'legacy'+(index?'-'+index:''),name:typeof p?.name==='string'&&p.name?p.name:'自定义服务商',enabled:p?.enabled!==false,baseUrl:typeof p?.baseUrl==='string'?p.baseUrl:'https://api.deepseek.com',apiKey:typeof p?.apiKey==='string'?p.apiKey:'',model,modelDetails,modelIds,modelOverrides:p?.modelOverrides&&typeof p.modelOverrides==='object'?p.modelOverrides:{},efforts:rawEfforts};}

export function resolveActiveAgentThinkingState(
    settings: AgentSettings,
    codexModels: { slug: string; name?: string; efforts?: string[]; defaultEffort?: string; isDefault?: boolean }[] = [],
    agyStatus?: { available: boolean; authenticated?: boolean; models?: { slug: string; name?: string; efforts?: string[]; defaultEffort?: string }[] } | null,
): { levels: string[]; saved: string; current: string; modelKey: string } {
    if (settings.provider === 'codex') {
        const modelKey = settings.codexModel || 'auto';
        const target = settings.codexModel
            ? codexModels.find(m => m.slug === settings.codexModel)
            : (codexModels.find(m => m.isDefault) || codexModels[0]);
        const levels = target && Array.isArray(target.efforts) && target.efforts.length > 0
            ? ['default', ...sortReasoningEfforts(target.efforts)]
            : [];
        const saved = settings.codexEfforts?.[modelKey] || 'default';
        const current = levels.includes(saved) ? saved : (levels[0] || 'default');
        return { levels, saved, current, modelKey };
    }
    if (settings.provider === 'agy') {
        const modelKey = settings.agyModel || 'gemini-4-argon';
        if (agyStatus && agyStatus.available === false) {
            return { levels: [], saved: 'default', current: 'default', modelKey };
        }
        const agyModels = agyStatus?.models?.length ? agyStatus.models : AGY_DEFAULT_MODELS;
        const target = agyModels.find(m => m.slug === modelKey);
        const levels = !target
            ? []
            : target.efforts && target.efforts.length > 0
              ? ['default', ...sortReasoningEfforts(target.efforts)]
              : ['default'];
        const saved = settings.agyEfforts?.[modelKey] || 'default';
        const current = levels.includes(saved) ? saved : (levels[0] || 'default');
        return { levels, saved, current, modelKey };
    }
    const activeProvider = settings.providers?.find(a => a.id === settings.activeProviderId) || settings.customApi;
    const m = providerModel(activeProvider);
    const deepseek = isDeepseekApi(activeProvider?.baseUrl);
    const levels = reasoningLevels(m, deepseek);
    const modelKey = activeProvider?.model || '';
    const hasEffortsMap = Boolean(activeProvider?.efforts && typeof activeProvider.efforts === 'object');
    const rawSaved = (modelKey ? activeProvider?.efforts?.[modelKey] : undefined) ?? (!hasEffortsMap ? activeProvider?.reasoningEffort : undefined);
    const fallback = deepseek ? 'off' : 'default';
    const saved = rawSaved || fallback;
    const current = levels.includes(saved) ? saved : (levels.includes(fallback) ? fallback : (levels[0] || 'default'));
    return { levels, saved, current, modelKey };
}

export function buildNextSettingsForEffort(settings: AgentSettings, v: string): AgentSettings {
    if (settings.provider === 'codex') {
        const key = settings.codexModel || 'auto';
        return {
            ...settings,
            codexEfforts: { ...(settings.codexEfforts || {}), [key]: v },
        };
    }
    if (settings.provider === 'agy') {
        const key = settings.agyModel || 'gemini-4-argon';
        return {
            ...settings,
            agyEfforts: { ...(settings.agyEfforts || {}), [key]: v },
        };
    }
    const activeProvider = settings.providers?.find(a => a.id === settings.activeProviderId) || settings.customApi;
    const targetId = settings.activeProviderId || settings.providers?.[0]?.id || 'legacy';
    const modelKey = activeProvider?.model || '';
    const providers = settings.providers?.map(a => {
        if (a.id !== targetId || !modelKey) return a;
        const { reasoningEffort: _legacy, ...rest } = a as any;
        return { ...rest, efforts: { ...(a.efforts || {}), [modelKey]: v } };
    });
    let customApi = settings.customApi;
    if (customApi && modelKey) {
        const { reasoningEffort: _legacy, ...rest } = customApi as any;
        customApi = { ...rest, efforts: { ...(customApi.efforts || {}), [modelKey]: v } };
    }
    return {
        ...settings,
        providers,
        customApi,
    };
}
