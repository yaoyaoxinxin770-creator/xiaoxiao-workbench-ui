import fs from 'node:fs/promises';
import {sanitizeModel,normalizeAgentProvider,AGY_DEFAULT_MODELS} from './agent-models';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';

function settingsFile() {
    const dir = process.env.WORKBENCH_AGENT_SETTINGS_DIR || process.env.WORKBENCH_PROFILE_DIR || (process.env.WORKBENCH_HOME_DIR ? path.join(process.env.WORKBENCH_HOME_DIR, '工作台数据') : '');
    if (!path.isAbsolute(dir)) throw Error('Agent本机配置目录未就绪');
    return path.join(dir, 'agent-api-protected.json');
}

export function protect(text: string, decrypt = false): Promise<string> {
    return new Promise((resolve, reject) => {
        if (process.platform !== 'win32') { reject(Error('本机密钥保护仅支持Windows')); return; }
        const script = 'Add-Type -AssemblyName System.Security; $s=[Console]::In.ReadToEnd(); $b=[Convert]::FromBase64String($s); $r=[Security.Cryptography.ProtectedData]::' + (decrypt ? 'Unprotect' : 'Protect') + '($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser); [Console]::Write([Convert]::ToBase64String($r))';
        const child = spawn(path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe'), ['-NoProfile', '-NonInteractive', '-Command', script], { windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
        let output = '', settled = false;
        const finish = (error?: Error, value?: string) => {
            if (settled) return;
            settled = true;
            clearTimeout(timer);
            if (error) reject(error); else resolve(value!);
        };
        const timer = setTimeout(() => { finish(Error('Windows密钥保护超时，请重试')); child.kill(); }, 15000);
        child.stdout.on('data', chunk => output += chunk);
        child.stderr.resume();
        child.stdin.on('error', () => finish(Error('Windows密钥保护不可用')));
        child.on('error', () => finish(Error('Windows密钥保护不可用')));
        child.on('close', code => code ? finish(Error('Windows密钥保护失败')) : finish(undefined, decrypt ? Buffer.from(output.trim(), 'base64').toString('utf8') : output.trim()));
        child.stdin.end(decrypt ? text : Buffer.from(text).toString('base64'));
    });
}

function normalizeAgyModelSlug(slug?: string): string {
    if (!slug || slug === 'gemini-2.5-pro') return 'gemini-4-argon';
    return AGY_DEFAULT_MODELS.some(m => m.slug === slug) ? slug : 'gemini-4-argon';
}

// Legacy single-provider records are projected to v2 without decrypting or replacing their key.
export function migrateAgentSettings(raw:any){if(!raw)return null;const providers=Array.isArray(raw.providers)?raw.providers:raw.customApi?[{...raw.customApi,id:'legacy',name:new URL(raw.customApi.baseUrl).hostname==='api.deepseek.com'?'DeepSeek':'自定义服务商',enabled:true,efforts:{[raw.customApi.model]:raw.customApi.reasoningEffort||'off'}}]:[];const id=raw.activeProviderId||providers[0]?.id;const agyModel=normalizeAgyModelSlug(raw.agyModel);const codexEfforts=raw.codexEfforts&&typeof raw.codexEfforts==='object'?{...raw.codexEfforts}:{};const agyEfforts=raw.agyEfforts&&typeof raw.agyEfforts==='object'?{...raw.agyEfforts}:{};if(Object.keys(agyEfforts).length===0&&raw.agyModel&&codexEfforts[raw.agyModel]){agyEfforts[agyModel]=codexEfforts[raw.agyModel];}return {version:2,provider:raw.provider==='custom'?'custom':raw.provider==='agy'?'agy':'codex',codexModel:raw.codexModel||'',agyModel,codexEfforts,agyEfforts,activeProviderId:id,providers:providers.filter((p:any)=>p&&typeof p==='object').map(normalizeAgentProvider)};}
async function readSettings(){try{return migrateAgentSettings(JSON.parse(await fs.readFile(settingsFile(),'utf8')));}catch(e:any){if(e.code==='ENOENT')return null;throw Error('Agent配置无法读取，请保留原文件并核对');}}
export async function loadAgentSettings(secret=false,providerId?:string){const raw=await readSettings();if(!raw)return null;const providers=[];for(const p of raw.providers){const {protectedKey,...rest}=p;providers.push({...rest,apiKey:secret&&p.id===(providerId||raw.activeProviderId)&&protectedKey?await protect(protectedKey,true):'',hasKey:Boolean(protectedKey),useSavedKey:true});}return {...raw,providers,customApi:providers.find(p=>p.id===raw.activeProviderId)};}
let saveQueue:Promise<unknown>=Promise.resolve();
export function saveAgentSettings(input:any){const operation=saveQueue.then(async()=>{const previous=await readSettings(),file=settingsFile();const incoming=Array.isArray(input.providers)?input.providers:input.customApi?[{...input.customApi,id:previous?.activeProviderId||'legacy',name:'自定义服务商',enabled:true}]:previous?.providers||[];if(incoming.length>30)throw Error('最多30个服务商');const providers=[];const ids=new Set();for(const api of incoming){const id=String(api.id||randomUUID());if(!/^[a-zA-Z0-9_-]{1,100}$/.test(id)||ids.has(id))throw Error('服务商身份无效');ids.add(id);const url=new URL(api.baseUrl||'https://api.deepseek.com');if(!['https:','http:'].includes(url.protocol)||url.username||url.password||url.search||url.hash)throw Error('无效的API地址');const baseUrl=url.href.replace(/\/$/,'');const prior=previous?.providers.find((p:any)=>p.id===id&&p.baseUrl===baseUrl);const protectedKey=api.apiKey?await protect(String(api.apiKey)):prior?.protectedKey;const models=Array.isArray(api.modelDetails)?api.modelDetails.slice(0,1000):prior?.modelDetails||[];const modelName=String(api.model||'deepseek-flash').slice(0,200);const hasEffortsObj=api.efforts&&typeof api.efforts==='object'&&Object.keys(api.efforts).length>0;const hasPriorEfforts=prior?.efforts&&typeof prior.efforts==='object'&&Object.keys(prior.efforts).length>0;const legacyEffort=(!hasEffortsObj&&!hasPriorEfforts&&typeof api.reasoningEffort==='string'&&api.reasoningEffort)?{[modelName]:api.reasoningEffort}:{};const clean=JSON.parse(JSON.stringify({name:String(api.name||'服务商').slice(0,80),model:modelName,modelDetails:models.map(sanitizeModel),modelIds:Array.isArray(api.modelIds)?api.modelIds.filter((id:unknown)=>typeof id==='string').slice(0,1000):prior?.modelIds,modelOverrides:Object.fromEntries(Object.entries(api.modelOverrides||{}).slice(0,1000).map(([id,m])=>[id,sanitizeModel({...m as object,id})])),efforts:{...(prior?.efforts||{}),...(api.efforts&&typeof api.efforts==='object'?api.efforts:{}),...legacyEffort}}));if(JSON.stringify(clean).length>2000000)throw Error('模型配置过大');providers.push({id,enabled:api.enabled!==false,baseUrl,...clean,protectedKey});}const activeProviderId=input.activeProviderId||previous?.activeProviderId||providers[0]?.id;const value={version:2,provider:input.provider==='custom'?'custom':input.provider==='agy'?'agy':'codex',codexModel:String(input.codexModel??previous?.codexModel??''),agyModel:normalizeAgyModelSlug(String(input.agyModel||previous?.agyModel||'gemini-4-argon')),codexEfforts:input.codexEfforts&&typeof input.codexEfforts==='object'?input.codexEfforts:(previous?.codexEfforts||{}),agyEfforts:input.agyEfforts&&typeof input.agyEfforts==='object'?input.agyEfforts:(previous?.agyEfforts||{}),providers,activeProviderId};if(activeProviderId&&!ids.has(activeProviderId))throw Error('请选择已有服务商');await fs.mkdir(path.dirname(file),{recursive:true});const temp=file+'.'+randomUUID()+'.tmp';try{await fs.writeFile(temp,JSON.stringify(value),{mode:0o600});await fs.rename(temp,file);}finally{await fs.rm(temp,{force:true});}return loadAgentSettings();});saveQueue=operation.catch(()=>{});return operation;}
