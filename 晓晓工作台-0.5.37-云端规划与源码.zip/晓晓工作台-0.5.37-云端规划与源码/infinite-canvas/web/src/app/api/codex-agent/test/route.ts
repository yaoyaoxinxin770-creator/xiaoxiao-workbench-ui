import {NextResponse,type NextRequest} from 'next/server';
import {loadAgentSettings} from '@/lib/agent-settings';
import {normalizeAgentModels} from '@/lib/agent-models';
export const runtime='nodejs';
export async function POST(request:NextRequest){let secret='';try{
 const input=await request.json().catch(()=>null),saved=await loadAgentSettings(true,input?.providerId||input?.customApi?.id);
 const api=input?.customApi||saved?.providers?.find((p:any)=>p.id===input?.providerId)||saved?.customApi;if(!api?.baseUrl)throw Error('请先配置接口地址');
 const url=new URL(api.baseUrl);if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.search||url.hash)throw Error('接口地址无效');
 const prior=saved?.providers?.find((p:any)=>p.id===api.id)||saved?.customApi;secret=api.apiKey||(prior?.baseUrl===api.baseUrl?prior.apiKey:'');
 const base=api.baseUrl.replace(/\/chat\/completions\/?$/,'').replace(/\/$/,'');
 const headers:Record<string,string>=secret?{Authorization:'Bearer '+secret}:{};
 let r=await fetch(base+'/models',{headers,signal:AbortSignal.timeout(15000)});
 if(r.status===404&&!base.endsWith('/v1')){
  const r2=await fetch(base+'/v1/models',{headers,signal:AbortSignal.timeout(15000)}).catch(()=>null);
  if(r2&&r2.ok)r=r2;
 }
 if(!r.ok)return NextResponse.json({ok:false,error:'接口连接失败：HTTP '+r.status},{status:400});
 const raw=await r.text(),data=JSON.parse(secret?raw.replaceAll(secret,"[已隐藏]"):raw),modelDetails=normalizeAgentModels(data.data),models=modelDetails.map(m=>m.id);
 return NextResponse.json({ok:models.includes(api.model),connected:true,models,modelDetails,error:models.includes(api.model)?undefined:'授权有效，请从同步列表中选择可用模型'});
 }catch{return NextResponse.json({ok:false,error:'连接检查失败，请检查网络和API配置'},{status:400});}}
