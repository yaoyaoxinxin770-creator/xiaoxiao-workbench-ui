import {selectedAgentSkills,combineAgentSkills} from "@/lib/agent-skills";
import {agentThinkingOptions,providerModel,codexEffort,agyEffort,isDeepseekApi,AGY_DEFAULT_MODELS,CODEX_FALLBACK_EFFORTS} from "@/lib/agent-models";
import {loadAgentSettings} from "@/lib/agent-settings";
import { NextResponse, type NextRequest } from "next/server";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawn } from "node:child_process";
import { jsonrepair } from "jsonrepair";

export const runtime = "nodejs";
export const maxDuration = 300;

const joinPath = (...parts: string[]) => parts.filter(Boolean).join(path.sep);

function resolveCodexBinary(): { bin: string; isCmd: boolean } {
    const candidates: string[] = [];
    const localAppData = process.env.LOCALAPPDATA || joinPath(os.homedir(), "AppData", "Local");
    const codexBinRoot = joinPath(localAppData, "OpenAI", "Codex", "bin");
    try {
        if (fs.existsSync(codexBinRoot)) {
            const dirs = fs
                .readdirSync(codexBinRoot, { withFileTypes: true })
                .filter(d => d.isDirectory())
                .map(d => joinPath(codexBinRoot, d.name, "codex.exe"))
                .filter(p => fs.existsSync(p))
                .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);
            candidates.push(...dirs);
        }
    } catch {
        // ignore
    }
    try {
        const cfgPath = joinPath(os.homedir(), ".codex", "config.toml");
        if (fs.existsSync(cfgPath)) {
            const cfg = fs.readFileSync(cfgPath, "utf8");
            const match = cfg.match(/CODEX_CLI_PATH\s*=\s*['"]([^'"]+)['"]/);
            if (match?.[1] && fs.existsSync(match[1])) candidates.push(match[1]);
        }
    } catch {
        // ignore
    }
    const fixedPaths = [
        "F:/LOCAL_TOOLS/codex/codex.cmd",
        joinPath(process.env.APPDATA || "", "npm", "codex.cmd"),
    ];
    for (const p of fixedPaths) {
        if (p && fs.existsSync(p)) candidates.push(p);
    }
    const chosen = candidates[0] || "codex";
    return { bin: chosen, isCmd: chosen.toLowerCase().endsWith(".cmd") || chosen === "codex" };
}

function resolveAgyBinary(): { bin: string; isCmd: boolean; found: boolean } {
    if (process.env.AGY_CLI_PATH && fs.existsSync(process.env.AGY_CLI_PATH)) {
        const p = process.env.AGY_CLI_PATH;
        return { bin: p, isCmd: p.toLowerCase().endsWith(".cmd"), found: true };
    }
    const localAppData = process.env.LOCALAPPDATA || joinPath(os.homedir(), "AppData", "Local");
    const fixedPaths = [
        joinPath(localAppData, "agy", "bin", "agy.exe"),
        "F:/LOCAL_TOOLS/agy/bin/agy.exe",
        joinPath(process.env.APPDATA || "", "npm", "agy.cmd"),
    ];
    for (const p of fixedPaths) {
        if (p && fs.existsSync(p)) {
            return { bin: p, isCmd: p.toLowerCase().endsWith(".cmd"), found: true };
        }
    }
    const pathDirs = (process.env.PATH || "").split(path.delimiter).filter(Boolean);
    for (const d of pathDirs) {
        if (/Programs[\\/]Antigravity/i.test(d)) continue;
        for (const ext of ["agy.exe", "agy.cmd", "agy"]) {
            const p = path.join(d, ext);
            try {
                if (fs.existsSync(p)) return { bin: p, isCmd: p.toLowerCase().endsWith(".cmd"), found: true };
            } catch {
                // ignore
            }
        }
    }
    return { bin: "agy", isCmd: true, found: false };
}

function safeKillProcessTree(pid?: number) {
    if (!pid || pid <= 0) return;
    try {
        if (process.platform === "win32") {
            const killer = spawn("taskkill", ["/pid", String(pid), "/T", "/F"], { windowsHide: true, stdio: "ignore" });
            killer.on("error", () => {});
        } else {
            process.kill(-pid, "SIGKILL");
        }
    } catch {
        try {
            process.kill(pid, "SIGKILL");
        } catch {}
    }
}

function resolveWorkDir(): string {
    const preferredDirs = ["F:/WORKBENCH_TEMP", "F:/LOCAL_TOOLS/gemini"];
    for (const d of preferredDirs) {
        try {
            if (!fs.existsSync(d)) {
                fs.mkdirSync(d, { recursive: true });
            }
            if (fs.existsSync(d)) return d;
        } catch {
            // ignore
        }
    }
    return os.tmpdir();
}

function normalizeAgentParams(rawParams: any, currentParams?: any): { seconds?: string; size?: string; resolution?: string; model?: string } | undefined {
    if (!rawParams || typeof rawParams !== "object") return undefined;
    const params: Record<string, string> = {};
    if (rawParams.seconds !== undefined && rawParams.seconds !== null && rawParams.seconds !== "") {
        const cleaned = String(rawParams.seconds).trim().replace(/\s*(?:s|sec|seconds?|秒)$/i, "");
        if (/^[1-9]\d{0,2}$/.test(cleaned) && cleaned !== String(currentParams?.seconds || "").replace(/\s*s$/i, "")) {
            params.seconds = cleaned;
        } else if (/^[1-9]\d{0,2}$/.test(cleaned) && !currentParams) {
            params.seconds = cleaned;
        }
    }
    if (rawParams.size !== undefined && rawParams.size !== null && rawParams.size !== "") {
        const cleaned = String(rawParams.size).trim();
        const match = cleaned.match(/^(?:adaptive|[1-9]\d?:[1-9]\d?)/i);
        if (match && match[0] !== String(currentParams?.size || "")) {
            params.size = match[0];
        }
    }
    if (rawParams.resolution !== undefined && rawParams.resolution !== null && rawParams.resolution !== "") {
        const cleaned = String(rawParams.resolution).trim().toLowerCase();
        const norm = /^\d{3,4}$/.test(cleaned) ? `${cleaned}p` : cleaned;
        if (/^\d{3,4}p$/i.test(norm) && norm.toLowerCase() !== String(currentParams?.resolution || "").toLowerCase()) {
            params.resolution = norm.toLowerCase();
        }
    }
    if (rawParams.model !== undefined && rawParams.model !== null && rawParams.model !== "") {
        const cleaned = String(rawParams.model).trim();
        if (cleaned && cleaned !== "默认" && cleaned !== String(currentParams?.model || "").trim()) {
            const mapped = /^seedance[\s_-]*2\.5[\s_-]*draft$/i.test(cleaned)
                ? "seedance_2.5_draft"
                : /^seedance[\s_-]*2\.5$/i.test(cleaned)
                  ? "seedance_2.5"
                  : /^seedance[\s_-]*2\.0[\s_-]*fast$/i.test(cleaned)
                    ? "seedance_2.0_fast"
                    : /^seedance[\s_-]*2\.0$/i.test(cleaned)
                      ? "seedance_2.0"
                      : cleaned;
            if (/^[a-z0-9_.:/-]{1,100}$/i.test(mapped)) {
                params.model = mapped;
            }
        }
    }
    return Object.keys(params).length ? params : undefined;
}

function valueToText(val: any): string {
    if (typeof val === "string") return val.trim();
    if (Array.isArray(val)) {
        return val
            .map((item, idx) => {
                if (typeof item === "string") return item.trim();
                if (item && typeof item === "object") {
                    const title = item.title || item.name || item.scene || item.label || item.id || `分段 ${idx + 1}`;
                    const body =
                        item.prompt ||
                        item.content ||
                        item.description ||
                        item.text ||
                        item.value ||
                        Object.entries(item)
                            .filter(([k]) => !["title", "name", "scene", "label", "id"].includes(k))
                            .map(([k, v]) => `${k}：${typeof v === "string" ? v : JSON.stringify(v)}`)
                            .join("\n");
                    return `【${title}】\n${typeof body === "string" ? body.trim() : JSON.stringify(body)}`;
                }
                return String(item ?? "").trim();
            })
            .filter(Boolean)
            .join("\n\n");
    }
    if (val && typeof val === "object") {
        return Object.entries(val)
            .map(([k, v]) => {
                const sub = valueToText(v);
                return sub ? `【${k}】\n${sub}` : "";
            })
            .filter(Boolean)
            .join("\n\n");
    }
    return "";
}

function coerceAgentPromptText(parsed: any): string {
    if (!parsed || typeof parsed !== "object") return "";
    for (const key of [
        "prompt",
        "revisedPrompt",
        "videoPrompt",
        "scenePrompt",
        "scenePrompts",
        "scene_prompts",
        "scenes",
        "extracted",
        "result",
        "content",
        "output",
        "text",
        "answer",
        "response",
        "data",
    ]) {
        const text = valueToText(parsed[key]);
        if (text) return text;
    }
    const customEntries = Object.entries(parsed).filter(
        ([k]) => !["summary", "changes", "params", "voiceDrafts", "status", "ok", "mode"].includes(k),
    );
    if (customEntries.length > 0) {
        const text = valueToText(Object.fromEntries(customEntries));
        if (text) return text;
    }
    const fallback = [
        typeof parsed.summary === "string" ? parsed.summary.trim() : "",
        ...(Array.isArray(parsed.changes) ? parsed.changes.map((c: any) => valueToText(c)).filter(Boolean) : []),
    ]
        .filter(Boolean)
        .join("\n\n");
    return fallback;
}

export interface AgentVoiceDraft {
    roleName: string;
    voiceSpec: string;
    lineText: string;
    audioPrompt: string;
    scenario?: "omni-dubbing" | "text-reading";
    voiceName?: string;
}

function normalizeVoiceDrafts(rawDrafts: any, currentPrompt = "", instruction = "", projectAssets: any[] = []): AgentVoiceDraft[] {
    if (!/(配音|音色|声线|音频|SeedAudio|路人.*音|4秒.*音|授权可商用)/i.test(instruction)) return [];
    const list: AgentVoiceDraft[] = [];
    if (Array.isArray(rawDrafts)) {
        for (const item of rawDrafts) {
            if (!item || typeof item !== "object") continue;
            const roleName = String(item.roleName || item.role || item.name || item.character || "路人配音").trim();
            const voiceSpec = String(item.voiceSpec || item.timbre || item.voice || "自然清晰的角色声线，语速适中（约4秒）").trim();
            const lineText = String(item.lineText || item.line || item.text || "").trim();
            const audioPrompt = String(
                item.audioPrompt ||
                item.prompt ||
                (lineText ? `${voiceSpec}：${lineText}` : voiceSpec),
            ).trim();
            if (!audioPrompt) continue;
            list.push({
                roleName: roleName.slice(0, 40) || "路人配音",
                voiceSpec,
                lineText: lineText || audioPrompt,
                audioPrompt: audioPrompt.slice(0, 3000),
                scenario: item.scenario === "text-reading" ? "text-reading" : "omni-dubbing",
                ...(typeof item.voiceName === "string" && item.voiceName.trim() ? { voiceName: item.voiceName.trim() } : {}),
            });
        }
    }
    if (list.length > 0) return list.slice(0, 6);
    const existingAudioNames = new Set(
        projectAssets
            .filter((a: any) => a?.kind === "audio" || a?.category === "audio" || a?.category === "音频")
            .map((a: any) => String(a.title || "").trim()),
    );
    const dialogueMatches = Array.from(
        (currentPrompt || "").matchAll(/([^\n，。；：:“”"【】]{2,12}?)(?:[（(][^）)\n]{1,30}[）)])?[^\n。；]{0,20}?[：:]\s*[“"]([^”"\n]{3,40})[”"]/g),
    );
    for (const m of dialogueMatches) {
        const rawRole = String(m[1] || "").replace(/^(镜头\d+|画面|动作|紧接着|随后|此时|第\d+秒)/, "").trim();
        const line = String(m[2] || "").trim().slice(0, 24);
        if (!rawRole || !line || existingAudioNames.has(rawRole)) continue;
        if (list.some(d => d.roleName === rawRole)) continue;
        const spec = /女|姐|妈|姨|妹|婆/.test(rawRole)
            ? `${rawRole}自然真实女声，情绪贴合剧情，语速适中（约4秒）`
            : `${rawRole}沉稳清晰男声，情绪贴合剧情，语速适中（约4秒）`;
        list.push({
            roleName: rawRole.slice(0, 24),
            voiceSpec: spec,
            lineText: line,
            audioPrompt: `${spec}：${line}`,
            scenario: "omni-dubbing",
        });
        if (list.length >= 3) break;
    }
    return list;
}

function unescapeLooseJsonString(s: string): string {
    return s
        .replace(/\\n/g, "\n")
        .replace(/\\r/g, "\r")
        .replace(/\\t/g, "\t")
        .replace(/\\"/g, '"')
        .replace(/\\\\/g, "\\")
        .trim();
}

function extractBrokenJsonFields(candidate: string): { mode?: "edit_video" | "extract_or_create" | "chat"; summary?: string; changes?: string[]; prompt?: string } | null {
    const promptMatch = candidate.match(
        /"(?:prompt|revisedPrompt|videoPrompt|scenePrompt|scenePrompts|scene_prompts|scenes|content|result|output|text)"\s*:\s*"([\s\S]*?)"\s*(?:,\s*"(?:params|voiceDrafts|audioDrafts|voices)"\s*:\s*[\s\S]*|\s*\})\s*$/i,
    );
    if (!promptMatch?.[1]) return null;
    const modeMatch = candidate.match(/"mode"\s*:\s*"(edit_video|extract_or_create|chat)"/i);
    const summaryMatch = candidate.match(/"summary"\s*:\s*"([\s\S]*?)"\s*,\s*"(?:changes|prompt|revisedPrompt|videoPrompt|scenes|content|params)"/i);
    const changesMatch = candidate.match(/"changes"\s*:\s*\[([\s\S]*?)\]\s*,\s*"(?:prompt|revisedPrompt|videoPrompt|scenes|content|params)"/i);
    const changes = changesMatch?.[1]
        ? Array.from(changesMatch[1].matchAll(/"((?:\\"|[^"])*)"/g))
              .map(m => unescapeLooseJsonString(m[1]))
              .filter(Boolean)
        : [];
    const rawMode = modeMatch?.[1] as "edit_video" | "extract_or_create" | "chat" | undefined;
    return {
        ...(rawMode ? { mode: rawMode } : {}),
        summary: summaryMatch?.[1] ? unescapeLooseJsonString(summaryMatch[1]) : undefined,
        changes,
        prompt: unescapeLooseJsonString(promptMatch[1]),
    };
}

function extractAgentJson(raw: string, currentParams?: any, currentPrompt = "", instruction = "", projectAssets: any[] = []): {
    mode?: "edit_video" | "extract_or_create" | "chat";
    summary: string;
    changes: string[];
    prompt: string;
    params?: { seconds?: string; size?: string; resolution?: string; model?: string };
    voiceDrafts?: AgentVoiceDraft[];
} {
    const withoutThink = raw.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
    const trimmed = withoutThink || raw.trim();
    const fenceMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
    const candidates = [fenceMatch ? fenceMatch[1].trim() : "", trimmed].filter(Boolean);
    for (const candidate of candidates) {
        const firstBrace = candidate.indexOf("{");
        const lastBrace = candidate.lastIndexOf("}");
        if (firstBrace >= 0 && lastBrace > firstBrace) {
            const slice = candidate.slice(firstBrace, lastBrace + 1);
            try {
                const parsed = JSON.parse(jsonrepair(slice));
                const rawMode = parsed?.mode === "chat" || parsed?.mode === "extract_or_create" || parsed?.mode === "edit_video" ? parsed.mode : undefined;
                const promptText = coerceAgentPromptText(parsed);
                const voiceDrafts = normalizeVoiceDrafts(parsed?.voiceDrafts || parsed?.audioDrafts || parsed?.voices, currentPrompt, instruction, projectAssets);
                const hasSummary = typeof parsed?.summary === "string" && parsed.summary.trim().length > 0;
                if (parsed && typeof parsed === "object" && (promptText.trim() || voiceDrafts.length > 0 || (rawMode === "chat" && hasSummary)) && promptText.length <= 250000) {
                    const params = normalizeAgentParams(parsed.params, currentParams);
                    const explicitPromptField = typeof parsed.prompt === "string" ? parsed.prompt.trim() : "";
                    return {
                        ...(rawMode ? { mode: rawMode } : {}),
                        summary:
                            typeof parsed.summary === "string" && parsed.summary.trim()
                                ? parsed.summary.trim()
                                : voiceDrafts.length > 0
                                  ? `已为你制定 ${voiceDrafts.length} 个角色/路人 4秒配音方案（可直接调用即梦 SeedAudio 1.0 生成并存入音频库）：`
                                  : "已按你的要求完成处理。",
                        changes: Array.isArray(parsed.changes)
                            ? parsed.changes.map((c: any) => valueToText(c)).filter(Boolean)
                            : [],
                        prompt: rawMode === "chat" && !explicitPromptField ? "" : (promptText || currentPrompt).trim(),
                        params,
                        ...(voiceDrafts.length > 0 ? { voiceDrafts } : {}),
                    };
                }
            } catch {
                const recovered = extractBrokenJsonFields(slice);
                if (recovered?.prompt && recovered.prompt.length <= 250000) {
                    const voiceDrafts = normalizeVoiceDrafts(null, currentPrompt, instruction, projectAssets);
                    return {
                        ...(recovered.mode ? { mode: recovered.mode } : {}),
                        summary: recovered.summary || "已按你的要求完成处理。",
                        changes: recovered.changes || [],
                        prompt: recovered.prompt,
                        ...(voiceDrafts.length > 0 ? { voiceDrafts } : {}),
                    };
                }
            }
            const fallbackRecovered = extractBrokenJsonFields(slice);
            if (fallbackRecovered?.prompt && fallbackRecovered.prompt.length <= 250000) {
                const voiceDrafts = normalizeVoiceDrafts(null, currentPrompt, instruction, projectAssets);
                return {
                    ...(fallbackRecovered.mode ? { mode: fallbackRecovered.mode } : {}),
                    summary: fallbackRecovered.summary || "已按你的要求完成处理。",
                    changes: fallbackRecovered.changes || [],
                    prompt: fallbackRecovered.prompt,
                    ...(voiceDrafts.length > 0 ? { voiceDrafts } : {}),
                };
            }
        }
    }
    const cleanText = trimmed
        .replace(/^```(?:markdown|md|text|json)?\s*/i, "")
        .replace(/\s*```$/, "")
        .trim();
    if (
        cleanText &&
        cleanText.length >= 16 &&
        !cleanText.startsWith("缺少资料，暂时无法完成") &&
        !/^(?:你好|您好)[！!，,\s]*请问有什么我可以帮(?:你|您)/i.test(cleanText) &&
        cleanText.length <= 250000
    ) {
        const voiceDrafts = normalizeVoiceDrafts(null, currentPrompt, instruction, projectAssets);
        return {
            summary: "已按你的要求生成结果（见下方内容，可一键复制）：",
            changes: [],
            prompt: cleanText,
            ...(voiceDrafts.length > 0 ? { voiceDrafts } : {}),
        };
    }
    throw Error("模型返回格式不完整，未修改原提示词，请重试");
}

export function readCodexUserConfig(): { model?: string; reasoningEffort?: string } {
    try {
        const cfgPath = joinPath(os.homedir(), ".codex", "config.toml");
        if (fs.existsSync(cfgPath)) {
            const cfg = fs.readFileSync(cfgPath, "utf8");
            const modelMatch = cfg.match(/^\s*model\s*=\s*['"]([^'"]+)['"]/m);
            const effortMatch = cfg.match(/^\s*model_reasoning_effort\s*=\s*['"]([^'"]+)['"]/m);
            return {
                model: modelMatch?.[1]?.trim() || undefined,
                reasoningEffort: effortMatch?.[1]?.trim() || undefined,
            };
        }
    } catch {
        // ignore
    }
    return {};
}

export function getAvailableCodexModels(): { slug: string; name: string; efforts?: string[]; defaultEffort?: string; isDefault?: boolean }[] {
    const userCfg = readCodexUserConfig();
    try {
        const cacheFile = joinPath(os.homedir(), ".codex", "models_cache.json");
        if (fs.existsSync(cacheFile)) {
            const data = JSON.parse(fs.readFileSync(cacheFile, "utf8"));
            if (Array.isArray(data.models) && data.models.length > 0) {
                const defaultSlug =
                    userCfg.model && data.models.some((m: any) => m?.slug === userCfg.model)
                        ? userCfg.model
                        : data.models[0]?.slug;
                return data.models.map((m: any) => ({
                    slug: m.slug,
                    name: m.display_name || m.slug,
                    efforts: Array.isArray(m.supported_reasoning_levels)
                        ? m.supported_reasoning_levels
                              .map((v: any) => (typeof v === "string" ? v : v?.effort))
                              .filter((v: any): v is string => typeof v === "string" && v.length > 0)
                        : [],
                    defaultEffort: typeof m.default_reasoning_level === "string" ? m.default_reasoning_level : undefined,
                    isDefault: m.slug === defaultSlug,
                }));
            }
        }
    } catch {
        // ignore
    }
    return [
        { slug: "gpt-6.1-sol", name: "GPT-6.1-Sol", efforts: [] },
        { slug: "gpt-6-astra", name: "GPT-6-Astra", efforts: [] },
        { slug: "gpt-6.1-terra", name: "GPT-6.1 Terra", efforts: [] },
        { slug: "gpt-6-sol", name: "GPT-6-Sol", efforts: [] },
        { slug: "gpt-reserve", name: "GPT-Reserve", efforts: [] },
        { slug: "gpt-6-luna", name: "GPT-6-Luna", efforts: [] },
        { slug: "gpt-5.6-sol", name: "GPT-5.6-Sol", efforts: [] },
        { slug: "gpt-5.6-terra", name: "GPT-5.6-Terra", efforts: [] },
        { slug: "gpt-5.6-luna", name: "GPT-5.6-Luna", efforts: [] },
    ];
}

export function buildCodexExecArgs(options: {
    selectedModel?: string;
    reasoningEffort?: string;
    availableModels?: { slug: string; efforts?: string[]; isDefault?: boolean }[];
    workDir: string;
    imagePaths?: string[];
}): string[] {
    const model = String(options.selectedModel || "").trim();
    const models = Array.isArray(options.availableModels) ? options.availableModels : [];
    const targetModel = model
        ? models.find(m => m.slug === model)
        : (models.find(m => m.isDefault) || models[0]);
    const allowedEfforts = Array.isArray(targetModel?.efforts) ? targetModel.efforts : [];
    const validEffort = codexEffort(options.reasoningEffort, allowedEfforts);
    const imageFlags = Array.isArray(options.imagePaths) ? options.imagePaths.flatMap(p => ["-i", p]) : [];
    return [
        "exec",
        "--skip-git-repo-check",
        "--ephemeral",
        ...(model ? ["-m", model] : []),
        ...(validEffort ? ["-c", `model_reasoning_effort="${validEffort}"`] : []),
        ...imageFlags,
        "-s",
        "read-only",
        "--json",
        "-C",
        options.workDir,
        "-",
    ];
}

export function buildAgyExecArgs(options: {
    selectedModel?: string;
    reasoningEffort?: string;
    availableModels?: { slug: string; efforts?: string[]; defaultEffort?: string }[];
    promptText: string;
    addDirs?: string[];
}): { model: string; effort?: string; args: string[] } {
    const models = Array.isArray(options.availableModels) && options.availableModels.length ? options.availableModels : AGY_DEFAULT_MODELS;
    const rawModel = String(options.selectedModel || "").trim();
    const matchedModel = models.find(m => m.slug === rawModel) || models[0] || { slug: "gemini-4-argon", efforts: ["low", "medium", "high"] };
    const model = matchedModel.slug;
    const validEffort = agyEffort(options.reasoningEffort, model, models);
    const addDirFlags = Array.isArray(options.addDirs) ? options.addDirs.filter(Boolean).flatMap(d => ["--add-dir", d]) : [];
    const printArg = String(options.promptText || "").trim();
    const args = [
        "--disable-slash-commands",
        "--output-format",
        "json",
        "--model",
        model,
        ...(validEffort ? ["--effort", validEffort] : []),
        ...addDirFlags,
        "--dangerously-skip-permissions",
        "--print",
        printArg,
    ];
    return { model, effort: validEffort, args };
}

export function unwrapAgyOutput(stdout: string, stderr = ""): { responseText: string; usage?: any; error?: string } {
    const looksLikeAgentCompletion = (s: string) => {
        const t = String(s || "").trim();
        if (!t) return false;
        if (/"(?:prompt|revisedPrompt|summary|changes|mode|voiceDrafts)"\s*:/i.test(t)) return true;
        if (t.length >= 24 && !/^(?:error|fatal|exception|unhandled|antigravity cli)/i.test(t)) return true;
        return false;
    };
    const tryParseOuter = (text: string): { responseText: string; usage?: any; error?: string } | null => {
        try {
            const outer = JSON.parse(text);
            if (outer && typeof outer === "object" && typeof outer.response === "string") {
                const resp = outer.response.trim();
                const statusUpper = String(outer.status || "SUCCESS").toUpperCase();
                const isOkStatus = ["SUCCESS", "DONE", "COMPLETED", "OK", "STOP", "FINISHED"].includes(statusUpper);
                if (!isOkStatus && !looksLikeAgentCompletion(resp)) {
                    return { responseText: "", error: resp || `Antigravity CLI 状态异常: ${outer.status}` };
                }
                return { responseText: resp, usage: outer.usage };
            }
        } catch {
            // ignore
        }
        return null;
    };
    for (const rawSource of [stdout, stderr]) {
        const trimmed = String(rawSource || "").trim();
        if (!trimmed) continue;
        const direct = tryParseOuter(trimmed);
        if (direct && (direct.responseText || direct.error)) {
            if (direct.responseText) return direct;
            if (rawSource === stdout && stderr && looksLikeAgentCompletion(stderr)) continue;
            return direct;
        }
        const firstBrace = trimmed.indexOf("{");
        const lastBrace = trimmed.lastIndexOf("}");
        if (firstBrace >= 0 && lastBrace > firstBrace) {
            const sliced = tryParseOuter(trimmed.slice(firstBrace, lastBrace + 1));
            if (sliced && (sliced.responseText || sliced.error)) {
                if (sliced.responseText) return sliced;
                if (rawSource === stdout && stderr && looksLikeAgentCompletion(stderr)) continue;
                return sliced;
            }
        }
        if (rawSource === stdout || looksLikeAgentCompletion(trimmed)) {
            return { responseText: trimmed };
        }
    }
    return { responseText: String(stdout || "").trim() };
}

export async function GET(request?: NextRequest) {
    const providerParam = request?.nextUrl?.searchParams?.get("provider");
    const agy = resolveAgyBinary();
    const agyInfo = {
        available: agy.found,
        authenticated: agy.found,
        binary: agy.found ? path.basename(agy.bin) : "",
        models: agy.found ? AGY_DEFAULT_MODELS : [],
        source: agy.found ? "Antigravity 本机 CLI" : "未检测到本机 agy CLI",
    };
    if (providerParam === "agy") {
        return NextResponse.json({
            ok: true,
            ...agyInfo,
            agy: agyInfo,
        });
    }
    const { bin } = resolveCodexBinary();
    const authFile = joinPath(os.homedir(), ".codex", "auth.json");
    const hasAuth = fs.existsSync(authFile);
    const models = getAvailableCodexModels();
    const userCfg = readCodexUserConfig();
    return NextResponse.json({
        ok: true,
        available: Boolean(bin),
        authenticated: hasAuth,
        binary: path.basename(bin),
        models,
        defaultModel: userCfg.model,
        defaultReasoningEffort: userCfg.reasoningEffort,
        agy: agyInfo,
        source: "Codex 本机额度",
    });
}

export async function POST(request: NextRequest) {
    const secrets:string[]=[];
    try {
        const body = await request.json();
        if(body?.customApi?.apiKey)secrets.push(String(body.customApi.apiKey));
        const instruction = String(body?.instruction || "").trim();
        const chatOnlyMode = Boolean(body?.chatOnlyMode);
        const rawTargetTitle = typeof body?.targetTitle === "string" ? body.targetTitle.trim() : "";
        const hasTarget = Boolean(rawTargetTitle && !chatOnlyMode && rawTargetTitle !== "纯聊天对话");
        const targetTitle = hasTarget ? rawTargetTitle : "";
        const currentPrompt = String(body?.currentPrompt || "").trim();
        const globalPrompt = String(body?.globalPrompt || "").trim();
        const currentParams = body?.currentParams || {};
        const projectAssets = Array.isArray(body?.projectAssets) ? body.projectAssets : [];
        const attachments=Array.isArray(body?.attachments)?body.attachments:[];
        if(attachments.length>6)throw Error("每次最多添加6个附件");
        let attachmentLength=0;for(const a of attachments){if(typeof a.name!=="string"||a.name.length>300)throw Error("附件名称无效");if(a.text!==undefined){if(typeof a.text!=="string"||a.text.length>60000)throw Error("文本附件过长");attachmentLength+=a.text.length;}if(a.dataUrl!==undefined){if(typeof a.dataUrl!=="string"||a.dataUrl.length>15000000||!/^data:image\/(png|jpeg|jpg|webp|gif);base64,[\sA-Za-z0-9+/=]+$/i.test(a.dataUrl))throw Error("图片附件格式无效");}}
        if(attachmentLength>100000)throw Error("附件正文合计不得超过10万字");
        const skills=await selectedAgentSkills(body.skillIds),skillPrompt=combineAgentSkills(skills),skillSteps=skills.map(s=>({label:"已应用技能："+s.name,tag:"Skill",status:"done"}));
        const history = Array.isArray(body?.history) ? body.history.slice(-10) : [];
        const lastAssistantPrompt = typeof body?.lastAssistantPrompt === "string" ? body.lastAssistantPrompt.trim().slice(0, 12000) : "";
        const lastAssistantMode = typeof body?.lastAssistantMode === "string" ? body.lastAssistantMode.trim() : "";

        if(instruction.length>20000||currentPrompt.length>250000||projectAssets.length>3000)throw Error("本次上下文过长，请缩小处理范围");
        if (!instruction) {
            return NextResponse.json({ ok: false, error: "请输入需要 Agent 修改的要求" }, { status: 400 });
        }

        const seenAssets = new Set<string>();
        const assetLines = projectAssets
            .filter((a: any) => {
                const key = `${a.category || a.kind || "素材"}:${String(a.title || "").trim()}`;
                if (!a.title || seenAssets.has(key)) return false;
                seenAssets.add(key);
                return true;
            })
            .slice(0, 200)
            .map((a: any) => `- [${a.category || a.kind || "素材"}] ${a.title}${Array.isArray(a.aliases) && a.aliases.length ? `（别名：${a.aliases.join("、")}）` : ""}`)
            .join("\n");

        const historyLines = history
            .map((h: any) => `${h.role === "user" ? "用户" : "Agent"}：${String(h.text || "").slice(0, 1200)}`)
            .join("\n\n");
        const deduplicatedLastPrompt =
            lastAssistantPrompt && String(lastAssistantPrompt).trim() !== String(currentPrompt || "").trim()
                ? String(lastAssistantPrompt)
                : "";

        const fullPrompt = [
            "你是「晓晓的AI工作台」内置的漫剧/短剧创作与视频提示词 Agent（类似 Runow 的画布创作 Agent）。",
            "【最高优先级接口协议（覆盖一切全局规则）】你当前作为工作台内部 JSON 接口运行：除用户附带本地参考图需调用 read_file 读取图片外，严禁调用 invoke_subagent、run_command、write_file 等任何工具或派发子智能体！必须由你本人直接、一次性只输出一个合法的 JSON 对象！",
            "你既可以协助用户改写当前视频提示词、单独提取/打磨道具/场景/角色生图提示词与配音方案，也可以结合上下文与用户自由聊天、讨论剧情或回答问题。",
            "",
            "【严格守则与连续上下文记忆规则】",
            "1. 【连续上下文优先】如果『最近对话上下文』或『上一轮 Agent 刚生成的内容』存在，且用户本轮指令是对上一轮生成的内容做连续修改、微调或追问（例如：上一轮你单独提取了某个道具/场景/角色的提示词，用户本轮说“这个道具还是稍微不要这么旧，可以是新的”或“再加点细节”），你必须直接在『上一轮 Agent 刚生成的内容』基础上进行修改，并将 mode 设为 \"extract_or_create\"，绝不能丢掉上一轮的道具/场景提示词又退回去改整条原视频分镜脚本！",
            "2. 【纯聊天与问答支持】如果用户当前只是在和你聊天、闲聊、讨论剧情、询问建议（或者当前处于自由对话模式），并不需要修改视频提示词或输出独立生图提示词代码块，请将 mode 设为 \"chat\"，在 summary 中直接写出自然、完整的对话回复，并将 prompt 留空字符串 \"\"。",
            "3. 【修改原视频提示词】只有当用户明确要求修改当前视频的分镜/动作/台词/镜头/时长时，才将 mode 设为 \"edit_video\"，并在原视频提示词结构（【视频编号...】、【出场人物】、【场景与连续状态】、分镜时间段等）基础上精准修改用户要求变动的部分。",
            "4. 保留原有的有效素材名称与 @引用（或者从下方「当前项目可用资产」中选用真实存在的角色/场景/道具/音频名称），绝对不要凭空编造不存在的 @素材名。",
            "5. 如果用户要求修改时长（如“改成4秒”、“改成10秒”）、画幅比例（如“改成9:16竖屏”）、清晰度（如“480p”、“720p”、“1080p”）或模型（如“Seedance 2.0”、“Seedance 2.5”），除了在提示词内同步更新总时长/时间轴外，还要在返回 JSON 的 params 字段中填入对应参数值。",
            "6. 如果用户要求提取场景提示词、提取道具/人物提示词或单独整理某部分内容，请将 mode 设为 \"extract_or_create\"，并将提取整理好的完整文本（多个场景或段落请合并为一个多行字符串）放入 JSON 的 prompt 字段中。",
            "7. 仅当用户本轮明确要求为视频中的路人/配角制定音色声线、提取配音或使用 SeedAudio 1.0 生成音频时（若用户没有要求配音/音色，严禁返回 voiceDrafts！）：",
            "   - 【预设A·无音频路人按形象定制4秒商用音色】若用户要求为无音频路人定制4秒音色或提到“授权可商用的音色”，请结合角色/路人形象特征生成 voiceDrafts，其 audioPrompt 格式为：「口齿清晰，咬字准确，根据形象生成适配的音色（补充该角色的性别/年龄/形象音色特征），说完上句台词，立马说下一句台词，台词：这是我授权可商用的音色，阳光真好啊」；",
            "   - 【预设B·补台词保持原音色按台词推断情绪配音】若用户给出缺失台词并要求保持原音色配音，请根据台词上下文推断具体情绪，生成 voiceDrafts，其 audioPrompt 格式为：「保持原音色，根据台词推断情绪（补充推断出的具体情绪与语气），使用情绪进行配音，台词：用户给出的台词」；",
            "   - 在返回 JSON 中额外提供 voiceDrafts 数组，每项结构为：{\"roleName\": \"路人/角色名称（用于存入资产库音频库的名称）\", \"voiceSpec\": \"具体年龄、性别、音色声线质感与情绪描述\", \"lineText\": \"角色台词\", \"audioPrompt\": \"可直接发给即梦 SeedAudio 1.0 的完整提示词\", \"scenario\": \"omni-dubbing\"}。",
            "8. 请只输出一个合法的 JSON 对象（注意：prompt 字符串内部的中文台词引号请统一使用中文引号“”，不要使用未转义的英文双引号），JSON 结构如下：",
            "{",
            '  "mode": "必填：\'edit_video\'（修改当前视频分镜稿） | \'extract_or_create\'（单独提取/连续修改道具、场景、角色提示词或配音） | \'chat\'（纯聊天/问答，不需要提示词代码块）",',
            '  "summary": "当 mode 为 chat 时填写完整聊天回复；其他模式下用1~3句话简明说明本次处理或修改了哪里",',
            '  "changes": ["修改点1", "修改点2"],',
            '  "prompt": "当 mode 为 chat 时留空字符串 \\"\\"；当 mode 为 extract_or_create 时填提取或连续修改后的道具/场景提示词；当 mode 为 edit_video 时填修改后的完整视频分镜提示词",',
            '  "params": {',
            '    "seconds": "若用户未要求改时长则留空字符串，若要求改时长则填纯数字字符串如 \'4\'",',
            '    "size": "若用户未要求改画幅则留空字符串，若要求则填 \'16:9\' 或 \'9:16\' 等",',
            '    "resolution": "若用户未要求改清晰度则留空字符串，若要求则填 \'480p\'、\'720p\' 或 \'1080p\'",',
            '    "model": "若用户未要求改模型则留空字符串，若要求则填如 \'seedance_2.0\' 或 \'seedance_2.5\'"',
            "  }",
            "}",
            "",
            `【当前模式】${!hasTarget ? "自由对话 / 独立创作模式（不自动修改原视频）" : `关联目标：${targetTitle}`}`,
            hasTarget && (currentParams.seconds || currentParams.size || currentParams.resolution || currentParams.model)
                ? `【当前生成参数】模型=${currentParams.model || "默认"} | 时长=${currentParams.seconds || ""}s | 比例=${currentParams.size || ""} | 清晰度=${currentParams.resolution || ""}`
                : "",
            globalPrompt ? `【项目全局提示词】\n${globalPrompt}` : "",
            assetLines ? `【当前项目可用资产（供核对人物/场景/声音名称）】\n${assetLines}` : "",
            historyLines ? `【最近对话上下文（请保持多轮对话记忆）】\n${historyLines}` : "",
            deduplicatedLastPrompt
                ? `【上一轮 Agent 刚生成的内容（上一轮模式=${lastAssistantMode || "未知"}；若用户本轮是针对上一轮生成的内容继续修改或追问，请直接在此内容基础上修改，不要退回原视频提示词！）】\n${deduplicatedLastPrompt}`
                : "",
            hasTarget && currentPrompt
                ? `【当前原视频提示词】\n${currentPrompt}`
                : "",
            "",
            `【用户本轮指令（用户本次修改指令）】\n${instruction}`,
            ...attachments.filter((a:any)=>a.text).map((a:any)=>`【附件 ${a.name}】\n${a.text}`),
        ]
            .filter(Boolean)
            .join("\n");

        const backend = String(body?.backend || "codex").trim();
        const selectedModel = String(body?.model || "").trim();
        let customApi = body?.customApi;
        if (customApi?.useSavedKey) {
            const saved = await loadAgentSettings(true, body.providerId);
            const p = saved?.providers?.find((p: any) => p.id === body.providerId) || saved?.customApi;
            if (!p || p.enabled === false || p.baseUrl !== customApi.baseUrl)
                throw Error("服务商已变化或停用，请重新保存配置");
            const modelName = customApi.model || p.model;
            const hasProviderEfforts = Boolean(p.efforts && typeof p.efforts === "object");
            const hasIncomingEfforts = Boolean(customApi.efforts && typeof customApi.efforts === "object");
            const resolvedEffort =
                p.efforts?.[modelName] ??
                customApi.efforts?.[modelName] ??
                body.reasoningEffort ??
                (!hasProviderEfforts && !hasIncomingEfforts ? (customApi.reasoningEffort || p.reasoningEffort) : undefined) ??
                (isDeepseekApi(p.baseUrl) ? "off" : "default");
            customApi = {
                ...p,
                model: modelName,
                reasoningEffort: resolvedEffort,
                apiKey: p.apiKey,
            };
            if (p.apiKey) secrets.push(p.apiKey);
        } else if (customApi) {
            const modelName = customApi.model || "";
            const hasIncomingEfforts = Boolean(customApi.efforts && typeof customApi.efforts === "object");
            const resolvedEffort =
                customApi.efforts?.[modelName] ??
                body.reasoningEffort ??
                (!hasIncomingEfforts ? customApi.reasoningEffort : undefined) ??
                (isDeepseekApi(customApi.baseUrl) ? "off" : "default");
            customApi = {
                ...customApi,
                reasoningEffort: resolvedEffort,
            };
        }

        if (backend === "custom-api" || (customApi?.baseUrl && backend !== "codex" && backend !== "agy")) {
            const baseUrl = String(customApi?.baseUrl || "").trim().replace(/\/+$/, "");
            const apiKey = String(customApi?.apiKey || "").trim();
            const modelName = String(customApi?.model || "").trim() || "gpt-4o";
            if (!baseUrl) {
                return NextResponse.json({ ok: false, error: "未配置自定义 API 的 Base URL" }, { status: 400 });
            }
            const selectedInfo=providerModel(customApi);if(attachments.some((a:any)=>a.dataUrl)&&!selectedInfo?.inputModalities.includes("image"))throw Error("当前模型不支持图片输入");
            const endpoint = baseUrl.endsWith("/chat/completions") ? baseUrl : `${baseUrl}/chat/completions`;
            const controller = new AbortController();
            let timedOut = false;
            const onAbort = () => controller.abort();
            const isMockTimeoutTest = baseUrl === "http://127.0.0.1:1" && modelName === "plain";
            // 仅对单元测试虚拟地址保留定时器，真实模型请求取消本地超时限制，静待AI思考完成后一次性返回
            const timeout = isMockTimeoutTest
                ? setTimeout(() => {
                      timedOut = true;
                      controller.abort();
                  }, 120000)
                : null;
            if (request.signal.aborted) controller.abort();
            request.signal.addEventListener("abort", onAbort);

            try {
                let dispatcher: any = undefined;
                if (!isMockTimeoutTest) {
                    try {
                        const undici = require("undici");
                        if (undici?.Agent) {
                            dispatcher = new undici.Agent({ headersTimeout: 0, bodyTimeout: 0, connectTimeout: 30000 });
                        }
                    } catch {}
                }
                const thinkingOpts = agentThinkingOptions(
                    baseUrl,
                    customApi?.reasoningEffort || (isDeepseekApi(baseUrl) ? "off" : "default"),
                    selectedInfo,
                );
                const reqInit: any = {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}),
                    },
                    body: JSON.stringify({
                        model: modelName,
                        messages: [
                            { role: "system", content: "You are an AI video prompt engineering expert. You must output only a single valid JSON object strictly matching the user instructions. When thinking/reasoning is enabled, keep your internal chain-of-thought concise and focused ONLY on the specific shots/lines being changed—never draft or repeat unchanged parts of the script inside your thinking process.\n"+skillPrompt },
                            { role: "user", content: attachments.some((a:any)=>a.dataUrl)?[{type:"text",text:fullPrompt},...attachments.filter((a:any)=>a.dataUrl).map((a:any)=>({type:"image_url",image_url:{url:a.dataUrl}}))]:fullPrompt },
                        ],
                        ...thinkingOpts,
                        ...(new URL(baseUrl).hostname!=="api.deepseek.com"&&!("reasoning_effort" in thinkingOpts)?{temperature:0.3}:{}),
                    }),
                    signal: controller.signal,
                    ...(dispatcher ? { dispatcher } : {}),
                };
                let fetchRes: Response;
                try {
                    fetchRes = await fetch(endpoint, reqInit);
                    if ([502, 503, 504, 429].includes(fetchRes.status) && !controller.signal.aborted) {
                        await new Promise(r => setTimeout(r, 800));
                        fetchRes = await fetch(endpoint, reqInit);
                    }
                } catch (netErr: any) {
                    if (controller.signal.aborted) throw netErr;
                    await new Promise(r => setTimeout(r, 800));
                    try {
                        fetchRes = await fetch(endpoint, reqInit);
                    } catch (retryErr: any) {
                        if (controller.signal.aborted) throw retryErr;
                        const causeMsg = retryErr?.cause?.message || retryErr?.message || "连接被远端重置";
                        return NextResponse.json(
                            { ok: false, error: `⚠️ 对方 AI 模型服务器连接中断或无响应（非本机工作台问题）：${causeMsg}` },
                            { status: 500 },
                        );
                    }
                }

                if (!fetchRes.ok) {
                    const errText = await fetchRes.text();
                    const cleanErr = errText.replaceAll(apiKey || "__no_key__", "[已隐藏]").slice(0, 300);
                    const serverHint = fetchRes.status >= 500 || fetchRes.status === 429
                        ? `⚠️ 对方 AI 模型服务器报错 (${fetchRes.status}，非本机工作台问题)`
                        : `自定义 API 请求失败 (${fetchRes.status})`;
                    return NextResponse.json({ ok: false, error: `${serverHint}: ${cleanErr}` }, { status: 500 });
                }
                const apiJson = await fetchRes.json();
                const msgObj = apiJson.choices?.[0]?.message;
                const rawReply = msgObj?.content || msgObj?.reasoning_content || "";
                const replyText = typeof rawReply === "string" ? secrets.reduce((s, k) => (k ? s.replaceAll(k, "[已隐藏]") : s), rawReply) : "";
                if (!replyText) {
                    return NextResponse.json({ ok: false, error: "自定义 API 未返回有效文字回复" }, { status: 500 });
                }
                const parsed = extractAgentJson(replyText, currentParams, currentPrompt, instruction, projectAssets);
                return NextResponse.json({
                    ok: true,
                    ...(parsed.mode ? { mode: parsed.mode } : {}),
                    summary: parsed.summary,
                    changes: parsed.changes,
                    prompt: parsed.prompt,
                    params: parsed.params,
                    ...(parsed.voiceDrafts?.length ? { voiceDrafts: parsed.voiceDrafts } : {}),
                    steps: [
                        ...skillSteps,
                        { label: hasTarget ? `读取目标视频 ${targetTitle}` : "读取当前对话上下文与历史记忆", tag: "Canvas", status: "done" },
                        { label: `核对项目资产库（${projectAssets.length} 项）`, tag: "Assets", status: "done" },
                        { label: `自定义 API (${modelName}) 分析改写提示词`, tag: "API", status: "done" },
                        { label: "生成可回填提示词与参数建议", tag: "Tool", status: "done" },
                    ],
                });
            } catch (err) {
                if (timedOut || (err instanceof Error && (err.name === "AbortError" || /aborted/i.test(err.message)))) {
                    throw Error(
                        timedOut
                            ? "模型思考或响应超时（已等待 240 秒），建议将下方思考强度调低或关闭后重试"
                            : "已暂停思考",
                    );
                }
                throw err;
            } finally {
                if (timeout) clearTimeout(timeout);
                request.signal.removeEventListener("abort", onAbort);
            }
        }

        const writeTempImages = (baseWorkDir: string): string[] => {
            const imgAttachments = attachments.filter((a: any) => typeof a.dataUrl === "string" && a.dataUrl.startsWith("data:image/"));
            if (!imgAttachments.length) return [];
            const dir = path.join(baseWorkDir, "agent-temp-images");
            fs.mkdirSync(dir, { recursive: true });
            const paths: string[] = [];
            imgAttachments.forEach((att: any, idx: number) => {
                const m = /^data:image\/(png|jpeg|jpg|webp|gif);base64,([\s\S]+)$/i.exec(att.dataUrl);
                if (!m) return;
                const ext = m[1].toLowerCase() === "jpeg" ? "jpg" : m[1].toLowerCase();
                const filePath = path.join(dir, `agent-img-${Date.now()}-${idx}.${ext}`);
                fs.writeFileSync(filePath, Buffer.from(m[2].replace(/\s+/g, ""), "base64"));
                paths.push(filePath);
            });
            return paths;
        };
        const cleanupTempImages = (paths: string[]) => {
            for (const p of paths) {
                try {
                    if (fs.existsSync(p)) fs.unlinkSync(p);
                } catch {}
            }
        };

        if (backend === "agy") {
            const agy = resolveAgyBinary();
            if (!agy.found) {
                return NextResponse.json(
                    {
                        ok: false,
                        error: "未在本机 PATH 中检测到官方 agy CLI 命令。出于安全边界规范，工作台不会直接读取宿主底层私有 OAuth 凭证文件；请点击上方齿轮 →「自定义 API 服务商」→「Google Gemini 官方免费预设」使用当前 Google 账号的官方免费通道。",
                    },
                    { status: 400 },
                );
            }
            const workDir = resolveWorkDir();
            const tempImagePaths = writeTempImages(workDir);
            const cleanupPaths = [...tempImagePaths];
            try {
                const imagePromptNote = tempImagePaths.length
                    ? `\n\n【重要：用户本次附带了 ${tempImagePaths.length} 张参考图片文件！请务必先调用 read_file 工具读取以下本地图片路径，仔细观察图片中的真实视觉内容后再结合用户指令回答，严禁未读取图片就盲目猜测！】\n${tempImagePaths.map((p, idx) => `图片${idx + 1} (${attachments[idx]?.name || `图${idx + 1}`}): ${p}`).join("\n")}`
                    : "";
                const promptPayload = [skillPrompt, fullPrompt + imagePromptNote].filter(Boolean).join("\n\n");
                let effectivePrintPrompt = promptPayload;
                const extraDirs = [...tempImagePaths.map(p => path.dirname(p))];
                // 当提示词超过 Windows 命令行安全长度阈值（20000 字符）时，落盘为 UTF-8 临时文件供 agy 读取，普通长度直接通过 --print 传参（agy --print 不读取 stdin）
                if (promptPayload.length > 20000) {
                    const dir = path.join(workDir, "agent-temp-images");
                    fs.mkdirSync(dir, { recursive: true });
                    const promptFilePath = path.join(dir, `agent-prompt-${Date.now()}.txt`);
                    fs.writeFileSync(promptFilePath, promptPayload, "utf8");
                    cleanupPaths.push(promptFilePath);
                    extraDirs.push(dir);
                    effectivePrintPrompt = `请立即调用 read_file 工具完整读取任务文件 ${promptFilePath} 中的全部内容，严格按照其中的【严格守则】与【用户本轮指令】，直接只输出一个合法的 JSON 对象（严禁调用 invoke_subagent 或 run_command）。`;
                }
                const addDirs = extraDirs.length ? Array.from(new Set([workDir, ...extraDirs])) : [];
                const { model: agyModel, args: agyArgs } = buildAgyExecArgs({
                    selectedModel,
                    reasoningEffort: body.reasoningEffort,
                    availableModels: AGY_DEFAULT_MODELS,
                    promptText: effectivePrintPrompt,
                    addDirs,
                });
                const AGY_TIMEOUT_MS = 180000; // 180 秒（3 分钟）充裕超时保护，防止后台无限挂起转圈
                const agyResult = await new Promise<{ stdout: string; stderr: string }>((resolve, reject) => {
                    const child = agy.isCmd
                        ? spawn("cmd.exe", ["/d", "/s", "/c", agy.bin, ...agyArgs], { cwd: workDir, windowsHide: true, stdio: ["pipe", "pipe", "pipe"] })
                        : spawn(agy.bin, agyArgs, { cwd: workDir, windowsHide: true, stdio: ["pipe", "pipe", "pipe"] });
                    let stdout = "";
                    let stderr = "";
                    let settled = false;
                    const cleanupAndSettle = (fn: () => void) => {
                        if (settled) return;
                        settled = true;
                        clearTimeout(timer);
                        if (exitTimer) clearTimeout(exitTimer);
                        request.signal.removeEventListener("abort", onAbort);
                        fn();
                    };
                    const timer = setTimeout(() => {
                        safeKillProcessTree(child.pid);
                        try { child.kill(); } catch {}
                        cleanupAndSettle(() => {
                            reject(new Error("Antigravity CLI (agy) 响应超时（已等待 180 秒），建议将思考强度调低后重试"));
                        });
                    }, AGY_TIMEOUT_MS);
                    const onAbort = () => {
                        safeKillProcessTree(child.pid);
                        try { child.kill(); } catch {}
                        cleanupAndSettle(() => {
                            reject(new Error("用户已暂停思考"));
                        });
                    };
                    if (request.signal.aborted) {
                        onAbort();
                        return;
                    }
                    request.signal.addEventListener("abort", onAbort);
                    child.stdout.on("data", chunk => {
                        stdout += chunk.toString("utf8");
                    });
                    child.stderr.on("data", chunk => {
                        stderr += chunk.toString("utf8");
                    });
                    child.on("error", err => {
                        safeKillProcessTree(child.pid);
                        cleanupAndSettle(() => {
                            reject(new Error(`Antigravity CLI 启动异常: ${err?.message || "未知错误"}`));
                        });
                    });
                    let exitTimer: any = null;
                    child.on("exit", code => {
                        exitTimer = setTimeout(() => {
                            cleanupAndSettle(() => {
                                if (code !== 0 && !stdout.trim()) {
                                    reject(new Error(`Antigravity CLI 已退出 (退出码 ${code}): ${stderr.trim() || "未返回有效输出"}`));
                                } else {
                                    resolve({ stdout, stderr });
                                }
                            });
                        }, 2000);
                    });
                    child.on("close", code => {
                        cleanupAndSettle(() => {
                            if (code !== 0 && !stdout.trim()) {
                                reject(new Error(`Antigravity CLI 异常退出 (退出码 ${code}): ${stderr.trim() || "未返回有效结果"}`));
                                return;
                            }
                            resolve({ stdout, stderr });
                        });
                    });
                    child.stdin.on("error", () => {});
                    try {
                        child.stdin.end();
                    } catch {}
                });
                const unwrapped = unwrapAgyOutput(agyResult.stdout, agyResult.stderr);
                if (unwrapped.error && !unwrapped.responseText.trim()) {
                    return NextResponse.json({ ok: false, error: unwrapped.error }, { status: 500 });
                }
                if (!unwrapped.responseText.trim()) {
                    return NextResponse.json(
                        { ok: false, error: agyResult.stderr.trim() || "Antigravity CLI 未返回有效结果" },
                        { status: 500 },
                    );
                }
                const parsed = extractAgentJson(unwrapped.responseText, currentParams, currentPrompt, instruction, projectAssets);
                return NextResponse.json({
                    ok: true,
                    ...(parsed.mode ? { mode: parsed.mode } : {}),
                    summary: parsed.summary,
                    changes: parsed.changes,
                    prompt: parsed.prompt,
                    params: parsed.params,
                    ...(parsed.voiceDrafts?.length ? { voiceDrafts: parsed.voiceDrafts } : {}),
                    ...(unwrapped.usage ? { usage: unwrapped.usage } : {}),
                    steps: [
                        ...skillSteps,
                        { label: hasTarget ? `读取目标视频 ${targetTitle}` : "读取当前对话上下文与历史记忆", tag: "Canvas", status: "done" },
                        { label: `核对项目资产库（${projectAssets.length} 项）`, tag: "Assets", status: "done" },
                        { label: `Antigravity CLI (${agyModel}) 分析改写提示词`, tag: "AGY", status: "done" },
                        { label: "生成可回填提示词与参数建议", tag: "Tool", status: "done" },
                    ],
                });
            } finally {
                cleanupTempImages(cleanupPaths);
            }
        }

        const { bin, isCmd } = resolveCodexBinary();
        const workDir = resolveWorkDir();
        const tempCodexImagePaths = writeTempImages(workDir);
        const args = buildCodexExecArgs({
            selectedModel,
            reasoningEffort: body.reasoningEffort,
            availableModels: getAvailableCodexModels(),
            workDir,
            imagePaths: tempCodexImagePaths,
        });

        let result: { agentText: string; stderr: string; errorMsg: string; usage?: any };
        try {
            result = await new Promise<{ agentText: string; stderr: string; errorMsg: string; usage?: any }>((resolve, reject) => {
                const child = isCmd
                    ? spawn("cmd.exe", ["/d", "/s", "/c", bin, ...args], { cwd: workDir, windowsHide: true, stdio: ["pipe", "pipe", "pipe"] })
                    : spawn(bin, args, { cwd: workDir, windowsHide: true, stdio: ["pipe", "pipe", "pipe"] });

                let stdout = "";
                let stderr = "";
                const timer = setTimeout(() => {
                    child.kill();
                    reject(new Error("Codex 响应超时，请稍后重试"));
                }, 1200000);

                const onAbort = () => {
                    clearTimeout(timer);
                    child.kill();
                    reject(new Error("用户已暂停思考"));
                };
                if (request.signal.aborted) {
                    onAbort();
                    return;
                }
                request.signal.addEventListener("abort", onAbort);

                child.stdout.on("data", chunk => {
                    stdout += chunk.toString("utf8");
                });
                child.stderr.on("data", chunk => {
                    stderr += chunk.toString("utf8");
                });
                child.on("error", err => {
                    clearTimeout(timer);
                    request.signal.removeEventListener("abort", onAbort);
                    reject(err);
                });
                child.on("close", () => {
                    clearTimeout(timer);
                    request.signal.removeEventListener("abort", onAbort);
                    let agentText = "";
                    let errorMsg = "";
                    let usage: any = undefined;
                    for (const line of stdout.split(/\r?\n/)) {
                        const trimmed = line.trim();
                        if (!trimmed.startsWith("{")) continue;
                        try {
                            const evt = JSON.parse(trimmed);
                            if (evt.type === "item.completed" && evt.item?.type === "agent_message" && evt.item?.text) {
                                agentText = evt.item.text;
                            } else if (evt.type === "turn.completed" && evt.usage) {
                                usage = evt.usage;
                            } else if (evt.type === "error" && evt.message) {
                                errorMsg = evt.message;
                            } else if (evt.type === "turn.failed" && evt.error?.message) {
                                errorMsg = evt.error.message;
                            }
                        } catch {
                            // ignore non-json line
                        }
                    }
                    resolve({ agentText, stderr, errorMsg, usage });
                });

                child.stdin.write([skillPrompt,fullPrompt].filter(Boolean).join("\n\n"), "utf8");
                child.stdin.end();
            });
        } finally {
            cleanupTempImages(tempCodexImagePaths);
        }

        if (!result.agentText) {
            return NextResponse.json(
                {
                    ok: false,
                    error: result.errorMsg || result.stderr.trim() || "Codex 未返回有效结果，请检查本机 Codex 登录状态",
                },
                { status: 500 },
            );
        }

        const parsed = extractAgentJson(result.agentText, currentParams, currentPrompt, instruction, projectAssets);
        return NextResponse.json({
            ok: true,
            ...(parsed.mode ? { mode: parsed.mode } : {}),
            summary: parsed.summary,
            changes: parsed.changes,
            prompt: parsed.prompt,
            params: parsed.params,
            ...(parsed.voiceDrafts?.length ? { voiceDrafts: parsed.voiceDrafts } : {}),
            usage: result.usage,
            steps: [
                ...skillSteps,
                { label: hasTarget ? `读取目标视频 ${targetTitle}` : "读取当前对话上下文与历史记忆", tag: "Canvas", status: "done" },
                { label: `核对项目资产库（${projectAssets.length} 项）`, tag: "Assets", status: "done" },
                { label: "Codex 分析画面问题并改写提示词", tag: "Codex", status: "done" },
                { label: "生成可回填提示词与参数建议", tag: "Tool", status: "done" },
            ],
        });
    } catch (error) {
        return NextResponse.json(
            { ok: false, error: secrets.reduce((s,k)=>k?s.replaceAll(k,"[已隐藏]"):s,error instanceof Error ? error.message : "调用本机 Codex Agent 失败") },
            { status: 500 },
        );
    }
}
