"use client";
import { useState } from "react";
import { App, Button, Checkbox, Input, InputNumber, Modal, Popover, Select, Switch, Tabs, Tag, Tooltip } from "antd";
import { Check, Pencil, Plus, RefreshCw, Search, Settings, Trash2 } from "lucide-react";
import {
    AGY_DEFAULT_MODELS,
    effortLabel,
    normalizeAgentModels,
    normalizeAgentProvider,
    resolveAgentModel,
    sortReasoningEfforts,
    type AgentSettings,
    type AgentProvider,
    type AgentModelOverride,
} from "@/lib/agent-models";

export function AgentProviderSettings({
    settings,
    models,
    onSave,
    onCancel,
}: {
    settings: AgentSettings;
    models: { slug: string; name: string }[];
    onSave: (s: AgentSettings) => void;
    onCancel: () => void;
}) {
    const { message } = App.useApp();
    const legacy = settings.customApi;
    const [value, setValue] = useState<AgentSettings>({
        ...settings,
        providers: settings.providers?.length
            ? settings.providers.map(normalizeAgentProvider)
            : [
                  {
                      id: "legacy",
                      name: "DeepSeek",
                      enabled: true,
                      baseUrl: legacy?.baseUrl || "https://api.deepseek.com",
                      apiKey: legacy?.apiKey || "",
                      model: legacy?.model || "deepseek-flash",
                      ...legacy,
                      modelDetails: Array.isArray(legacy?.modelDetails) ? legacy.modelDetails : [],
                  } as AgentProvider,
              ],
        activeProviderId: settings.activeProviderId || settings.providers?.[0]?.id || "legacy",
    });
    const [saving, setSaving] = useState(false);
    const [syncing, setSyncing] = useState(false);
    const [search, setSearch] = useState("");
    const [override, setOverride] = useState<{ id: string; value: AgentModelOverride } | null>(null);

    const p = value.providers!.find(item => item.id === value.activeProviderId) || value.providers![0];
    const patch = (next: Partial<AgentProvider>) =>
        setValue(v => ({
            ...v,
            providers: v.providers!.map(a => (a.id === p.id ? { ...a, ...next } : a)),
        }));

    const sync = async (detect = false) => {
        if (detect && (value.provider === "codex" || value.provider === "agy")) {
            setSyncing(true);
            try {
                const r = await fetch(`/api/codex-agent?provider=${value.provider}`);
                const d = await r.json();
                if (d.available && d.authenticated) {
                    message.success(
                        value.provider === "agy"
                            ? `本机 Antigravity CLI 连接正常（模型：${value.agyModel || "gemini-4-argon"}）`
                            : "本机 Codex CLI 连接与授权有效",
                    );
                } else {
                    message.warning(
                        value.provider === "agy"
                            ? "未在系统 PATH 中检测到公开的 agy 命令行程序（出于安全规范工作台不直接读取宿主底层私有凭证文件）；建议切到右侧「自定义 API 服务商」使用已配好的 DeepSeek-V4-Pro 或 Gemini 官方预设。"
                            : d.source || "未检测到本机 CLI 授权",
                    );
                }
            } catch (e) {
                message.error(e instanceof Error ? e.message : "本机 CLI 状态检查失败");
            } finally {
                setSyncing(false);
            }
            return;
        }
        const origin = p;
        setSyncing(true);
        try {
            const r = await fetch("/api/codex-agent/test", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ customApi: p, providerId: p.id }),
            });
            const d = await r.json();
            if (!d.connected && !d.modelDetails?.length) throw Error(d.error || "连接检查失败");
            if (!detect) {
                setValue(v => ({
                    ...v,
                    providers: v.providers!.map(a =>
                        a.id === origin.id && a.baseUrl === origin.baseUrl && a.apiKey === origin.apiKey
                            ? {
                                  ...a,
                                  modelDetails: d.modelDetails,
                                  modelIds: a.modelIds ?? d.models,
                                  model: a.model || d.models?.[0] || "",
                              }
                            : a,
                    ),
                }));
                message.success("已同步 " + d.modelDetails.length + " 个模型");
            } else {
                message.success("服务商连接及授权有效，未调用生成");
            }
        } catch (e) {
            message.error(e instanceof Error ? e.message : "连接检查失败");
        } finally {
            setSyncing(false);
        }
    };

    const save = async () => {
        setSaving(true);
        try {
            const r = await fetch("/api/codex-agent/settings", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(value),
            });
            const d = await r.json();
            if (!d.ok) throw Error(d.error);
            onSave(d.settings);
            message.success("已更新 Agent 模型配置");
        } catch (e) {
            message.error(e instanceof Error ? e.message : "保存失败");
        } finally {
            setSaving(false);
        }
    };

    const included = p.modelIds ?? p.modelDetails.map(m => m.id);
    const items = p.modelDetails.filter(m => (m.name + " " + m.id).toLowerCase().includes(search.toLowerCase()));
    const previewEndpoint = `${(p.baseUrl || "https://api.deepseek.com").replace(/\/+$/, "")}/chat/completions`;

    return (
        <>
            <Modal
                title="Agent 模型与接口配置"
                open
                onCancel={onCancel}
                width={720}
                footer={
                    <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="text-xs text-muted-foreground">
                            当前生效：{value.provider === "codex" ? `本机 Codex (${value.codexModel || "自动"})` : value.provider === "agy" ? `本机 Antigravity CLI (${value.agyModel || "gemini-4-argon"})` : `${p.name} · ${p.model || "未选模型"}`}
                        </span>
                        <div className="flex flex-wrap gap-2">
                            <Button aria-label="测试已保存的 Agent 连接" onClick={() => void sync(true)} loading={syncing}>
                                测试连接
                            </Button>
                            <Button aria-label="取消 Agent 模型设置" onClick={onCancel}>
                                取消
                            </Button>
                            <Button aria-label="保存 Agent 模型配置" type="primary" onClick={() => void save()} loading={saving}>
                                保存配置
                            </Button>
                        </div>
                    </div>
                }
            >
                <Tabs
                    activeKey={value.provider}
                    onChange={provider => setValue(v => ({ ...v, provider: provider as "custom" | "codex" | "agy" }))}
                    items={[
                        {
                            key: "codex",
                            label: "本机 Codex 额度",
                            children: (
                                <div className="space-y-2 py-2">
                                    <label className="block text-xs font-medium">选择本机 Codex 模型</label>
                                    <Select
                                        aria-label="选择 Codex 模型"
                                        className="w-full"
                                        value={value.codexModel || ""}
                                        options={[
                                            { value: "", label: "自动（跟随本机 Codex 默认配置）" },
                                            ...models.map(m => ({ value: m.slug, label: m.name })),
                                        ]}
                                        onChange={codexModel => setValue(v => ({ ...v, codexModel }))}
                                    />
                                </div>
                            ),
                        },
                        {
                            key: "agy",
                            label: "Antigravity 本机 CLI",
                            children: (
                                <div className="space-y-2.5 py-2">
                                    <label className="block text-xs font-medium">选择本机 Antigravity CLI (agy) 模型</label>
                                    <Select
                                        aria-label="选择 Antigravity 模型"
                                        className="w-full"
                                        value={AGY_DEFAULT_MODELS.some(m => m.slug === value.agyModel) ? value.agyModel! : "gemini-4-argon"}
                                        options={AGY_DEFAULT_MODELS.map(m => ({
                                            value: m.slug,
                                            label: `${m.name}${m.efforts.length ? `（支持思考档位：${m.efforts.map(effortLabel).join("/")}）` : "（仅默认思考档位）"}`,
                                        }))}
                                        onChange={agyModel => setValue(v => ({ ...v, agyModel }))}
                                    />
                                    <p className="text-[11px] leading-relaxed text-muted-foreground">
                                        通过本机已安装的官方 <code>agy</code> 命令行子进程调用（<code>--model</code> 与 <code>--effort</code> 实时传参，不直接读取宿主底层私有 OAuth 文件）；各模型思考档位独立保存。
                                    </p>
                                </div>
                            ),
                        },
                        {
                            key: "custom",
                            label: "自定义 API 服务商",
                            children: (
                                <div className="space-y-4">
                                    {/* Top Provider Bar (Clean single bar without duplicate provider name input below) */}
                                    <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-border bg-secondary/40 p-2.5">
                                        <div className="flex flex-1 flex-wrap items-center gap-2">
                                            <Select
                                                aria-label="选择 Agent 服务商"
                                                className="min-w-44"
                                                value={p.id}
                                                options={value.providers!.map(a => ({
                                                    value: a.id,
                                                    label: a.name + (a.enabled ? "" : " · 已停用"),
                                                }))}
                                                onChange={activeProviderId => setValue(v => ({ ...v, activeProviderId }))}
                                            />
                                            <Popover
                                                trigger="click"
                                                title="修改服务商显示名称"
                                                content={
                                                    <Input
                                                        aria-label="Agent 服务商名称"
                                                        value={p.name}
                                                        onChange={e => patch({ name: e.target.value })}
                                                        placeholder="例如：DeepSeek / 硅基流动"
                                                    />
                                                }
                                            >
                                                <Button size="small" icon={<Pencil size={13} />} title="重命名服务商" />
                                            </Popover>
                                            <Button
                                                size="small"
                                                aria-label="新增 Agent 服务商"
                                                icon={<Plus size={13} />}
                                                onClick={() => {
                                                    const id = crypto.randomUUID();
                                                    setValue(v => ({
                                                        ...v,
                                                        activeProviderId: id,
                                                        providers: [
                                                            ...v.providers!,
                                                            {
                                                                id,
                                                                name: "新服务商",
                                                                enabled: true,
                                                                baseUrl: "http://127.0.0.1:8317/v1",
                                                                apiKey: "",
                                                                model: "",
                                                                modelDetails: [],
                                                            },
                                                        ],
                                                    }));
                                                }}
                                            >
                                                新增服务商
                                            </Button>
                                            <Button
                                                size="small"
                                                aria-label="使用 DeepSeek 预设"
                                                onClick={() =>
                                                    patch({
                                                        name: "DeepSeek",
                                                        baseUrl: "https://api.deepseek.com",
                                                        apiKey: p.baseUrl === "https://api.deepseek.com" ? p.apiKey : "",
                                                        hasKey: p.baseUrl === "https://api.deepseek.com" && p.hasKey,
                                                        model: "deepseek-flash",
                                                        modelDetails: [],
                                                        modelIds: undefined,
                                                        modelOverrides: {},
                                                    })
                                                }
                                            >
                                                DeepSeek 官方预设
                                            </Button>
                                            <Button
                                                size="small"
                                                aria-label="使用 Google Gemini 官方免费预设"
                                                onClick={() => {
                                                    const geminiUrl = "https://generativelanguage.googleapis.com/v1beta/openai";
                                                    const geminiModels = normalizeAgentModels([
                                                        { id: "gemini-4-argon", name: "Gemini 4 Argon", context_window: 1048576, max_output_tokens: 65536 },
                                                        { id: "gemini-2.5-pro", name: "Gemini 2.5 Pro", context_window: 1048576, max_output_tokens: 65536 },
                                                        { id: "gemini-2.5-flash", name: "Gemini 2.5 Flash", context_window: 1048576, max_output_tokens: 65536 },
                                                    ]);
                                                    patch({
                                                        name: "Google Gemini",
                                                        baseUrl: geminiUrl,
                                                        apiKey: p.baseUrl === geminiUrl ? p.apiKey : "",
                                                        hasKey: p.baseUrl === geminiUrl && p.hasKey,
                                                        model: "gemini-2.5-pro",
                                                        modelDetails: geminiModels,
                                                        modelIds: geminiModels.map(m => m.id),
                                                        modelOverrides: {},
                                                    });
                                                }}
                                            >
                                                Google Gemini 官方免费预设
                                            </Button>
                                        </div>
                                        <div className="flex items-center gap-1.5 text-xs">
                                            <span className="text-muted-foreground">{p.enabled ? "已启用" : "已停用"}</span>
                                            <Switch
                                                aria-label="启用 Agent 服务商"
                                                checked={p.enabled}
                                                onChange={enabled => patch({ enabled })}
                                            />
                                        </div>
                                    </div>

                                    {/* API Key with inline Detect button (matching Image 10) */}
                                    <div className="space-y-1">
                                        <div className="flex items-center justify-between text-xs">
                                            <span className="font-medium">API 密钥</span>
                                            {p.hasKey && !p.apiKey && (
                                                <span className="text-[11px] text-emerald-600">已加密保存在本机（留空即沿用原密钥）</span>
                                            )}
                                        </div>
                                        <div className="flex gap-2">
                                            <Input.Password
                                                aria-label="自定义 API Key"
                                                className="flex-1"
                                                autoComplete="off"
                                                value={p.apiKey}
                                                placeholder={p.hasKey ? "已加密保存，留空保留原 Key" : "请输入 API 密钥"}
                                                onChange={e => patch({ apiKey: e.target.value })}
                                            />
                                            <Button
                                                aria-label="检测 Agent 服务商"
                                                onClick={() => void sync(true)}
                                                loading={syncing}
                                            >
                                                检测
                                            </Button>
                                        </div>
                                    </div>

                                    {/* API Base URL with endpoint preview (matching Image 10) */}
                                    <div className="space-y-1">
                                        <span className="block text-xs font-medium">API 地址</span>
                                        <Input
                                            aria-label="自定义 API Base URL"
                                            value={p.baseUrl}
                                            placeholder="https://api.deepseek.com"
                                            onChange={e =>
                                                patch({
                                                    baseUrl: e.target.value,
                                                    hasKey: false,
                                                    modelDetails: [],
                                                    modelIds: undefined,
                                                    modelOverrides: {},
                                                    efforts: {},
                                                })
                                            }
                                        />
                                        <p className="truncate text-[11px] text-muted-foreground">预览：{previewEndpoint}</p>
                                    </div>

                                    {/* Clean Single Model Section (matching Image 10 & Image 11, no duplicate model boxes) */}
                                    <div className="space-y-2 rounded-xl border border-border bg-card p-3">
                                        <div className="flex flex-wrap items-center justify-between gap-2">
                                            <div className="flex items-center gap-2">
                                                <span className="text-xs font-semibold">模型</span>
                                                <Tag className="!m-0 !rounded-full">{p.modelDetails.length}</Tag>
                                            </div>
                                            <div className="flex flex-wrap items-center gap-1.5">
                                                <Input
                                                    size="small"
                                                    aria-label="搜索 Agent 模型"
                                                    prefix={<Search size={12} className="text-muted-foreground" />}
                                                    placeholder="搜索模型…"
                                                    className="!w-36"
                                                    value={search}
                                                    onChange={e => setSearch(e.target.value)}
                                                    allowClear
                                                />
                                                <Button
                                                    size="small"
                                                    aria-label="同步 Agent 模型"
                                                    icon={<RefreshCw size={12} />}
                                                    loading={syncing}
                                                    onClick={() => void sync()}
                                                >
                                                    同步模型
                                                </Button>
                                            </div>
                                        </div>

                                        {/* Active / Manual Model Input Bar */}
                                        <div className="flex items-center gap-2 rounded-lg bg-secondary/50 px-2.5 py-1.5 text-xs">
                                            <span className="shrink-0 font-medium text-muted-foreground">当前使用模型：</span>
                                            <Input
                                                size="small"
                                                aria-label="自定义 API 模型名称"
                                                placeholder="点击下方列表选择，或直接输入模型 ID（如 deepseek-chat）"
                                                className="flex-1"
                                                value={p.model}
                                                onChange={e => patch({ model: e.target.value })}
                                            />
                                            <Button
                                                size="small"
                                                aria-label="添加 Agent 模型"
                                                icon={<Plus size={12} />}
                                                onClick={() => {
                                                    if (!p.model.trim()) return;
                                                    const id = p.model.trim();
                                                    patch({
                                                        modelDetails: p.modelDetails.some(m => m.id === id)
                                                            ? p.modelDetails
                                                            : [...p.modelDetails, ...normalizeAgentModels([{ id }])],
                                                        modelIds: [...new Set([...included, id])],
                                                    });
                                                }}
                                            >
                                                加入列表
                                            </Button>
                                        </div>

                                        {/* Model List */}
                                        <div className="max-h-56 overflow-auto rounded-lg border border-border bg-background">
                                            <div className="sticky top-0 z-[1] flex items-center justify-between border-b border-border bg-secondary/70 px-3 py-1.5 text-[11px] font-medium text-muted-foreground">
                                                <span>{p.name} · 点击模型即可设为当前使用</span>
                                                <span>勾选控制启用 · 齿轮调整能力</span>
                                            </div>
                                            {items.length === 0 ? (
                                                <div className="p-4 text-center text-xs text-muted-foreground">
                                                    暂无模型列表，可点击右上角「同步模型」自动获取，或在上方输入模型 ID 后点「加入列表」。
                                                </div>
                                            ) : (
                                                items.map(raw => {
                                                    const m = resolveAgentModel(raw, p.modelOverrides?.[raw.id]);
                                                    const isActive = p.model === m.id;
                                                    const isIncluded = included.includes(m.id);
                                                    return (
                                                        <div
                                                            key={m.id}
                                                            data-agent-model={m.id}
                                                            onClick={() =>
                                                                patch({
                                                                    model: m.id,
                                                                    modelIds: isIncluded ? included : [...included, m.id],
                                                                })
                                                            }
                                                            className={`flex cursor-pointer items-center gap-2.5 border-t border-border/60 px-3 py-2 text-xs transition first:border-t-0 ${
                                                                isActive ? "bg-primary/8" : "hover:bg-accent/50"
                                                            }`}
                                                        >
                                                            <div onClick={e => e.stopPropagation()}>
                                                                <Checkbox
                                                                    aria-label={"添加模型 " + m.id}
                                                                    checked={isIncluded}
                                                                    onChange={e => {
                                                                        const nextIds = e.target.checked
                                                                            ? [...new Set([...included, m.id])]
                                                                            : included.filter(id => id !== m.id);
                                                                        const nextModel = e.target.checked
                                                                            ? m.id
                                                                            : p.model === m.id && nextIds.length > 0
                                                                              ? nextIds[0]
                                                                              : p.model;
                                                                        patch({
                                                                            modelIds: nextIds,
                                                                            model: nextModel,
                                                                        });
                                                                    }}
                                                                />
                                                            </div>
                                                            <div className="min-w-0 flex-1">
                                                                <div className="flex flex-wrap items-center gap-1.5">
                                                                    <strong className="truncate text-foreground">{m.name}</strong>
                                                                    {m.id !== m.name && (
                                                                        <span className="text-[11px] text-muted-foreground">({m.id})</span>
                                                                    )}
                                                                    {isActive && (
                                                                        <Tag color="success" className="!m-0 !px-1.5 !py-0 !text-[10px]">
                                                                            <Check size={10} className="mr-0.5 inline" />
                                                                            当前使用
                                                                        </Tag>
                                                                    )}
                                                                </div>
                                                                <div className="mt-0.5 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
                                                                    {m.contextWindow ? (
                                                                        <span>上下文 {m.contextWindow.toLocaleString()}</span>
                                                                    ) : null}
                                                                    {m.maxOutputTokens ? (
                                                                        <span>· 输出 {m.maxOutputTokens.toLocaleString()}</span>
                                                                    ) : null}
                                                                    <span
                                                                        aria-label={"模型能力 " + m.id}
                                                                        className="inline-flex flex-wrap items-center gap-1"
                                                                        title={m.source}
                                                                    >
                                                                        {m.inputModalities.includes("image") && (
                                                                            <Tag className="!m-0 !text-[10px]">👁 视觉</Tag>
                                                                        )}
                                                                        {(m.reasoning || m.reasoningEfforts.length > 0) && (
                                                                            <Tag className="!m-0 !text-[10px]">💡 思考</Tag>
                                                                        )}
                                                                        {m.tools && <Tag className="!m-0 !text-[10px]">🔧 工具</Tag>}
                                                                        {m.web && <Tag className="!m-0 !text-[10px]">🌐 联网</Tag>}
                                                                        <span className="text-[10px] opacity-75">{m.source}</span>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                            <div className="flex shrink-0 items-center gap-1" onClick={e => e.stopPropagation()}>
                                                                <Tooltip title="设置模型能力与思考档位">
                                                                    <Button
                                                                        size="small"
                                                                        type="text"
                                                                        aria-label={"设置模型能力 " + m.id}
                                                                        icon={<Settings size={13} />}
                                                                        onClick={() => setOverride({ id: m.id, value: { ...m } })}
                                                                    />
                                                                </Tooltip>
                                                                <Tooltip title="从列表移除此模型">
                                                                    <Button
                                                                        size="small"
                                                                        type="text"
                                                                        danger
                                                                        aria-label={"移除模型 " + m.id}
                                                                        icon={<Trash2 size={13} />}
                                                                        onClick={() =>
                                                                            patch({
                                                                                modelDetails: p.modelDetails.filter(item => item.id !== m.id),
                                                                                modelIds: included.filter(id => id !== m.id),
                                                                            })
                                                                        }
                                                                    />
                                                                </Tooltip>
                                                            </div>
                                                        </div>
                                                    );
                                                })
                                            )}
                                        </div>
                                    </div>
                                </div>
                            ),
                        },
                    ]}
                />
            </Modal>
            <Modal
                title="模型能力覆盖"
                open={Boolean(override)}
                onCancel={() => setOverride(null)}
                onOk={() => {
                    if (override) patch({ modelOverrides: { ...p.modelOverrides, [override.id]: override.value } });
                    setOverride(null);
                }}
            >
                {override && (
                    <div className="space-y-3">
                        <Checkbox
                            aria-label="模型支持视觉"
                            checked={override.value.inputModalities?.includes("image")}
                            onChange={e =>
                                setOverride(
                                    o =>
                                        o && {
                                            ...o,
                                            value: { ...o.value, inputModalities: e.target.checked ? ["text", "image"] : ["text"] },
                                        },
                                )
                            }
                        >
                            视觉
                        </Checkbox>
                        {(["reasoning", "tools", "web"] as const).map((k, i) => (
                            <Checkbox
                                key={k}
                                aria-label={"模型支持" + ["思考", "工具", "联网"][i]}
                                checked={override.value[k]}
                                onChange={e =>
                                    setOverride(
                                        o =>
                                            o && {
                                                ...o,
                                                value: {
                                                    ...o.value,
                                                    [k]: e.target.checked,
                                                    ...(k === "reasoning" && !e.target.checked ? { reasoningEfforts: [] } : {}),
                                                },
                                            },
                                    )
                                }
                            >
                                {["思考", "工具", "联网"][i]}
                            </Checkbox>
                        ))}
                        <label className="block">
                            上下文长度
                            <InputNumber
                                aria-label="模型上下文长度"
                                min={1}
                                max={10000000}
                                value={override.value.contextWindow}
                                onChange={n => setOverride(o => o && { ...o, value: { ...o.value, contextWindow: n || undefined } })}
                            />
                        </label>
                        <label className="block">
                            支持的思考档位
                            <Select
                                aria-label="模型支持思考档位"
                                mode="multiple"
                                className="w-full"
                                value={override.value.reasoningEfforts}
                                options={["minimal", "low", "medium", "high", "xhigh", "max", "ultra"].map(val => ({
                                    value: val,
                                    label: `${effortLabel(val)} (${val})`,
                                }))}
                                onChange={reasoningEfforts => {
                                    const sorted = sortReasoningEfforts(reasoningEfforts);
                                    setOverride(
                                        o =>
                                            o && {
                                                ...o,
                                                value: { ...o.value, reasoningEfforts: sorted, reasoning: sorted.length > 0 },
                                            },
                                    );
                                }}
                            />
                        </label>
                    </div>
                )}
            </Modal>
        </>
    );
}
