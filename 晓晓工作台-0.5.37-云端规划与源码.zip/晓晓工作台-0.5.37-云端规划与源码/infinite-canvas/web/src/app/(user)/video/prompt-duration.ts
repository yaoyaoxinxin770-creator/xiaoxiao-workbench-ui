export function promptDuration(prompt:string):number|null {
 const explicit=/总时长\s*[:：]?\s*(\d+(?:\.\d+)?)\s*(?:秒|s)/i.exec(prompt)?.[1];
 let raw=explicit?Number(explicit):NaN;
 if(!Number.isFinite(raw)||raw<=0){
  if(/(?:镜头|时间轴|分镜)/.test(prompt)){
   const ranges=[...prompt.matchAll(/\d+(?:\.\d+)?\s*(?:秒|s)?\s*[-~～至到—–]\s*(\d+(?:\.\d+)?)\s*(?:秒|s)/gi)];
   if(ranges.length)raw=Number(ranges[ranges.length-1]?.[1]);
  }
 }
 if(!Number.isFinite(raw)||raw<=0)return null;
 const base=Math.floor(raw);return base+(raw-base>0.5+Number.EPSILON*raw?1:0);
}
