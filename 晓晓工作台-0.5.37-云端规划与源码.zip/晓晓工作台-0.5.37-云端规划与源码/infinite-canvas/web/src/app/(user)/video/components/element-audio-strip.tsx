"use client";
import {writeElementDrag} from "../element-drag";
import type {ReactNode} from "react";
import { useEffect, useMemo, useRef, useState } from "react";
import { message } from "antd";
import { AtSign, Pause, Pencil, Play, Star } from "lucide-react";
import type { Asset } from "@/stores/use-asset-store";
import { useVideoStudioStore } from "@/stores/use-video-studio-store";
import { notifyLocalAssetLoadError, ensureAssetLocalFile } from "@/services/api/local-assets";
import { LocalAssetMenu } from "./local-asset-menu";

export function buildWaveformHeights(seedText: string, count = 24): number[] {
    let hash = 2166136261;
    for (let i = 0; i < seedText.length; i++) {
        hash ^= seedText.charCodeAt(i);
        hash = Math.imul(hash, 16777619);
    }
    const bars: number[] = [];
    for (let i = 0; i < count; i++) {
        hash ^= i + 0x9e3779b9;
        hash = Math.imul(hash, 2246822507);
        const unit = ((hash >>> 0) % 100) / 100;
        const arch = Math.sin(((i + 1) / (count + 1)) * Math.PI);
        bars.push(Math.round(26 + (unit * 0.62 + arch * 0.38) * 70));
    }
    return bars;
}

export function formatAudioSeconds(seconds: number): string {
    if (!Number.isFinite(seconds) || seconds <= 0) return "0:00";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    if (mins === 0 && seconds < 60) {
        return `${seconds.toFixed(1)}s`;
    }
    return `${mins}:${String(secs).padStart(2, "0")}`;
}

type StripProps = {
    asset: Extract<Asset, { kind: "audio" }>;
    selection?: ReactNode;
    roleName?: string;
    selected?: boolean;
    flash?: boolean;
    sortScope?: string;
    onInspect?: () => void;
    onEdit: () => void;
    onReference: () => void;
};

export function ElementAudioStripCard({ asset, roleName, selected = false, flash = false, sortScope = "audio", onInspect, onEdit, onReference, selection }: StripProps) {
    const audioRef = useRef<HTMLAudioElement>(null);
    const [playing, setPlaying] = useState(false);
    const [time, setTime] = useState(0);
    const audioUrl = asset.data.url || String((asset.data as any)?.dataUrl || "");
    const fallbackSecs = ((asset.data.durationMs || 0) / 1000) || Number((asset.data as any)?.duration || 0);
    const [duration, setDuration] = useState(fallbackSecs);
    const [error, setError] = useState(false);
    const isPinned = Number(asset.metadata?.elementPinnedAt || asset.metadata?.elementRolePinnedAt) > 0;

    useEffect(() => {
        setError(false);
        if (fallbackSecs > 0 && duration <= 0) setDuration(fallbackSecs);
        audioRef.current?.load();
    }, [audioUrl, fallbackSecs]);

    useEffect(() => {
        if (!asset.localFile && audioUrl.startsWith("data:")) {
            void ensureAssetLocalFile(asset);
        }
    }, [asset.id, asset.localFile, audioUrl]);

    const rule = useVideoStudioStore(s => s.projects.find(p => p.id === s.activeProjectId)?.elementRules?.[asset.id]);
    const bars = useMemo(() => buildWaveformHeights(asset.id + ":" + asset.title, 40), [asset.id, asset.title]);
    const progress = duration > 0 ? Math.min(1, Math.max(0, time / duration)) : 0;

    const togglePlay = () => {
        const el = audioRef.current;
        if (!el) return;
        if (playing) {
            el.pause();
        } else {
            void el.play().catch(() => setError(true));
        }
    };

    return (
        <LocalAssetMenu asset={asset} hideRelink>
            <article
                data-archive-card={`["音频",${JSON.stringify(roleName || asset.title)}]`}
                data-audio-strip={asset.id}
                data-element-sort-key={asset.id}
                data-element-sort-scope={sortScope}
                data-asset-flash={flash ? "true" : undefined}
                data-selected={selected || undefined}
                draggable
                onPointerDown={() => {
                    if (!asset.localFile && audioUrl.startsWith("data:")) {
                        void ensureAssetLocalFile(asset);
                    }
                }}
                onDragStart={event => {
                    const isDisabled = Boolean(rule?.disabled);
                    if (isDisabled) {
                        event.preventDefault();
                        message.warning("已禁用的音频素材不可拖出引用");
                        return;
                    }
                    const isMissing = Boolean(asset.metadata?.localFileMissing) && !audioUrl;
                    if (isMissing) {
                        event.preventDefault();
                        message.warning("音频原文件已失效或缺失，无法拖出");
                        return;
                    }
                    const targetEl = event.target as HTMLElement;
                    if (targetEl.closest(".wb-audio-play-btn, .wb-wave-track, button, a, [role=slider]")) {
                        return;
                    }
                    let localPath = asset.localFile?.path || "";
                    if (localPath.startsWith("file://")) {
                        try {
                            localPath = decodeURIComponent(new URL(localPath).pathname.replace(/^\/([a-zA-Z]:)/, "$1"));
                        } catch (_) {}
                    }
                    const bridge = (window as any).desktopBridge;
                    if (bridge?.startFileDrag || bridge?.startDrag) {
                        event.preventDefault();
                        const dragPayload = {
                            file: localPath,
                            assetId: asset.id,
                            title: asset.title,
                            dataUrl: audioUrl.startsWith("data:") ? audioUrl : undefined,
                        };
                        if (bridge.startFileDrag) {
                            bridge.startFileDrag(dragPayload);
                        } else {
                            bridge.startDrag(dragPayload);
                        }
                    } else {
                        writeElementDrag(event.dataTransfer, asset);
                    }
                }}
                onDragEnd={() => {
                    if (typeof window !== "undefined") {
                        setTimeout(() => {
                            delete (window as any).__activeDraggingElement;
                        }, 80);
                    }
                }}
                onClick={() => onInspect?.()}
                onDoubleClick={() => onEdit()}
                className="wb-audio-strip group relative"
            >
                {selection}
                <audio
                    ref={audioRef}
                    preload="metadata"
                    src={audioUrl}
                    onLoadedMetadata={e => {
                        setError(false);
                        if (Number.isFinite(e.currentTarget.duration) && e.currentTarget.duration > 0) {
                            setDuration(e.currentTarget.duration);
                        }
                    }}
                    onTimeUpdate={e => setTime(e.currentTarget.currentTime)}
                    onPlay={() => setPlaying(true)}
                    onPause={() => setPlaying(false)}
                    onEnded={() => {
                        setPlaying(false);
                        setTime(0);
                    }}
                    onError={() => {
                        setError(true);
                        if (asset.localFile) notifyLocalAssetLoadError(asset);
                    }}
                />

                <button
                    type="button"
                    aria-label={(playing ? "暂停 " : "试听 ") + asset.title}
                    onClick={e => {
                        e.stopPropagation();
                        togglePlay();
                    }}
                    className="wb-audio-play-btn"
                >
                    {playing ? <Pause size={15} /> : <Play size={15} className="ml-0.5" />}
                </button>

                <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                        <div className="flex min-w-0 items-center gap-1.5">
                            {isPinned && (
                                <span data-pinned-badge title="已置顶" aria-label="已置顶" className="inline-flex shrink-0 items-center justify-center rounded bg-amber-500/18 px-1 py-0.5 text-[10px] font-semibold text-amber-700 ring-1 ring-amber-500/35 dark:text-amber-300">
                                    📌
                                </span>
                            )}
                            {Number(rule?.priority) > 0 && (
                                <span className="wb-priority-chip">
                                    <Star size={10} />优先{rule?.priority}
                                </span>
                            )}
                            <span className="truncate text-xs font-semibold text-foreground" title={asset.title}>
                                {error ? `${asset.title}（无法读取）` : asset.title}
                            </span>
                        </div>
                        <time className="shrink-0 font-mono text-xs text-muted-foreground">
                            {formatAudioSeconds(playing ? time : duration)}
                        </time>
                    </div>

                    <div
                        role="slider"
                        aria-label={"试听进度 " + asset.title}
                        aria-valuemin={0}
                        aria-valuemax={Math.round(duration || 1)}
                        aria-valuenow={Math.round(time)}
                        tabIndex={0}
                        onClick={e => {
                            e.stopPropagation();
                            if (!audioRef.current || !duration) return;
                            const rect = e.currentTarget.getBoundingClientRect();
                            const ratio = Math.min(1, Math.max(0, (e.clientX - rect.left) / rect.width));
                            audioRef.current.currentTime = ratio * duration;
                            setTime(ratio * duration);
                        }}
                        className={"wb-wave-track " + (playing ? "is-playing" : "")}
                    >
                        {bars.map((h, i) => {
                            const activeBar = i / bars.length <= progress && (playing || time > 0);
                            return (
                                <span
                                    key={i}
                                    className={"wb-wave-bar " + (activeBar ? "is-active" : "")}
                                    style={{ height: `${Math.max(22, h)}%` }}
                                />
                            );
                        })}
                    </div>

                    <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
                        <span className="truncate">
                            {roleName ? (
                                <>
                                    声线归属：<strong className="font-semibold text-primary">@{roleName}</strong>
                                </>
                            ) : (
                                "独立音频参考"
                            )}
                        </span>
                        <div className="flex shrink-0 items-center gap-1.5">
                            <button
                                type="button"
                                aria-label={"编辑元素 " + asset.title}
                                title="编辑音频属性"
                                onClick={e => {
                                    e.stopPropagation();
                                    onEdit();
                                }}
                                className="rounded px-1.5 py-0.5 text-muted-foreground hover:bg-secondary hover:text-foreground"
                            >
                                <Pencil size={12} />
                            </button>
                            <button
                                type="button"
                                disabled={Boolean(rule?.disabled)}
                                aria-label={"引用到提示词 " + asset.title}
                                onClick={e => {
                                    e.stopPropagation();
                                    onReference();
                                }}
                                className="inline-flex items-center gap-1 rounded-md bg-accent px-2 py-0.5 font-medium text-accent-foreground transition hover:opacity-90 disabled:opacity-40"
                            >
                                <AtSign size={11} />引用音色
                            </button>
                        </div>
                    </div>
                </div>
            </article>
        </LocalAssetMenu>
    );
}
