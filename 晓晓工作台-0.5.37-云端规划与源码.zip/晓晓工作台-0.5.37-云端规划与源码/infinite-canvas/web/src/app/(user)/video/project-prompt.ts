export type ProjectPromptRule={enabled:boolean;text:string;position:'start'|'end'|'afterHeading';heading?:string};
export type ProjectPrompt=ProjectPromptRule & {primaryEnabled?:boolean;additional?:ProjectPromptRule[]};
export const projectPromptRules=(rule:ProjectPrompt)=>[{enabled:rule.primaryEnabled??true,text:rule.text,position:rule.position,heading:rule.heading},...(rule.additional||[])];
export function stripProjectPrompt(source:string,rule?:ProjectPrompt,onlyEnabled=false){
 if(!source||!rule)return source;
 const patterns=projectPromptRules(rule)
  .filter(e=>(!onlyEnabled||e.enabled)&&e.text?.trim())
  .map(e=>e.text.replace(/\r\n/g,'\n').trim().split(/\n+/).map(l=>l.trim().replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).filter(Boolean).join('[ \\t]*\\r?\\n+[ \\t]*'))
  .filter(Boolean);
 if(!patterns.length)return source;
 let cur=source;
 for(let pass=0;pass<4;pass++){
  let next=cur;
  for(const pat of patterns){
   next=next
    .replace(new RegExp('^[ \\t]*'+pat+'[ \\t]*(?:\\r?\\n)+'),'')
    .replace(new RegExp('(?:\\r?\\n)+[ \\t]*'+pat+'[ \\t]*$'),'')
    .replace(new RegExp('(\\r?\\n)[ \\t]*'+pat+'[ \\t]*(?:\\r?\\n)+','g'),'$1');
   if(new RegExp('^[ \\t]*'+pat+'[ \\t]*$').test(next))next='';
  }
  if(next===cur)break;
  cur=next;
 }
 return cur;
}
function normalizePromptSegment(text:string){
 return text.normalize('NFKC').replace(/[\s\p{P}\p{S}]+/gu,'').toLowerCase();
}
function filterMissingRuleText(ruleText:string,existingPrompt:string){
 if(!ruleText.trim()||!existingPrompt.trim())return ruleText.trim();
 const normExisting=normalizePromptSegment(existingPrompt);
 if(!normExisting)return ruleText.trim();
 const rawLines=ruleText.replace(/\r\n/g,'\n').split('\n');
 const keptLines:string[]=[];
 let pendingHeading:string|null=null;
 for(const rawLine of rawLines){
  const trimmed=rawLine.trim();
  if(!trimmed)continue;
  if(/^(?:\*\*)?【[^】]+】(?:\*\*)?$/.test(trimmed)){
   pendingHeading=trimmed;
   continue;
  }
  const normLine=normalizePromptSegment(trimmed);
  if(!normLine)continue;
  if(existingPrompt.includes(trimmed)||normExisting.includes(normLine)){
   continue;
  }
  const sentenceParts=trimmed.split(/(?<=[。；;！!？?])\s*/u).map(s=>s.trim()).filter(Boolean);
  let finalLine=trimmed;
  if(sentenceParts.length>1){
   const missingSentences=sentenceParts.filter(part=>{
    const np=normalizePromptSegment(part);
    return np&&!existingPrompt.includes(part)&&!normExisting.includes(np);
   });
   if(!missingSentences.length)continue;
   finalLine=missingSentences.join('');
  }else{
   const commaParts=trimmed.split(/([，,、])/u);
   if(commaParts.length>=3){
    const clauses:string[]=[];
    for(let i=0;i<commaParts.length;i+=2){
     const clause=(commaParts[i]||'').trim();
     const sep=commaParts[i+1]||'';
     const nc=normalizePromptSegment(clause);
     if(nc&&nc.length>=4&&(existingPrompt.includes(clause)||normExisting.includes(nc)))continue;
     if(clause)clauses.push(clause+sep);
    }
    const rebuilt=clauses.join('').replace(/[，,、]+$/u,'').trim();
    if(!rebuilt||!normalizePromptSegment(rebuilt))continue;
    finalLine=rebuilt;
   }
  }
  if(pendingHeading){
   keptLines.push(pendingHeading);
   pendingHeading=null;
  }
  keptLines.push(finalLine);
 }
 return keptLines.join('\n').trim();
}
export function applyProjectPrompt(source:string,rule?:ProjectPrompt){
 if(!rule?.enabled)return {prompt:source,missingHeading:false};
 const base=stripProjectPrompt(source,rule,true);
 const buckets=new Map<string,ProjectPromptRule>(),ends:string[]=[];let missingHeading=false;
 let accumulated=base;
 for(const entry of projectPromptRules(rule)){
  if(!entry.enabled||!entry.text.trim())continue;
  const dedupedText=filterMissingRuleText(entry.text,accumulated);
  if(!dedupedText)continue;
  accumulated+='\n'+dedupedText;
  const heading=(entry.heading||'').trim().replace(/^【|】$/g,''),value={...entry,text:dedupedText,heading};
  if(entry.position==='end'){ends.push(value.text);continue;}
  if(entry.position==='afterHeading'&&applyOne(base,value).missingHeading){missingHeading=true;ends.push(value.text);continue;}
  const key=entry.position+':'+(entry.position==='afterHeading'?heading:''),previous=buckets.get(key);buckets.set(key,previous?{...value,text:previous.text+'\n\n'+value.text}:value);
 }
 let prompt=base;for(const entry of buckets.values())prompt=applyOne(prompt,entry).prompt;
 if(ends.length)prompt=applyOne(prompt,{enabled:true,position:'end',text:ends.join('\n\n')}).prompt;
 return {prompt,missingHeading};
}
function applyOne(source:string,rule?:ProjectPromptRule){
 const text=rule?.text.trim();if(!rule?.enabled||!text)return {prompt:source,missingHeading:false};
 if(rule.position==='start')return {prompt:source===text||source.startsWith(text+'\n')?source:text+'\n\n'+source,missingHeading:false};
 const append=()=>source===text||source.endsWith('\n'+text)?source:source.replace(/\s+$/u,'')+'\n\n'+text;
 if(rule.position!=='afterHeading')return {prompt:append(),missingHeading:false};
 const heading=(rule.heading||'').trim().replace(/^【|】$/g,''),escaped=heading.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
 const match=heading?new RegExp('^[\\t ]*(?:\\*\\*)?【'+escaped+'】(?:\\*\\*)?','m').exec(source):null;
 if(!match)return {prompt:append(),missingHeading:true};
 const at=match.index+match[0].length,rest=source.slice(at).replace(/^\r?\n/,'');
 return {prompt:rest===text||rest.startsWith(text+'\n')?source:source.slice(0,at)+'\n'+text+'\n'+rest,missingHeading:false};
}
