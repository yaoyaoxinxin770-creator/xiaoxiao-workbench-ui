"use client";

import { useEffect, useState } from "react";
import { App, Button, Input, Select, Tag, Tooltip } from "antd";
import { ArrowUp, Bot, ChevronDown, FolderOpen, ImageIcon, Music2, Sparkles, Trash2, VideoIcon } from "lucide-react";
import { useAssetStore } from "@/stores/use-asset-store";
import { useVideoStudioStore } from "@/stores/use-video-studio-store";
import { chooseLocalDirectory, saveDataUrlAsLocalAsset } from "@/services/api/local-assets";
import type { ReferenceImage } from "@/types/image";
import type { ReferenceAudio } from "@/types/media";

export const AUDIO_OUTPUT_DIR_STORAGE_KEY = "xiaoxiao:seed-audio-output-dir";

export function getSavedAudioOutputDir(): string {
    if (typeof window === "undefined") return "";
    try {
        return localStorage.getItem(AUDIO_OUTPUT_DIR_STORAGE_KEY) || "";
    } catch {
        return "";
    }
}

export function setSavedAudioOutputDir(dir: string) {
    if (typeof window === "undefined") return;
    try {
        if (dir) localStorage.setItem(AUDIO_OUTPUT_DIR_STORAGE_KEY, dir);
        else localStorage.removeItem(AUDIO_OUTPUT_DIR_STORAGE_KEY);
        window.dispatchEvent(new CustomEvent("xiaoxiao:audio-output-dir-changed", { detail: { dir } }));
    } catch {}
}

export type ComposerCreationMode = "video" | "image" | "audio";

export const AUDIO_PRESET_COMMERCIAL_4S =
    "口齿清晰，咬字准确，根据形象生成适配的音色，说完上句台词，立马说下一句台词，台词：这是我授权可商用的音色，阳光真好啊";

export const AUDIO_PRESET_EMOTION_DUB =
    "保持原音色，根据台词推断情绪，使用情绪进行配音，台词：";

export function ComposerModeSwitcher({
    mode,
    onChange,
}: {
    mode: ComposerCreationMode;
    onChange: (next: ComposerCreationMode) => void;
}) {
    const items: { id: ComposerCreationMode; label: string; icon: typeof VideoIcon }[] = [
        { id: "video", label: "视频", icon: VideoIcon },
        { id: "image", label: "图像", icon: ImageIcon },
        { id: "audio", label: "音频", icon: Music2 },
    ];
    return (
        <div
            data-composer-mode-switcher
            role="tablist"
            aria-label="切换创作模型区"
            className="pointer-events-auto flex shrink-0 flex-col items-center gap-1 self-end rounded-[22px] border border-border/80 bg-card/95 p-1.5 shadow-[0_18px_50px_rgba(15,23,42,.18)] ring-1 ring-white/40 backdrop-blur-2xl dark:ring-white/10"
        >
            {items.map(item => {
                const Icon = item.icon;
                const active = mode === item.id;
                return (
                    <button
                        key={item.id}
                        type="button"
                        role="tab"
                        data-composer-mode-btn={item.id}
                        aria-selected={active}
                        onClick={() => onChange(item.id)}
                        className={`flex w-13 flex-col items-center justify-center gap-1 rounded-2xl px-2 py-2 text-[11px] font-medium transition ${
                            active
                                ? "bg-primary text-primary-foreground shadow-xs"
                                : "text-muted-foreground hover:bg-accent hover:text-foreground"
                        }`}
                    >
                        <Icon className="size-4" />
                        <span>{item.label}</span>
                    </button>
                );
            })}
        </div>
    );
}

export function SeedAudioComposerPanel({
    projectId,
    references,
    audioReferences,
    videoPrompt,
    onInsertAudioMention,
    onHidePrompt,
}: {
    projectId: string;
    references: ReferenceImage[];
    audioReferences: ReferenceAudio[];
    videoPrompt: string;
    onInsertAudioMention: (roleName: string) => void;
    onHidePrompt?: () => void;
}) {
    const { message, modal } = App.useApp();
    const [audioTitle, setAudioTitle] = useState("路人商用音色");
    const [titleManuallyEdited, setTitleManuallyEdited] = useState(false);
    const [activePreset, setActivePreset] = useState<"commercial-4s" | "emotion-dub" | "">("");
    const [scenario, setScenario] = useState<"omni-dubbing" | "text-reading">("omni-dubbing");
    const [voiceName, setVoiceName] = useState("");
    const [audioPrompt, setAudioPrompt] = useState(AUDIO_PRESET_COMMERCIAL_4S);
    const [enabledRefKey, setEnabledRefKey] = useState<string>("");
    const [voices, setVoices] = useState<{ voiceName: string; voiceId: string }[]>([]);
    const [loadingVoices, setLoadingVoices] = useState(false);
    const [audioOutputDir, setAudioOutputDir] = useState<string>(() => getSavedAudioOutputDir());
    const [task, setTask] = useState<{
        id?: string;
        status?: string;
        credits?: number;
        canvasName?: string;
        audioUrl?: string;
        error?: string;
        busy?: boolean;
    }>({});

    useEffect(() => {
        setAudioOutputDir(getSavedAudioOutputDir());
        const onDirChange = (e: Event) => {
            const detail = (e as CustomEvent)?.detail;
            setAudioOutputDir(typeof detail?.dir === "string" ? detail.dir : getSavedAudioOutputDir());
        };
        window.addEventListener("xiaoxiao:audio-output-dir-changed", onDirChange);
        return () => window.removeEventListener("xiaoxiao:audio-output-dir-changed", onDirChange);
    }, []);

    const handleChooseAudioOutputDir = async () => {
        const picked = await chooseLocalDirectory(audioOutputDir || undefined, "选择生成配音音频保存文件夹（切换文件夹不影响已生成音频）");
        if (picked) {
            setSavedAudioOutputDir(picked);
            setAudioOutputDir(picked);
            message.success(`已设置配音保存文件夹：${picked}`);
        }
    };

    const enabledImage = references.find(img => `image:${img.id}` === enabledRefKey);
    const enabledAudio = audioReferences.find(aud => `audio:${aud.id}` === enabledRefKey);

    useEffect(() => {
        if (enabledRefKey && !enabledImage && !enabledAudio) {
            setEnabledRefKey("");
        }
    }, [enabledRefKey, enabledImage, enabledAudio]);

    useEffect(() => {
        if (scenario !== "text-reading" || voices.length > 0) return;
        const bridge = (window as any).desktopBridge;
        if (!bridge?.dreaminaAudioVoices) return;
        setLoadingVoices(true);
        void bridge
            .dreaminaAudioVoices({ count: 50 })
            .then((res: any) => {
                const list = Array.isArray(res?.voices) ? res.voices : [];
                setVoices(list);
                if (!voiceName && list[0]?.voiceName) setVoiceName(list[0].voiceName);
            })
            .catch(() => {})
            .finally(() => setLoadingVoices(false));
    }, [scenario, voices.length, voiceName]);

    const extractDialogueSuffix = (text: string) => {
        const idx = text.lastIndexOf("台词：");
        const idxEn = text.lastIndexOf("台词:");
        const pos = Math.max(idx, idxEn);
        if (pos < 0) return "";
        const raw = text.slice(pos + 3).trim();
        const cleaned = raw.replace(/^[“"「『\s]+|[”"」』\s。.！!？?，,、；;：:]+$/gu, "").replace(/[<>:"/\\|?*\x00-\x1f\s]+/gu, "");
        return cleaned.slice(0, 14);
    };

    const computeAutoTitle = (baseRole: string, promptText: string, fallbackSuffix: string) => {
        const dialoguePart = extractDialogueSuffix(promptText);
        if (dialoguePart && dialoguePart !== "这是我授权可商用的音色阳光真好啊") {
            return `${baseRole}-${dialoguePart}`;
        }
        return `${baseRole}-${fallbackSuffix}`;
    };

    const applyImageRef = (img: ReferenceImage) => {
        setEnabledRefKey(`image:${img.id}`);
        setActivePreset("commercial-4s");
        const nextPrompt = `结合参考形象「${img.name}」，${AUDIO_PRESET_COMMERCIAL_4S}`;
        setAudioPrompt(nextPrompt);
        setTitleManuallyEdited(false);
        setAudioTitle(computeAutoTitle(img.name, nextPrompt, "商用音色"));
        message.success(`已启用参考形象「${img.name}」，按形象定制音色`);
    };

    const applyAudioRef = (aud: ReferenceAudio) => {
        setEnabledRefKey(`audio:${aud.id}`);
        setActivePreset("emotion-dub");
        const existingLine = (() => {
            if (audioPrompt.includes("这是我授权可商用的音色")) return "";
            const idx = audioPrompt.lastIndexOf("台词：");
            return idx >= 0 ? audioPrompt.slice(idx + 3).trim() : "";
        })();
        const nextPrompt = `保持原音色（参考原音色：${aud.name}），根据台词推断情绪，使用情绪进行配音，台词：${existingLine}`;
        setAudioPrompt(nextPrompt);
        setTitleManuallyEdited(false);
        setAudioTitle(computeAutoTitle(aud.name, nextPrompt, "补词"));
        message.success(`已启用参考原声「${aud.name}」，保持该角色音色补台词`);
    };

    const toggleRefChip = (kind: "image" | "audio", item: ReferenceImage | ReferenceAudio) => {
        const key = `${kind}:${item.id}`;
        if (enabledRefKey === key) {
            setEnabledRefKey("");
            message.success(`已取消启用「${item.name}」`);
            return;
        }
        if (kind === "image") {
            applyImageRef(item as ReferenceImage);
        } else {
            applyAudioRef(item as ReferenceAudio);
        }
    };

    const applyPreset = (kind: "commercial-4s" | "emotion-dub") => {
        setActivePreset(kind);
        setTitleManuallyEdited(false);
        if (kind === "commercial-4s") {
            const preferredImg =
                enabledImage ||
                references.find(r => !/(客厅|卧室|房间|走廊|街道|室内|室外|场景|大门|办公室|医院|学校)/u.test(r.name || "")) ||
                references[0];
            if (preferredImg) {
                setEnabledRefKey(`image:${preferredImg.id}`);
                const nextPrompt = `结合参考形象「${preferredImg.name}」，${AUDIO_PRESET_COMMERCIAL_4S}`;
                setAudioPrompt(nextPrompt);
                setAudioTitle(computeAutoTitle(preferredImg.name, nextPrompt, "商用音色"));
            } else {
                setEnabledRefKey("");
                setAudioPrompt(AUDIO_PRESET_COMMERCIAL_4S);
                setAudioTitle("路人商用音色");
            }
            message.success("已填入「4秒商用授权音色」预设，可点击上方图片切换要参考的角色形象");
        } else {
            let targetAud = enabledAudio;
            if (!targetAud && audioReferences.length > 0) {
                targetAud = audioReferences[0];
            } else if (targetAud && audioReferences.length > 1) {
                const idx = audioReferences.findIndex(a => a.id === targetAud!.id);
                targetAud = audioReferences[(idx + 1) % audioReferences.length];
            }
            if (targetAud) {
                applyAudioRef(targetAud);
            } else {
                setEnabledRefKey("");
                setAudioPrompt(`${AUDIO_PRESET_EMOTION_DUB}`);
                setAudioTitle("补台词情绪配音");
                message.success("已填入「保持原音色·按台词推断情绪配音」预设，请补充台词");
            }
        }
    };

    const toBase64DataUrl = async (rawUrl?: string, fallbackMime = "audio/mpeg"): Promise<string | undefined> => {
        if (!rawUrl) return undefined;
        if (/^data:[^;,]+;base64,/i.test(rawUrl)) return rawUrl;
        try {
            const res = await fetch(rawUrl);
            const blob = await res.blob();
            return await new Promise<string>((resolve, reject) => {
                const reader = new FileReader();
                reader.onloadend = () => (typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("读取失败")));
                reader.onerror = () => reject(new Error("读取失败"));
                reader.readAsDataURL(blob.type ? blob : new Blob([blob], { type: fallbackMime }));
            });
        } catch {
            return undefined;
        }
    };

    const confirmAudioTask = async (snapshot: {
        taskId: string;
        credits: number;
        cleanTitle: string;
        cleanPrompt: string;
        baseRoleName: string;
        targetOutputDir: string;
    }) => {
        const bridge = (window as any).desktopBridge;
        if (!bridge?.dreaminaConfirm || !bridge?.dreaminaQuery || !snapshot.taskId) return;
        setTask(prev => ({ ...prev, id: snapshot.taskId, busy: true, status: "processing", error: undefined }));
        try {
            await bridge.dreaminaConfirm({ id: snapshot.taskId, creditCeiling: Math.max(0, snapshot.credits) });
            for (let i = 0; i < 120; i++) {
                await new Promise(r => setTimeout(r, 2500));
                const q = await bridge.dreaminaQuery(snapshot.taskId);
                if (q.status === "completed" && q.media?.[0]?.dataUrl) {
                    const media = q.media[0];
                    const cleanTitle = snapshot.cleanTitle;
                    const localItem = await saveDataUrlAsLocalAsset(
                        media.dataUrl,
                        cleanTitle,
                        "生成配音与补词",
                        snapshot.targetOutputDir || undefined,
                    );
                    const playableUrl = localItem ? (localItem.revision ? `${localItem.url}?v=${encodeURIComponent(localItem.revision)}` : localItem.url) : media.dataUrl;
                    const baseRoleName = snapshot.baseRoleName;
                    const newId = useAssetStore.getState().addAsset({
                        title: cleanTitle,
                        category: "音频",
                        coverUrl: "",
                        tags: ["SeedAudio 1.0"],
                        kind: "audio",
                        ...(localItem ? { localFile: { id: localItem.id, path: localItem.path } } : {}),
                        metadata: {
                            elementPerformer: baseRoleName,
                            elementManualCategory: "音频",
                            elementManualGroup: baseRoleName,
                            seedAudioPrompt: snapshot.cleanPrompt,
                            isSeedAudioGenerated: true,
                            savedFolder: snapshot.targetOutputDir || undefined,
                        },
                        data: {
                            url: playableUrl,
                            dataUrl: media.dataUrl,
                            mimeType: localItem?.mimeType || media.mimeType || "audio/mpeg",
                            fileName: `${cleanTitle}.mp3`,
                            bytes: localItem?.bytes || Math.round((media.dataUrl.length * 3) / 4),
                            size: localItem?.bytes || Math.round((media.dataUrl.length * 3) / 4),
                            durationMs: 4000,
                            duration: 4,
                        },
                    });
                    useVideoStudioStore.getState().addElement(newId, projectId);
                    window.dispatchEvent(new CustomEvent("xiaoxiao:flash-asset", { detail: { id: newId, projectId, category: "音频" } }));
                    window.dispatchEvent(new CustomEvent("xiaoxiao:unread-asset-category", { detail: { category: "音频", projectId, assetId: newId } }));
                    setTask(prev => ({ ...prev, busy: false, status: "completed", audioUrl: playableUrl }));
                    message.success(
                        localItem?.path
                            ? `音频「${cleanTitle}」已生成并保存到文件夹（${localItem.path}），同时已入库「资产 → 音频」！`
                            : `音频「${cleanTitle}」已生成并自动存入当前项目「资产 → 音频」！`,
                    );
                    return;
                }
                if (q.status === "failed") {
                    throw new Error(q.error?.message || "即梦音频生成失败");
                }
            }
            throw new Error("音频生成等待超时，请稍后在即梦画布核对");
        } catch (err) {
            const msg = err instanceof Error ? err.message : "音频生成失败";
            setTask(prev => ({ ...prev, busy: false, status: "failed", error: msg }));
            message.error(msg);
        }
    };

    const prepareAudioTask = async () => {
        const bridge = (window as any).desktopBridge;
        if (!bridge?.dreaminaAudioSubmit) {
            message.warning("请在桌面版工作台中使用即梦 SeedAudio 1.0 音频生成功能");
            return;
        }
        if (!audioPrompt.trim()) {
            message.warning("请输入音频创作提示词或台词");
            return;
        }
        const snapTitle = audioTitle.trim() || "SeedAudio配音";
        const snapPrompt = audioPrompt.trim();
        const snapRole = enabledAudio?.name || enabledImage?.name || snapTitle.split("-")[0] || snapTitle;
        const snapOutputDir = audioOutputDir || getSavedAudioOutputDir();
        setTask({ busy: true });
        try {
            const submitRefs: { assetId?: string; kind: "image" | "audio"; name: string; dataUrl: string }[] = [];
            if (enabledImage) {
                const dataUrl = await toBase64DataUrl(enabledImage.dataUrl, enabledImage.type || "image/png");
                if (dataUrl) submitRefs.push({ assetId: enabledImage.assetId, kind: "image", name: enabledImage.name, dataUrl });
            } else if (enabledAudio) {
                const dataUrl = await toBase64DataUrl(enabledAudio.url, enabledAudio.type || "audio/mpeg");
                if (dataUrl) submitRefs.push({ assetId: enabledAudio.assetId, kind: "audio", name: enabledAudio.name, dataUrl });
            }
            const res = await bridge.dreaminaAudioSubmit({
                projectKey: projectId,
                title: snapTitle,
                prompt: snapPrompt,
                scenario,
                voiceName: scenario === "text-reading" ? voiceName : undefined,
                ...(submitRefs.length > 0 ? { references: submitRefs } : {}),
            });
            const credits = res.quote?.credits ?? 0;
            const canvasName = res.canvasName || "";
            setTask({
                id: res.id,
                status: res.status,
                credits,
                canvasName,
                busy: false,
            });
            const confirmed = await new Promise<boolean>(resolve => {
                let settled = false;
                const finish = (v: boolean) => {
                    if (!settled) {
                        settled = true;
                        resolve(v);
                    }
                };
                modal.confirm({
                    title: "即梦 SeedAudio 1.0 配音生成确认",
                    style: { top: 72 },
                    content: (
                        <div data-audio-confirm-modal className="space-y-1.5 text-xs">
                            <p className="flex flex-wrap items-center gap-1.5">
                                <span className="text-muted-foreground">入库名称：</span>
                                <span className="rounded bg-amber-500/15 px-2 py-0.5 font-semibold text-amber-800 dark:text-amber-200">
                                    🎙️ {snapTitle}
                                </span>
                            </p>
                            <p className="text-muted-foreground">
                                保存文件夹：<strong className="text-foreground">{snapOutputDir || "工作台默认生成配音目录"}</strong>
                            </p>
                            {canvasName && <p className="text-muted-foreground">目标画布：{canvasName}</p>}
                            <p className="font-medium text-foreground">
                                本次生成将消耗 <strong className="text-primary">{credits}</strong> 积分，确认开始生成吗？
                            </p>
                        </div>
                    ),
                    okText: "确认生成",
                    cancelText: "取消",
                    onOk: () => finish(true),
                    onCancel: () => finish(false),
                });
            });
            if (!confirmed) {
                setTask({ busy: false });
                return;
            }
            void confirmAudioTask({
                taskId: res.id,
                credits,
                cleanTitle: snapTitle,
                cleanPrompt: snapPrompt,
                baseRoleName: snapRole,
                targetOutputDir: snapOutputDir,
            });
        } catch (err) {
            const msg = err instanceof Error ? err.message : "准备音频节点失败";
            setTask({ error: msg, busy: false });
            message.error(msg);
        }
    };

    return (
        <div data-audio-composer className="flex flex-col gap-2.5">
            {/* Reference context strip */}
            {(references.length > 0 || audioReferences.length > 0) && (
                <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
                    <span className="shrink-0 text-[11px] text-muted-foreground" title="点一下启用作为本次配音的参考形象或参考原声；再点一下关闭">
                        当前组参考形象/原声（点击启用）：
                    </span>
                    {references.map(img => {
                        const active = enabledRefKey === `image:${img.id}`;
                        return (
                            <button
                                key={img.id}
                                type="button"
                                data-audio-ref-toggle={`image:${img.name}`}
                                aria-pressed={active}
                                title={active ? `已启用参考形象「${img.name}」（再次点击取消启用）` : `点击启用「${img.name}」作为定制音色的参考形象`}
                                onClick={() => toggleRefChip("image", img)}
                                className={`inline-flex shrink-0 cursor-pointer items-center gap-1.5 rounded-lg border px-2 py-1 text-[11px] font-medium transition ${
                                    active
                                        ? "border-primary bg-primary text-primary-foreground shadow-xs ring-2 ring-primary/25"
                                        : "border-border bg-secondary/60 text-foreground opacity-80 hover:border-primary/50 hover:opacity-100"
                                }`}
                            >
                                <span aria-hidden className="text-[10px]">{active ? "●" : "○"}</span>
                                <img src={img.dataUrl} alt={img.name} className="size-5 rounded object-cover" />
                                <span>{img.name}</span>
                            </button>
                        );
                    })}
                    {audioReferences.map(aud => {
                        const active = enabledRefKey === `audio:${aud.id}`;
                        return (
                            <button
                                key={aud.id}
                                type="button"
                                data-audio-ref-toggle={`audio:${aud.name}`}
                                aria-pressed={active}
                                title={active ? `已启用参考原声「${aud.name}」（再次点击取消启用）` : `点击启用「${aud.name}」作为保持原音色补台词的参考音频`}
                                onClick={() => toggleRefChip("audio", aud)}
                                className={`inline-flex shrink-0 cursor-pointer items-center gap-1.5 rounded-lg border px-2.5 py-1 text-[11px] font-medium transition ${
                                    active
                                        ? "border-primary bg-primary text-primary-foreground shadow-xs ring-2 ring-primary/25"
                                        : "border-border bg-secondary/60 text-foreground opacity-80 hover:border-primary/50 hover:opacity-100"
                                }`}
                            >
                                <span aria-hidden className="text-[10px]">{active ? "●" : "○"}</span>
                                <Music2 className="size-3.5" />
                                <span>{aud.name}</span>
                            </button>
                        );
                    })}
                </div>
            )}

            {/* Quick Presets Bar */}
            <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-[11px] font-medium text-muted-foreground">快捷预设：</span>
                    <button
                        type="button"
                        data-audio-preset="commercial-4s"
                        aria-pressed={activePreset === "commercial-4s"}
                        onClick={() => applyPreset("commercial-4s")}
                        className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-[11px] font-medium transition ${
                            activePreset === "commercial-4s"
                                ? "border-primary bg-primary text-primary-foreground shadow-xs ring-2 ring-primary/25"
                                : "border-border bg-secondary/70 text-foreground hover:border-primary hover:text-primary"
                        }`}
                    >
                        <span>{activePreset === "commercial-4s" ? "●" : "🎙️"}</span>
                        <span>无音频路人·按形象定制4秒商用音色</span>
                    </button>
                    <button
                        type="button"
                        data-audio-preset="emotion-dub"
                        aria-pressed={activePreset === "emotion-dub"}
                        onClick={() => applyPreset("emotion-dub")}
                        className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-[11px] font-medium transition ${
                            activePreset === "emotion-dub"
                                ? "border-primary bg-primary text-primary-foreground shadow-xs ring-2 ring-primary/25"
                                : "border-border bg-secondary/70 text-foreground hover:border-primary hover:text-primary"
                        }`}
                    >
                        <span>{activePreset === "emotion-dub" ? "●" : "🎭"}</span>
                        <span>补台词·保持原音色按台词推断情绪配音</span>
                    </button>
                </div>
                <span className="text-[11px] text-muted-foreground">支持任意时长与自由提示词创作，生成后自动入库「资产 → 音频」</span>
            </div>

            {/* Free-form Audio Prompt Input with Dialogue Highlight Preview */}
            <div className="space-y-1.5">
                <Input.TextArea
                    data-audio-composer-prompt
                    aria-label="音频创作提示词"
                    rows={3}
                    value={audioPrompt}
                    onChange={e => {
                        const nextVal = e.target.value;
                        setAudioPrompt(nextVal);
                        if (!titleManuallyEdited) {
                            const rolePrefix = enabledAudio?.name || enabledImage?.name || (activePreset === "emotion-dub" ? "补台词" : "路人");
                            const fallback = activePreset === "emotion-dub" || enabledAudio ? "补词" : "商用音色";
                            setAudioTitle(computeAutoTitle(rolePrefix, nextVal, fallback));
                        }
                    }}
                    placeholder="自由输入音频/配音提示词（不限于4秒），或点击上方预设一键填入…"
                    className="!rounded-2xl !text-xs leading-5"
                />
                {(() => {
                    const idx = Math.max(audioPrompt.lastIndexOf("台词："), audioPrompt.lastIndexOf("台词:"));
                    if (idx < 0) return null;
                    const instructionPart = audioPrompt.slice(0, idx + 3);
                    const dialoguePart = audioPrompt.slice(idx + 3);
                    return (
                        <div data-audio-dialogue-highlight className="flex flex-wrap items-baseline gap-1 rounded-xl border border-primary/25 bg-primary/5 px-3 py-1.5 text-xs leading-5">
                            <span className="text-muted-foreground">{instructionPart}</span>
                            {dialoguePart.trim() ? (
                                <span className="rounded bg-primary/15 px-1.5 py-0.5 font-semibold text-primary">
                                    {dialoguePart}
                                </span>
                            ) : (
                                <span className="italic text-amber-600 dark:text-amber-400">
                                    （请在上方输入框「台词：」后面直接输入要配音的台词，入库名将自动带上台词后缀）
                                </span>
                            )}
                        </div>
                    );
                })()}
            </div>

            {task.error && <p className="text-xs text-destructive">{task.error}</p>}

            {task.audioUrl && (
                <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-xs">
                    <div className="flex items-center gap-2">
                        <span className="font-medium text-emerald-700 dark:text-emerald-300">✅ 已存入音频库：{audioTitle}</span>
                        <audio controls src={task.audioUrl} className="h-8 w-56" />
                    </div>
                    <Button
                        size="small"
                        type="primary"
                        onClick={() => onInsertAudioMention(audioTitle.trim() || "SeedAudio配音")}
                    >
                        @引用到当前视频提示词
                    </Button>
                </div>
            )}

            {/* Bottom Toolbar (Single Row) */}
            <div data-audio-composer-bottom-bar className="flex items-center justify-between gap-2 pt-0.5 whitespace-nowrap">
                <div className="flex min-w-0 flex-1 items-center gap-2 overflow-x-auto">
                    <Tag color="gold" className="!m-0 shrink-0 !rounded-full !px-2.5 !py-0.5 !text-xs font-medium">
                        🎙️ seed_audio_v1 · SeedAudio 1.0
                    </Tag>
                    <Select
                        size="small"
                        aria-label="选择 SeedAudio 配音模式"
                        value={scenario}
                        onChange={val => setScenario(val)}
                        optionLabelProp="shortLabel"
                        popupMatchSelectWidth={false}
                        options={[
                            {
                                value: "omni-dubbing",
                                shortLabel: "全能配音",
                                label: "全能配音 (按提示词定制声线/情绪)",
                            },
                            {
                                value: "text-reading",
                                shortLabel: "官方音色库朗读",
                                label: "官方音色库朗读",
                            },
                        ]}
                        className="w-28 shrink-0 !text-xs"
                    />
                    {scenario === "text-reading" && (
                        <Select
                            size="small"
                            aria-label="选择官方音色"
                            loading={loadingVoices}
                            value={voiceName || undefined}
                            onChange={val => setVoiceName(val)}
                            placeholder="选择音色"
                            options={voices.map(v => ({ value: v.voiceName, label: v.voiceName }))}
                            className="w-32 shrink-0 !text-xs"
                        />
                    )}
                    <div className="flex min-w-0 items-center gap-1 text-xs">
                        <span className="shrink-0 text-muted-foreground">入库名称：</span>
                        <Input
                            size="small"
                            data-audio-composer-title
                            aria-label="存入音频库名称"
                            value={audioTitle}
                            onChange={e => {
                                setTitleManuallyEdited(true);
                                setAudioTitle(e.target.value);
                            }}
                            placeholder="如：女主-台词后缀"
                            className="!w-44 !text-xs"
                        />
                    </div>
                </div>

                <div className="flex shrink-0 items-center gap-1.5">
                    <Button
                        type="text"
                        size="small"
                        aria-label="清空音频提示词"
                        title="清空音频提示词"
                        icon={<Trash2 className="size-4" />}
                        onClick={() => setAudioPrompt("")}
                    />
                    {onHidePrompt && (
                        <Button
                            type="text"
                            size="small"
                            aria-label="收起提示词区域"
                            title="隐藏提示词区域"
                            icon={<ChevronDown className="size-4" />}
                            onClick={onHidePrompt}
                        />
                    )}
                    <Button
                        type="primary"
                        data-audio-composer-submit
                        aria-label="开始创作音频"
                        loading={task.busy}
                        onClick={() => void prepareAudioTask()}
                        icon={<ArrowUp className="size-4" />}
                        className="!h-9 !rounded-full !px-4 font-medium"
                    >
                        {task.status === "processing" ? "正在生成配音…" : "开始创作音频"}
                    </Button>
                </div>
            </div>
        </div>
    );
}
