// Preserve diagnostic details separately from the compact gallery message.
export function cleanVideoError(text: string) {
    if (!text || typeof text !== "string") return text;
    if (/The service could not be reached|无法连接到服务/i.test(text)) return "即梦服务连接超时或网络波动，请稍后安全重试";
    if (/The service returned an invalid response/i.test(text)) return "即梦服务响应异常（临时网络波动），请稍后安全重试";
    if (/ExceedConcurrencyLimit|超出并发|并发.*超限/i.test(text)) return "即梦当前并发任务已满，本次请求被拒绝。请等待已有任务结束后再提交。";
    const stripped = text.replace(/^Error invoking remote method '[^']+':\s*(?:Error:\s*)?/, "");
    if (/The service could not be reached|无法连接到服务/i.test(stripped)) return "即梦服务连接超时或网络波动，请稍后安全重试";
    if (/The service returned an invalid response/i.test(stripped)) return "即梦服务响应异常（临时网络波动），请稍后安全重试";
    if (stripped.includes("保存视频节点") && (stripped.includes("服务拒绝该请求") || stripped.includes("The service rejected the request as invalid"))) {
        return stripped.replace(/服务拒绝该请求，认为其无效。请检查命令和输入并重试。/, "请检查该视频组是否有场景/角色等素材尚未添加或未匹配到，或参数超出限制。");
    }
    return stripped;
}
export function videoCardError(text: string) {
    if (!text || typeof text !== "string") return "没有可显示的视频";
    if (/The service could not be reached|无法连接到服务/i.test(text)) return "即梦服务连接超时或网络波动，请稍后安全重试";
    if (/The service returned an invalid response/i.test(text)) return "即梦服务响应异常（临时网络波动），请稍后安全重试";
    const cleaned = cleanVideoError(text);
    if (cleaned.includes("小云雀") && cleaned.includes("视频素材信息缺失")) return "小云雀未能识别参考视频信息。点开详情查看错误。";
    if(cleaned.includes("The service rejected the request as invalid")||cleaned.includes("服务拒绝该请求")||cleaned.includes("素材尚未添加或未匹配到"))return cleaned.includes("计算视频积分")?"即梦计算积分时拒绝了请求。点开详情查看错误编号。":cleaned.includes("保存视频节点")?"即梦未能保存本次视频节点，请检查该视频组是否有场景/角色等素材尚未添加或未匹配到。":"即梦未接受本次请求。点开详情核对参数与素材状态。";
    return cleaned || "没有可显示的视频";
}
