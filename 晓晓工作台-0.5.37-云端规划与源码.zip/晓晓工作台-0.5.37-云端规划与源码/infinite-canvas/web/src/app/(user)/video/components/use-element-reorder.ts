"use client";
import { useEffect, useRef, type RefObject } from "react";

export function useElementReorder(
    ref: RefObject<HTMLElement | null>,
    onReorderScope?: (scope: string, orderedKeys: string[]) => void,
) {
    const callbackRef = useRef(onReorderScope);
    callbackRef.current = onReorderScope;

    useEffect(() => {
        const host = ref.current;
        if (!host) return;
        let timer: ReturnType<typeof setTimeout> | undefined;
        let frame = 0;
        let active = false;
        let activeScope = "";
        let moving = "";
        let original: string[] = [];
        let order: string[] = [];
        let ghost: HTMLElement | null = null;
        let source: HTMLElement | null = null;
        let x = 0;
        let y = 0;
        let startX = 0;
        let startY = 0;
        let offsetX = 0;
        let offsetY = 0;
        let suppress = false;
        let htmlDragKey = "";
        let htmlDragScope = "";

        const scopeNodes = (scope: string) =>
            Array.from(host.querySelectorAll<HTMLElement>("[data-element-sort-key]")).filter(
                el => (el.dataset.elementSortScope || "default") === scope,
            );

        const animate = (scope: string, before: Map<string, DOMRect>) =>
            requestAnimationFrame(() => {
                for (const el of scopeNodes(scope)) {
                    const key = el.dataset.elementSortKey!;
                    const prev = before.get(key);
                    if (!prev) continue;
                    const next = el.getBoundingClientRect();
                    if (Math.abs(prev.x - next.x) > 1 || Math.abs(prev.y - next.y) > 1) {
                        el.animate(
                            [
                                { transform: `translate(${prev.x - next.x}px, ${prev.y - next.y}px)` },
                                { transform: "translate(0, 0)" },
                            ],
                            { duration: 180, easing: "ease-out" },
                        );
                    }
                }
            });

        const clearSourceStyle = () => {
            if (!activeScope || !moving) {
                source?.style.removeProperty("opacity");
                return;
            }
            for (const el of scopeNodes(activeScope)) {
                if (el.dataset.elementSortKey === moving) {
                    el.style.removeProperty("opacity");
                }
            }
            source?.style.removeProperty("opacity");
        };

        const stop = (save: boolean) => {
            clearTimeout(timer);
            cancelAnimationFrame(frame);
            if (active) {
                if (!save && original.length) {
                    callbackRef.current?.(activeScope, original);
                }
                suppress = true;
            }
            clearSourceStyle();
            active = false;
            activeScope = "";
            moving = "";
            ghost?.remove();
            ghost = null;
            source = null;
            host.style.removeProperty("user-select");
            host.style.removeProperty("cursor");
        };

        const tick = () => {
            if (!active || !ghost) return;
            ghost.style.transform = `translate3d(${x - offsetX}px, ${y - offsetY}px, 0)`;
            const scroll = host.closest<HTMLElement>("[data-video-results-scroll], .ant-drawer-body, [data-reference-library]");
            if (scroll) {
                const r = scroll.getBoundingClientRect();
                const edge = 50;
                const delta =
                    y < r.top + edge
                        ? -Math.min(12, (r.top + edge - y) / 4)
                        : y > r.bottom - edge
                          ? Math.min(12, (y - r.bottom + edge) / 4)
                          : 0;
                if (delta) scroll.scrollTop += delta;
            }
            frame = requestAnimationFrame(tick);
        };

        const isInteractiveChild = (target: HTMLElement, tile: HTMLElement) => {
            if (
                target.closest(
                    "input, label, select, audio, [role=checkbox], [data-element-actions], .archive-more, .wb-inline-primary-btn, .wb-inline-ghost-btn, .wb-stack-cycle-pill, .archive-miniatures, .archive-voice, .wb-audio-play-btn, .wb-audio-actions",
                )
            ) {
                return true;
            }
            const btn = target.closest("button");
            if (!btn || !tile.contains(btn)) return false;
            if (
                btn.classList.contains("archive-group-cover") ||
                btn.classList.contains("wb-role-showcase-thumb") ||
                btn.classList.contains("archive-title") ||
                btn.hasAttribute("draggable")
            ) {
                return false;
            }
            return true;
        };

        const down = (e: PointerEvent) => {
            if (!callbackRef.current || e.button !== 0 || e.pointerType === "touch") return;
            const target = e.target as HTMLElement | null;
            if (!target) return;
            const tile = target.closest<HTMLElement>("[data-element-sort-key]");
            if (!tile || isInteractiveChild(target, tile)) return;
            stop(false);
            suppress = false;
            source = tile;
            moving = tile.dataset.elementSortKey || "";
            activeScope = tile.dataset.elementSortScope || "default";
            if (!moving) return;
            x = startX = e.clientX;
            y = startY = e.clientY;
            timer = setTimeout(() => {
                if (!source || !moving) return;
                const nodes = scopeNodes(activeScope);
                if (nodes.length < 2) return;
                original = nodes.map(n => n.dataset.elementSortKey!);
                order = [...original];
                const r = source.getBoundingClientRect();
                offsetX = startX - r.left;
                offsetY = startY - r.top;
                ghost = source.cloneNode(true) as HTMLElement;
                ghost.removeAttribute("data-element-sort-key");
                ghost.removeAttribute("data-element-sort-scope");
                ghost.querySelectorAll("video, audio").forEach(m => m.remove());
                Object.assign(ghost.style, {
                    position: "fixed",
                    left: "0",
                    top: "0",
                    width: `${r.width}px`,
                    height: `${r.height}px`,
                    zIndex: "10000",
                    pointerEvents: "none",
                    opacity: "0.95",
                    boxShadow: "0 12px 32px #0004",
                    borderRadius: "12px",
                });
                document.body.appendChild(ghost);
                source.style.opacity = "0.3";
                host.style.userSelect = "none";
                host.style.cursor = "grabbing";
                active = true;
                tick();
            }, 220);
        };

        const move = (e: PointerEvent) => {
            x = e.clientX;
            y = e.clientY;
            if (!active) {
                if (Math.hypot(x - startX, y - startY) > 8) clearTimeout(timer);
                return;
            }
            e.preventDefault();
            const nodes = scopeNodes(activeScope);
            const currentTile = nodes.find(n => n.dataset.elementSortKey === moving);
            if (currentTile) {
                source = currentTile;
                currentTile.style.opacity = "0.3";
            }
            const target = nodes.find(n => {
                const r = n.getBoundingClientRect();
                return x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
            });
            if (!target || target.dataset.elementSortKey === moving) return;
            const next = [...order];
            const from = next.indexOf(moving);
            const to = next.indexOf(target.dataset.elementSortKey!);
            if (from < 0 || to < 0 || from === to) return;
            const before = new Map(nodes.map(n => [n.dataset.elementSortKey!, n.getBoundingClientRect()]));
            next.splice(from, 1);
            next.splice(to, 0, moving);
            order = next;
            callbackRef.current?.(activeScope, next);
            animate(activeScope, before);
        };

        const up = () => stop(true);
        const cancel = () => stop(false);
        const key = (e: KeyboardEvent) => {
            if (e.key === "Escape") cancel();
        };
        const click = (e: MouseEvent) => {
            if (suppress) {
                e.preventDefault();
                e.stopPropagation();
                suppress = false;
            }
        };
        const getActiveDrag = () => {
            const mem = typeof window !== "undefined" ? (window as any).__activeDraggingElement : null;
            return {
                key: htmlDragKey || mem?.key || mem?.id || "",
                scope: htmlDragScope || mem?.scope || "",
            };
        };
        const dragStart = (e: DragEvent) => {
            if (active) {
                e.preventDefault();
                return;
            }
            clearTimeout(timer);
            const target = e.target as HTMLElement | null;
            const tile = target?.closest<HTMLElement>("[data-element-sort-key]");
            htmlDragKey = tile?.dataset.elementSortKey || "";
            htmlDragScope = tile?.dataset.elementSortScope || "";
        };
        const dragOver = (e: DragEvent) => {
            const { key, scope } = getActiveDrag();
            if (!key || !scope) return;
            const target = e.target as HTMLElement | null;
            const tile = target?.closest<HTMLElement>("[data-element-sort-key]");
            if (!tile || (tile.dataset.elementSortScope || "default") !== scope) return;
            if (tile.dataset.elementSortKey === key) return;
            e.preventDefault();
            if (e.dataTransfer) e.dataTransfer.dropEffect = "move";
        };
        const drop = (e: DragEvent) => {
            const { key, scope } = getActiveDrag();
            if (!key || !scope) return;
            const target = e.target as HTMLElement | null;
            const tile = target?.closest<HTMLElement>("[data-element-sort-key]");
            if (!tile || (tile.dataset.elementSortScope || "default") !== scope) return;
            const toKey = tile.dataset.elementSortKey || "";
            e.preventDefault();
            e.stopPropagation();
            if (toKey && toKey !== key) {
                const nodes = scopeNodes(scope);
                const keys = nodes.map(n => n.dataset.elementSortKey!);
                const from = keys.indexOf(key);
                const to = keys.indexOf(toKey);
                if (from >= 0 && to >= 0 && from !== to) {
                    const before = new Map(nodes.map(n => [n.dataset.elementSortKey!, n.getBoundingClientRect()]));
                    const next = [...keys];
                    next.splice(from, 1);
                    next.splice(to, 0, key);
                    callbackRef.current?.(scope, next);
                    animate(scope, before);
                }
            }
            htmlDragKey = "";
            htmlDragScope = "";
            if (typeof window !== "undefined") delete (window as any).__activeDraggingElement;
        };
        const dragEnd = () => {
            htmlDragKey = "";
            htmlDragScope = "";
            if (typeof window !== "undefined") {
                setTimeout(() => {
                    delete (window as any).__activeDraggingElement;
                }, 80);
            }
        };

        host.addEventListener("pointerdown", down);
        host.addEventListener("click", click, true);
        host.addEventListener("dragstart", dragStart);
        host.addEventListener("dragover", dragOver);
        host.addEventListener("drop", drop);
        host.addEventListener("dragend", dragEnd);
        document.addEventListener("pointermove", move, { passive: false });
        document.addEventListener("pointerup", up);
        document.addEventListener("pointercancel", cancel);
        document.addEventListener("keydown", key);
        window.addEventListener("blur", cancel);
        return () => {
            clearTimeout(timer);
            cancelAnimationFrame(frame);
            ghost?.remove();
            clearSourceStyle();
            host.style.removeProperty("user-select");
            host.style.removeProperty("cursor");
            host.removeEventListener("pointerdown", down);
            host.removeEventListener("click", click, true);
            host.removeEventListener("dragstart", dragStart);
            host.removeEventListener("dragover", dragOver);
            host.removeEventListener("drop", drop);
            host.removeEventListener("dragend", dragEnd);
            document.removeEventListener("pointermove", move);
            document.removeEventListener("pointerup", up);
            document.removeEventListener("pointercancel", cancel);
            document.removeEventListener("keydown", key);
            window.removeEventListener("blur", cancel);
        };
    }, [ref]);
}
