"use client";
import {useEffect,useMemo,useState} from 'react';
import {App,Button,Popover,Select} from 'antd';
import {ChevronLeft,ChevronRight} from 'lucide-react';
import {useVideoStudioStore} from '@/stores/use-video-studio-store';
import {videoColorHex,videoColorsFor} from '../video-colors';
import type {StudioVideoGroup} from '../studio-model';
export function ComposerGroupNavigation({currentId,busy,onLoad,currentBindings}:{currentId:string;busy:boolean;onLoad:(group:StudioVideoGroup)=>Promise<void>;currentBindings?:Record<string,string>}){
 const {message}=App.useApp();
 const groups=useVideoStudioStore(s=>s.groups),placements=useVideoStudioStore(s=>s.placements),projectId=useVideoStudioStore(s=>s.activeProjectId),folderId=useVideoStudioStore(s=>s.folderId),draftBindings=useVideoStudioStore(s=>s.drafts[s.activeProjectId]?.bindings),[loading,setLoading]=useState(false);
 const current=groups.find(g=>g.id===currentId&&g.projectId===projectId),scope=current?.folderId??folderId;
 const items=useMemo(()=>groups.filter(g=>g.projectId===projectId&&(!scope||g.folderId===scope)).slice().sort((a,b)=>a.number.localeCompare(b.number,'zh-CN',{numeric:true})||a.createdAt-b.createdAt),[groups,projectId,scope]);
 const index=items.findIndex(g=>g.id===currentId),disabled=busy||loading;
 const [rangeOpen,setRangeOpen]=useState(false),[startId,setStartId]=useState(''),[endId,setEndId]=useState('');
 useEffect(()=>{
  if(!items.length)return;
  const sIdx=index>=0?index:0;
  setStartId(items[sIdx]?.id||'');
  setEndId(items[Math.min(items.length-1,sIdx+4)]?.id||items[sIdx]?.id||'');
 },[currentId,items.length]);
 const load=async(id:string)=>{const group=items.find(g=>g.id===id);if(!group||disabled)return;setLoading(true);try{await onLoad(group);}finally{setLoading(false);}};
 if(!items.length)return null;
 const activeBindings={...(current?.bindings||{}),...(draftBindings||{}),...(currentBindings||{})};
 const bindingCount=Object.keys(activeBindings).length;
 const applyCostumeRange=()=>{
  const a=items.findIndex(g=>g.id===startId),b=items.findIndex(g=>g.id===endId);
  if(a<0||b<0){message.warning('请选择起始视频组和结束视频组');return;}
  if(!bindingCount){message.warning('当前视频组尚未绑定特定人物服装或参考素材，请先在上方参考区绑定后再锁装');return;}
  const lo=Math.min(a,b),hi=Math.max(a,b),targetIds=new Set(items.slice(lo,hi+1).map(g=>g.id));
  useVideoStudioStore.setState(s=>({
   groups:s.groups.map(g=>targetIds.has(g.id)?{...g,bindings:{...(g.bindings||{}),...activeBindings}}:g),
  }));
  setRangeOpen(false);
  message.success(`已将当前服装/角色绑定锁定到 ${items[lo].number} ~ ${items[hi].number}（共 ${hi-lo+1} 组）`);
 };
 const rangePopover=<div data-costume-range-popover className="w-64 space-y-2.5 text-xs"><div className="font-semibold text-foreground">👗 区间锁装防穿帮（按组锁定服装）</div><p className="text-[11px] leading-relaxed text-muted-foreground">将当前组已绑定的角色服装/参考素材（共 {bindingCount} 项）批量锁定到指定视频组区间，不同桥段可分批锁不同衣服。</p><div className="grid grid-cols-2 gap-2"><label className="space-y-1"><span className="text-[11px] text-muted-foreground">从第几组</span><Select size="small" aria-label="锁装起始视频组" className="w-full" value={startId||undefined} onChange={setStartId} options={items.map(g=>({value:g.id,label:g.number}))}/></label><label className="space-y-1"><span className="text-[11px] text-muted-foreground">到第几组</span><Select size="small" aria-label="锁装结束视频组" className="w-full" value={endId||undefined} onChange={setEndId} options={items.map(g=>({value:g.id,label:g.number}))}/></label></div><Button size="small" type="primary" block data-confirm-costume-range onClick={applyCostumeRange}>一键锁定区间服装绑定</Button></div>;
 return <nav data-composer-group-navigation aria-label="切换视频组" className="inline-flex shrink-0 items-center gap-1"><Button size="small" aria-label="载入上一组" title="载入上一组" className="!h-8 !w-11 !p-0" icon={<ChevronLeft size={14}/>} disabled={disabled||index<=0} onClick={()=>void load(items[index-1].id)}><span className="sr-only">上一组</span></Button><Select size="small" aria-label="当前视频组" className="w-auto min-w-[68px]" popupMatchSelectWidth={false} styles={{popup:{root:{minWidth:260}}}} placeholder="选组" value={current?.id} labelRender={()=>current?<span className="text-xs font-medium">{current.number}</span>:<span className="text-xs text-muted-foreground">选组</span>} disabled={disabled} showSearch optionFilterProp="label" onSelect={id=>void load(id)} options={items.map((g,i)=>({value:g.id,label:g.number+' · '+g.title+'（'+(i+1)+'/'+items.length+'）'}))} optionRender={opt=>{const g=items.find(item=>item.id===opt.data.value);if(!g)return opt.data.label;const activeLogs=g.logIds.filter(id=>!placements[id]?.trashedAt);const groupColors=g.color?[g.color]:Array.isArray(g.colors)&&g.colors.length?[g.colors[0]]:[];const colors=Array.from(new Set([...groupColors,...activeLogs.flatMap(id=>videoColorsFor(id,groups,placements))]));return <span className="flex items-center justify-between gap-2 text-xs"><span className="flex min-w-0 items-center gap-1.5"><span className="truncate">{opt.data.label}</span>{colors.slice(0,3).map(c=><span key={c} className="size-2 shrink-0 rounded-full" style={{background:c==="unusable"?"#ef4444":videoColorHex(c),opacity:0.8,boxShadow:`0 0 6px 1px ${c==="unusable"?"#ef4444":videoColorHex(c)}`}}/>)}</span><span className={`shrink-0 rounded px-1.5 py-0.5 text-[10px] ${activeLogs.length>0?"bg-emerald-500/15 font-medium text-emerald-600 dark:text-emerald-400":"bg-secondary text-muted-foreground"}`}>{activeLogs.length>0?`已生${activeLogs.length}版`:"未生成"}</span></span>;}}/><Button size="small" aria-label="载入下一组" title="载入下一组" className="!h-8 !w-11 !p-0" icon={<ChevronRight size={14}/>} disabled={disabled||index===items.length-1} onClick={()=>void load(items[index+1].id)}><span className="sr-only">下一组</span></Button><Popover trigger="click" placement="top" open={rangeOpen} onOpenChange={setRangeOpen} content={rangePopover}><Button size="small" data-costume-range-lock aria-label="区间锁装防穿帮" title="按视频组区间批量锁定当前人物服装/形象绑定（例如 V01~V08 一套衣服）" className="!h-8 !px-2 !text-xs">👗 锁装</Button></Popover></nav>;
}
