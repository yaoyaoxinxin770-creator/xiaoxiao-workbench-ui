"use client";
import {motion,useReducedMotion} from "motion/react";
import {AgentProviderSettings} from "./agent-provider-settings";
import {AgentInputTools} from "./agent-input-tools";
import {providerModel,clientAgentSettings,type AgentSettings} from "@/lib/agent-models";
import { useEffect, useMemo, useRef, useState } from "react";
import { App, Button, Checkbox, Tag, Tooltip } from "antd";
import {
    Bot,
    Paperclip,
    MessageSquarePlus,
    Check,
    ChevronDown,
    ChevronUp,
    Copy,
    Crosshair,
    History,
    LoaderCircle,
    Maximize2,
    Minimize2,
    PanelLeftClose,
    Pencil,
    Play,
    Plus,
    RotateCcw,
    Send,
    Settings,
    Sparkles,
    Square,
    Trash2,
    Video,
} from "lucide-react";
import { nanoid } from "nanoid";
import { useAssetStore, type Asset } from "@/stores/use-asset-store";
import { useVideoStudioStore } from "@/stores/use-video-studio-store";
import { useConfigStore } from "@/stores/use-config-store";
import { saveDataUrlAsLocalAsset } from "@/services/api/local-assets";
import { getSavedAudioOutputDir } from "./composer-audio-mode";
import { AGENT_PANEL_MAX, AGENT_PANEL_MIN, useWorkbenchLayoutStore } from "@/stores/use-workbench-layout-store";
import {readAgentAttachment,type AgentAttachment} from "../agent-attachments";
import {effortLabel,type AgentModelInfo} from "@/lib/agent-models";
import { diffPromptLines, diffStats } from "../agent-prompt-diff";
import { Input, Modal, Radio, Select, Tabs } from "antd";
import { jsonrepair } from "jsonrepair";

function unescapeClientJsonStr(s: string): string {
    return s
        .replace(/\\n/g, "\n")
        .replace(/\\r/g, "\r")
        .replace(/\\t/g, "\t")
        .replace(/\\"/g, '"')
        .replace(/\\\\/g, "\\")
        .trim();
}

function recoverClientAgentPayload(rawText?: string): {
    mode?: "edit_video" | "extract_or_create" | "chat";
    summary: string;
    changes: string[];
    prompt: string;
    params?: { seconds?: string; size?: string; resolution?: string; model?: string };
} | null {
    const trimmed = String(rawText || "").trim();
    if (!trimmed || !trimmed.includes("{")) return null;
    const firstBrace = trimmed.indexOf("{");
    const lastBrace = trimmed.lastIndexOf("}");
    if (firstBrace < 0 || lastBrace <= firstBrace) return null;
    const slice = trimmed.slice(firstBrace, lastBrace + 1);
    if (!/"(?:prompt|revisedPrompt|summary|changes|mode)"\s*:/i.test(slice)) return null;
    try {
        const parsed = JSON.parse(jsonrepair(slice));
        if (parsed && typeof parsed === "object") {
            const promptText = String(parsed.prompt || parsed.revisedPrompt || parsed.videoPrompt || parsed.content || "").trim();
            const summaryText = String(parsed.summary || "").trim();
            if (promptText || summaryText) {
                const rawMode =
                    parsed.mode === "chat" || parsed.mode === "extract_or_create" || parsed.mode === "edit_video"
                        ? parsed.mode
                        : undefined;
                return {
                    ...(rawMode ? { mode: rawMode } : {}),
                    summary: summaryText || "已按你的要求完成处理。",
                    changes: Array.isArray(parsed.changes)
                        ? parsed.changes.map((c: any) => String(c || "").trim()).filter(Boolean)
                        : [],
                    prompt: promptText,
                    params: parsed.params && typeof parsed.params === "object" ? parsed.params : undefined,
                };
            }
        }
    } catch {
        // Fallback regex extraction for unescaped inner quotes
    }
    const promptMatch = slice.match(
        /"(?:prompt|revisedPrompt|videoPrompt|scenePrompt|content|result|output|text)"\s*:\s*"([\s\S]*?)"\s*(?:,\s*"(?:params|voiceDrafts|audioDrafts|voices)"\s*:\s*[\s\S]*|\s*\})\s*$/i,
    );
    if (!promptMatch?.[1]) return null;
    const modeMatch = slice.match(/"mode"\s*:\s*"(edit_video|extract_or_create|chat)"/i);
    const summaryMatch = slice.match(/"summary"\s*:\s*"([\s\S]*?)"\s*,\s*"(?:changes|prompt|revisedPrompt|videoPrompt|scenes|content|params)"/i);
    const changesMatch = slice.match(/"changes"\s*:\s*\[([\s\S]*?)\]\s*,\s*"(?:prompt|revisedPrompt|videoPrompt|scenes|content|params)"/i);
    const changes = changesMatch?.[1]
        ? Array.from(changesMatch[1].matchAll(/"((?:\\"|[^"])*)"/g))
              .map(m => unescapeClientJsonStr(m[1]))
              .filter(Boolean)
        : [];
    const rawMode = modeMatch?.[1] as "edit_video" | "extract_or_create" | "chat" | undefined;
    return {
        ...(rawMode ? { mode: rawMode } : {}),
        summary: summaryMatch?.[1] ? unescapeClientJsonStr(summaryMatch[1]) : "已按你的要求完成处理。",
        changes,
        prompt: unescapeClientJsonStr(promptMatch[1]),
    };
}

function healAgentMessage(m: AgentMessage, activeIds?: Set<string>): AgentMessage {
    if (!m || typeof m !== "object" || m.role !== "assistant") return m;
    // 若当前存在正在执行中的请求对应此消息，绝不误标为中断残留
    if (activeIds && typeof (activeIds as any).has === "function" && activeIds && activeIds.has(m.id)) return m;
    if (m.status === "running") {
        return {
            ...m,
            status: "error",
            error: "上次思考未完成或已中断，可点击下方「重新发送」或修改后重发",
            steps: m.steps?.map(s => (s.status === "running" ? { ...s, status: "error", label: s.label.endsWith("（已中断）") ? s.label : s.label + "（已中断）" } : s)),
            stepsOpen: true,
        };
    }
    if (m.status === "error" && m.error) {
        const rec = recoverClientAgentPayload(m.error);
        if (rec && (rec.prompt || rec.summary)) {
            return {
                ...m,
                status: "done",
                error: undefined,
                mode: rec.mode || m.mode || "edit_video",
                summary: rec.summary,
                changes: rec.changes,
                revisedPrompt: rec.prompt,
                revisedParams: rec.params || m.revisedParams,
                steps: m.steps?.map(s => ({ ...s, status: "done" })),
                stepsOpen: false,
            };
        }
    }
    return m;
}

export type AgentTargetInfo = {
    id?: string;
    title: string;
    prompt: string;
    seconds?: string;
    size?: string;
    resolution?: string;
    model?: string;
};

type AgentStep = {
    label: string;
    tag: string;
    status: "pending" | "running" | "done" | "error";
};

export type SeedAudioVoiceDraft = {
    roleName: string;
    voiceSpec: string;
    lineText: string;
    audioPrompt: string;
    scenario?: "omni-dubbing" | "text-reading";
    voiceName?: string;
};

type AgentMessage = {
    id: string;
    role: "user" | "assistant";
    text: string;
    targetTitle?: string;
    targetId?: string;
    targetVideos?: { id?: string; title: string }[];
    sentImages?: { id: string; name: string; dataUrl: string }[];
    createdAt: number;
    status?: "running" | "done" | "error";
    steps?: AgentStep[];
    stepsOpen?: boolean;
    summary?: string;
    changes?: string[];
    revisedPrompt?: string;
    revisedParams?: { seconds?: string; size?: string; resolution?: string; model?: string };
    voiceDrafts?: SeedAudioVoiceDraft[];
    mode?: "edit_video" | "extract_or_create" | "chat";
    /** 发送指令时的原提示词，仅用于显示修改对比。 */
    originalPrompt?: string;
    applied?: boolean;
    error?: string;
};

type Props = {
    projectId: string;
    projectName: string;
    globalPrompt?: string;
    projectAssets: Asset[];
    elementRules?: Record<string, { disabled?: boolean }>;
    target: AgentTargetInfo;
    targets?: AgentTargetInfo[];
    onRemoveTarget?: (id: string) => void;
    onLinkCurrentDraft?: () => void;
    pendingAttachments?: any[];
    onConsumePendingAttachments?: () => void;
    pendingNote?: { text: string; autoSend?: boolean; nonce: number } | null;
    onConsumePendingNote?: () => void;
    onApplyResult: (payload: {
        prompt: string;
        params?: { seconds?: string; size?: string; resolution?: string; model?: string };
        autoStart?: boolean;
    }) => void;
    onClose: () => void;
    /** 侧栏正在收起：立即停止本次思考（与卸载时相同），并播放收起动画。 */
    closing?: boolean;
    /** 在视频台中定位并高亮当前目标视频。 */
    onLocateTarget?: () => void;
    /** 切换历史会话或跨视频回填时同步载入对应的视频组（含原参考素材还原）。 */
    onLoadTargetId?: (targetId: string) => void | Promise<void>;
};

type QuickPromptItem = { id: string; label: string; text: string };

const DEFAULT_QUICK_PROMPTS: QuickPromptItem[] = [
    { id: "1", label: "修画面/动作毛病", text: "这个视频出来的画面动作有点怪，请帮我优化动作与镜头稳定性描述，避免人物肢体变形或乱动，保留原有剧情和@素材。" },
    { id: "2", label: "稳住眼神与面部", text: "请强化人物面部表情和眼神稳定度描述，保持视线聚焦自然、五官稳定不崩坏，保留原有分镜与@素材。" },
    { id: "3", label: "精简防吞字", text: "当前提示词有点太碎，请帮我精简紧凑润色，保留核心动作、台词和所有@素材引用。" },
    { id: "4", label: "改4秒快节奏", text: "帮我把这段视频改成4秒的紧凑版本，同步调整里面的分镜时间段，保留核心画面。" },
    { id: "5", label: "🎙️ 路人4秒商用音色 (SeedAudio)", text: "请为当前视频中缺少音频的路人/配角，结合其形象定制一个4秒可商用音色生成方案（SeedAudio 1.0），提示词要求：口齿清晰，咬字准确，根据形象生成适配的音色，说完上句台词，立马说下一句台词，台词：这是我授权可商用的音色，阳光真好啊" },
    { id: "6", label: "🎭 补台词·原音色情绪配音", text: "请根据台词上下文推断角色情绪，生成 SeedAudio 1.0 配音方案，提示词要求：保持原音色，根据台词推断情绪，使用情绪进行配音" },
];

export type AgentModelSettings=AgentSettings;

const MotionButton=motion.create(Button);
export function CodexAgentPanel({
    projectId,
    projectName,
    globalPrompt,
    projectAssets,
    elementRules,
    target,
    targets,
    onRemoveTarget,
    onLinkCurrentDraft,
    pendingAttachments,
    onConsumePendingAttachments,
    pendingNote,
    onConsumePendingNote,
    onApplyResult,
    onClose,
    closing = false,
    onLocateTarget,
    onLoadTargetId,
}: Props) {
    const { message } = App.useApp();
    const reduceMotion=useReducedMotion();
    const effectiveTargets = useMemo(() => (targets && targets.length > 0 ? targets : []), [targets]);
    const hasEffectiveTarget = effectiveTargets.length > 0;
    const combinedTarget = useMemo<AgentTargetInfo>(() => {
        if (!hasEffectiveTarget) {
            return {
                id: "",
                title: "",
                prompt: "",
            };
        }
        if (effectiveTargets.length === 1) return effectiveTargets[0];
        return {
            ...effectiveTargets[0],
            id: effectiveTargets[effectiveTargets.length - 1]?.id || effectiveTargets[0].id,
            title: effectiveTargets.map(t => t.title || "视频").join(" + "),
            prompt: effectiveTargets.map((t, idx) => `=== 关联视频 ${idx + 1}：${t.title || "视频"} ===\n${t.prompt || ""}`).join("\n\n"),
        };
    }, [effectiveTargets, hasEffectiveTarget]);
    const [skillIds,setSkillIds]=useState<string[]|undefined>(),[draggingFiles,setDraggingFiles]=useState(false);
    useEffect(()=>{const clear=()=>setDraggingFiles(false);window.addEventListener("drop",clear,true);window.addEventListener("dragend",clear);window.addEventListener("blur",clear);return()=>{window.removeEventListener("drop",clear,true);window.removeEventListener("dragend",clear);window.removeEventListener("blur",clear);};},[]);
    const configChannels = useConfigStore(s => s.config.localChannels || []);
    const panelWidth = useWorkbenchLayoutStore(s => s.agentPanelWidth);
    const setPanelWidth = useWorkbenchLayoutStore(s => s.setAgentPanelWidth);
    const wide = panelWidth >= 460;
    const [resizing, setResizing] = useState(false);
    const resizeRef = useRef<{ x: number; width: number; frame: number; next?: number } | null>(null);
    const [resultViews, setResultViews] = useState<Record<string, "diff" | "full">>({});
    const [autoApply, setAutoApply] = useState(true);
    const [chatOnlyMode, setChatOnlyMode] = useState(false);
    const autoApplyRef = useRef(autoApply);
    autoApplyRef.current = autoApply;
    const [input, setInput] = useState("");
    const [busy, setBusy] = useState(false);
    const [codexStatus, setCodexStatus] = useState<{
        available: boolean;
        authenticated: boolean;
        source: string;
        models?: { slug: string; name: string; efforts?: string[]; defaultEffort?: string; isDefault?: boolean }[];
        agy?: { available: boolean; authenticated: boolean; models?: { slug: string; name: string; efforts?: string[]; defaultEffort?: string }[] };
    } | null>(null);
    const activeControllersRef = useRef<Map<string, AbortController>>(new Map());
    const [sessionsLoadError, setSessionsLoadError] = useState(false);
    const [messagesByProject, setMessagesByProject] = useState<Record<string, AgentMessage[]>>(() => {
        try {
            const raw = localStorage.getItem("xiaoxiao:agent-sessions");
            if (!raw) return {};
            const parsed = JSON.parse(raw);
            if (!parsed || typeof parsed !== "object") return {};
            const res: Record<string, AgentMessage[]> = {};
            for (const [k, list] of Object.entries(parsed)) {
                if (Array.isArray(list) && list[0]?.messages && Array.isArray(list[0].messages)) {
                    res[k] = list[0].messages
                        .filter((m: any) => m && typeof m === "object")
                        .map((m: any) => healAgentMessage(m));
                }
            }
            return res;
        } catch {
            return {};
        }
    });
    const messages = useMemo(() => {
        const list = messagesByProject[projectId] || [];
        const activeIds = new Set(activeControllersRef.current.keys());
        return list.map(m => healAgentMessage(m, activeIds));
    }, [messagesByProject, projectId, busy]);
    const [sessionsByProject, setSessionsByProject] = useState<Record<string, { id: string; title: string; customTitle?: boolean; targetTitle?: string; targetId?: string; updatedAt: number; messages: AgentMessage[] }[]>>(() => {
        try {
            const raw = localStorage.getItem("xiaoxiao:agent-sessions");
            if (!raw) return {};
            const parsed = JSON.parse(raw);
            if (!parsed || typeof parsed !== "object") return {};
            const healed: Record<string, any[]> = {};
            for (const [k, list] of Object.entries(parsed)) {
                if (!Array.isArray(list)) continue;
                const safeList: any[] = [];
                for (const sess of list) {
                    try {
                        if (!sess || typeof sess !== "object") continue;
                        const msgs = Array.isArray(sess.messages)
                            ? sess.messages
                                .filter((m: any) => m && typeof m === "object")
                                .map((m: any) => healAgentMessage(m))
                            : [];
                        safeList.push({
                            ...sess,
                            id: String(sess.id || nanoid()),
                            title: String(sess.title || "历史对话"),
                            updatedAt: Number(sess.updatedAt) || Date.now(),
                            messages: msgs,
                        });
                    } catch (sessErr) {
                        console.warn("[Agent] 单条历史会话解析异常，已跳过该条保留其余会话:", sessErr);
                    }
                }
                healed[k] = safeList;
            }
            return healed;
        } catch (err) {
            console.error("[Agent] 历史会话整体读取失败，已启动防覆盖保护:", err);
            setSessionsLoadError(true);
            if (typeof window !== "undefined") {
                (window as any).__AGENT_SESSIONS_LOAD_ERROR__ = true;
            }
            return {};
        }
    });
    const [activeSessionByProject, setActiveSessionByProject] = useState<Record<string, string>>({});
    const [sessionsViewOpen, setSessionsViewOpen] = useState(false);
    const [editingSessionId, setEditingSessionId] = useState<string | null>(null);
    const [editingSessionTitle, setEditingSessionTitle] = useState("");
    const projectSessions = sessionsByProject[projectId] || [];
    const activeSessionId = activeSessionByProject[projectId] || "";
    const scrollRef = useRef<HTMLDivElement>(null);
    const inputRef = useRef<HTMLTextAreaElement>(null);
    const attachmentInput=useRef<HTMLInputElement>(null);
    const [attachments,setAttachments]=useState<(AgentAttachment & { previewUrl?: string })[]>([]),[readingFiles,setReadingFiles]=useState(false);
    const attachmentTarget=useRef(projectId+":"+target.id);attachmentTarget.current=projectId+":"+target.id;
    const attachmentEpoch=useRef(0),readingRef=useRef(false);
    useEffect(()=>{attachmentEpoch.current++;readingRef.current=false;setReadingFiles(false);setAttachments([]);setInput("");},[projectId]);
    const addAttachments=async(files:File[])=>{const origin=attachmentTarget.current,epoch=attachmentEpoch.current;if(readingRef.current)return;if(files.some(f=>/\.(png|jpe?g|webp)$/i.test(f.name))&&(modelSettings.provider==="custom"&&!providerModel(modelSettings.customApi)?.inputModalities.includes("image"))){message.error("当前模型不支持图片输入");return;}if(attachments.length+files.length>6){message.error("每次最多添加6个附件");return;}readingRef.current=true;setReadingFiles(true);try{const items=await Promise.all(files.map(f=>readAgentAttachment(f)));if(origin===attachmentTarget.current&&epoch===attachmentEpoch.current)setAttachments(prev=>[...prev,...items]);}catch(e){message.error(e instanceof Error?e.message:"附件读取失败");}finally{if(epoch===attachmentEpoch.current){readingRef.current=false;setReadingFiles(false);}}};
    const latestTarget = useRef({projectId, ...combinedTarget});
    latestTarget.current={projectId, ...combinedTarget};
    useEffect(() => () => {
        for (const ctrl of activeControllersRef.current.values()) ctrl.abort();
        activeControllersRef.current.clear();
        setBusy(false);
    }, [projectId]);
    useEffect(() => {
        if (!closing) return;
        for (const ctrl of activeControllersRef.current.values()) ctrl.abort();
        activeControllersRef.current.clear();
        setBusy(false);
    }, [closing]);

    // Quick prompts state
    const [quickPrompts, setQuickPrompts] = useState<QuickPromptItem[]>(() => {
        try {
            const raw = localStorage.getItem("xiaoxiao:agent-quick-prompts");
            if (raw) {
                const parsed = JSON.parse(raw);
                if (Array.isArray(parsed) && parsed.length > 0) {
                    const existingLabels = new Set(parsed.map((p: any) => String(p?.label || "").trim()));
                    const missingDefaults = DEFAULT_QUICK_PROMPTS.filter(
                        d => (d.id === "5" || d.id === "6") && !existingLabels.has(d.label),
                    );
                    return missingDefaults.length ? [...parsed, ...missingDefaults] : parsed;
                }
            }
        } catch {}
        return DEFAULT_QUICK_PROMPTS;
    });
    const [managePromptsOpen, setManagePromptsOpen] = useState(false);
    const [editingPrompts, setEditingPrompts] = useState<QuickPromptItem[]>([]);
    const [selectedQuickPrompt, setSelectedQuickPrompt] = useState<QuickPromptItem | null>(null);

    // Model settings state
    const [modelSettings, setModelSettings] = useState<AgentModelSettings>(() => {
        try {
            const raw = localStorage.getItem("xiaoxiao:agent-model-settings");
            if (raw) {
                const parsed = JSON.parse(raw);
                if (parsed && typeof parsed === "object") return parsed;
            }
        } catch {}
        return { provider: "codex", codexModel: "" };
    });
    const [modelModalOpen, setModelModalOpen] = useState(false);
    const [tempSettings, setTempSettings] = useState<AgentModelSettings>(modelSettings);

    const attachAssetToAgent = async (asset: any) => {
        const assetTitle = String(asset?.title || asset?.name || "资产素材").trim();
        const category = String(asset?.category || asset?.kind || "素材").trim();
        const rawUrl = String(asset?.dataUrl || asset?.url || asset?.data?.dataUrl || asset?.data?.url || asset?.coverUrl || "");
        const isVideoAsset = asset?.kind === "video" || /\.(mp4|webm|mov)(?:[?#]|$)/i.test(rawUrl) || /^data:video\//i.test(rawUrl);
        let dataUrl: string | undefined;
        const supportsVision = modelSettings.provider !== "custom" || Boolean(providerModel(modelSettings.customApi)?.inputModalities.includes("image"));
        if (supportsVision && rawUrl) {
            if (/^data:image\/(png|jpe?g|webp);base64,/i.test(rawUrl) && rawUrl.length < 3500000) {
                dataUrl = rawUrl;
            } else if (isVideoAsset) {
                try {
                    dataUrl = await new Promise<string>((resolve, reject) => {
                        const vid = document.createElement("video");
                        vid.crossOrigin = "anonymous";
                        vid.muted = true;
                        vid.playsInline = true;
                        vid.preload = "auto";
                        const timer = setTimeout(() => reject(new Error("视频抽帧超时")), 6000);
                        const capture = () => {
                            clearTimeout(timer);
                            try {
                                const w = vid.videoWidth || 512;
                                const h = vid.videoHeight || 512;
                                const maxSide = 1024;
                                const scale = Math.min(1, maxSide / Math.max(w, h, 1));
                                const canvas = document.createElement("canvas");
                                canvas.width = Math.max(1, Math.round(w * scale));
                                canvas.height = Math.max(1, Math.round(h * scale));
                                const ctx = canvas.getContext("2d");
                                ctx?.drawImage(vid, 0, 0, canvas.width, canvas.height);
                                vid.removeAttribute("src");
                                vid.load();
                                resolve(canvas.toDataURL("image/jpeg", 0.85));
                            } catch (e) {
                                reject(e);
                            }
                        };
                        vid.onloadeddata = () => {
                            if (vid.duration > 0.15) {
                                vid.onseeked = capture;
                                vid.currentTime = 0.1;
                            } else {
                                capture();
                            }
                        };
                        vid.onerror = () => {
                            clearTimeout(timer);
                            reject(new Error("视频加载失败"));
                        };
                        vid.src = rawUrl;
                    });
                } catch {
                    dataUrl = undefined;
                }
            } else {
                try {
                    dataUrl = await new Promise<string>((resolve, reject) => {
                        const img = new Image();
                        img.crossOrigin = "anonymous";
                        img.onload = () => {
                            const maxSide = 1024;
                            const scale = Math.min(1, maxSide / Math.max(img.naturalWidth || 1, img.naturalHeight || 1));
                            const canvas = document.createElement("canvas");
                            canvas.width = Math.max(1, Math.round((img.naturalWidth || 512) * scale));
                            canvas.height = Math.max(1, Math.round((img.naturalHeight || 512) * scale));
                            const ctx = canvas.getContext("2d");
                            ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
                            resolve(canvas.toDataURL("image/jpeg", 0.85));
                        };
                        img.onerror = () => reject(new Error("图片加载失败"));
                        img.src = rawUrl;
                    });
                } catch {
                    try {
                        const res = await fetch(rawUrl);
                        const blob = await res.blob();
                        const bmp = await createImageBitmap(blob);
                        const maxSide = 1024;
                        const scale = Math.min(1, maxSide / Math.max(bmp.width || 1, bmp.height || 1));
                        const canvas = document.createElement("canvas");
                        canvas.width = Math.max(1, Math.round((bmp.width || 512) * scale));
                        canvas.height = Math.max(1, Math.round((bmp.height || 512) * scale));
                        const ctx = canvas.getContext("2d");
                        ctx?.drawImage(bmp, 0, 0, canvas.width, canvas.height);
                        bmp.close();
                        dataUrl = canvas.toDataURL("image/jpeg", 0.85);
                    } catch {
                        dataUrl = undefined;
                    }
                }
            }
        }
        const safePreviewUrl = dataUrl || (!isVideoAsset && rawUrl ? rawUrl : undefined);
        let added = false;
        setAttachments(prev => {
            if (prev.length >= 6) {
                message.error("每次最多添加6个附件");
                return prev;
            }
            if (prev.some(item => item.name === assetTitle)) return prev;
            added = true;
            return [
                ...prev,
                {
                    id: nanoid(),
                    name: assetTitle,
                    type: "image/jpeg",
                    previewUrl: safePreviewUrl,
                    dataUrl,
                    text: `资产素材：@${assetTitle}（分类：${category}）`,
                },
            ];
        });
        inputRef.current?.focus();
        if (added && !asset?.silent) {
            message.success(`已将素材「${assetTitle}」添加到 Agent 输入框`);
        }
    };
    const attachAssetRef = useRef(attachAssetToAgent);
    attachAssetRef.current = attachAssetToAgent;
    useEffect(() => {
        if (!pendingAttachments || pendingAttachments.length === 0) return;
        const items = [...pendingAttachments];
        onConsumePendingAttachments?.();
        void (async () => {
            for (const item of items) {
                await attachAssetRef.current(item);
            }
        })();
    }, [pendingAttachments, onConsumePendingAttachments]);
    useEffect(() => {
        if (!pendingNote) return;
        const note = pendingNote;
        onConsumePendingNote?.();
        if (note.text) {
            setInput(prev => (prev.trim() ? `${prev.trim()}\n${note.text}` : note.text));
            setTimeout(() => inputRef.current?.focus(), 60);
        }
    }, [pendingNote, onConsumePendingNote]);

    const saveSessionsToStorage = (next: typeof sessionsByProject) => {
        if (sessionsLoadError || (typeof window !== "undefined" && (window as any).__AGENT_SESSIONS_LOAD_ERROR__)) {
            console.error("[Agent] 历史会话加载异常保护生效中，禁止写回 localStorage 避免覆盖真实数据！");
            return;
        }
        try {
            localStorage.setItem("xiaoxiao:agent-sessions", JSON.stringify(next));
        } catch {}
    };

    const updateMessages = (updater: (prev: AgentMessage[]) => AgentMessage[]) => {
        setMessagesByProject(prev => {
            const nextMsgs = updater(prev[projectId] || []);
            if (nextMsgs.length > 0) {
                const sid = activeSessionByProject[projectId] || nanoid();
                if (!activeSessionByProject[projectId]) {
                    setActiveSessionByProject(s => ({ ...s, [projectId]: sid }));
                }
                const firstUser = nextMsgs.find(m => m.role === "user");
                const sessionTitle = (firstUser?.text || "Agent 对话").replace(/\s+/g, " ").slice(0, 36);
                const sessionTarget = firstUser ? firstUser.targetTitle : (hasEffectiveTarget ? combinedTarget.title : undefined);
                const sessionTargetId = firstUser ? firstUser.targetId : (hasEffectiveTarget ? combinedTarget.id : undefined);
                setSessionsByProject(sp => {
                    const list = sp[projectId] || [];
                    const existingIdx = list.findIndex(item => item.id === sid);
                    const prevItem = existingIdx >= 0 ? list[existingIdx] : undefined;
                    const updatedItem = {
                        id: sid,
                        title: prevItem?.customTitle ? prevItem.title : sessionTitle,
                        customTitle: prevItem?.customTitle,
                        targetTitle: sessionTarget,
                        targetId: sessionTargetId,
                        updatedAt: Date.now(),
                        messages: nextMsgs,
                    };
                    const nextList = existingIdx >= 0 ? list.map((item, i) => (i === existingIdx ? updatedItem : item)) : [updatedItem, ...list].slice(0, 30);
                    const nextAll = { ...sp, [projectId]: nextList };
                    saveSessionsToStorage(nextAll);
                    return nextAll;
                });
            }
            return {
                ...prev,
                [projectId]: nextMsgs,
            };
        });
    };

    const renameSession = (sessionId: string, nextTitle: string) => {
        const cleaned = nextTitle.trim();
        if (!cleaned) {
            setEditingSessionId(null);
            return;
        }
        setSessionsByProject(sp => {
            const nextList = (sp[projectId] || []).map(item =>
                item.id === sessionId ? { ...item, title: cleaned, customTitle: true } : item,
            );
            const nextAll = { ...sp, [projectId]: nextList };
            saveSessionsToStorage(nextAll);
            return nextAll;
        });
        setEditingSessionId(null);
        message.success("已更新会话名称");
    };

    const startNewSession = () => {
        attachmentEpoch.current++;
        readingRef.current = false;
        setReadingFiles(false);
        setActiveSessionByProject(s => ({ ...s, [projectId]: nanoid() }));
        setMessagesByProject(prev => ({ ...prev, [projectId]: [] }));
        setInput("");
        setAttachments([]);
        setSelectedQuickPrompt(null);
        setSessionsViewOpen(false);
    };

    const switchSession = (session: { id: string; targetId?: string; messages: AgentMessage[] }) => {
        setActiveSessionByProject(s => ({ ...s, [projectId]: session.id }));
        setMessagesByProject(prev => ({ ...prev, [projectId]: session.messages }));
        setSessionsViewOpen(false);
        // 切换历史会话仅查看之前与 AI 的对话内容，不自动跳转右侧视频组
    };

    const deleteSession = (sessionId: string) => {
        setSessionsByProject(sp => {
            const nextList = (sp[projectId] || []).filter(item => item.id !== sessionId);
            const nextAll = { ...sp, [projectId]: nextList };
            saveSessionsToStorage(nextAll);
            return nextAll;
        });
        if (activeSessionId === sessionId) {
            setActiveSessionByProject(s => ({ ...s, [projectId]: "" }));
            setMessagesByProject(prev => ({ ...prev, [projectId]: [] }));
        }
    };

    useEffect(() => {
        fetch("/api/codex-agent/settings").then(r=>r.json()).then(async d=>{if(d.ok&&!d.settings){const previous=localStorage.getItem("xiaoxiao:agent-model-settings");if(previous){const r=await fetch("/api/codex-agent/settings",{method:"POST",headers:{"Content-Type":"application/json"},body:previous});d=await r.json();}}if(d.ok&&d.settings){const settings={...d.settings,customApi:d.settings.customApi?{...d.settings.customApi,useSavedKey:true}:undefined};setModelSettings(settings);setTempSettings(settings);localStorage.setItem("xiaoxiao:agent-model-settings",JSON.stringify(clientAgentSettings(settings)));}}).catch(()=>{});
        fetch("/api/codex-agent")
            .then(r => r.json())
            .then(data => {
                if (data?.ok) setCodexStatus(data);
            })
            .catch(() => {});
    }, []);

    useEffect(() => {
        const el = scrollRef.current;
        if (el) el.scrollTop = el.scrollHeight;
    }, [messages.length, busy]);

    const stopThinking = (specificId?: string) => {
        if (specificId) {
            const ctrl = activeControllersRef.current.get(specificId);
            if (ctrl) {
                ctrl.abort();
                activeControllersRef.current.delete(specificId);
            }
            setBusy(activeControllersRef.current.size > 0);
            updateMessages(prev =>
                prev.map(m =>
                    m.id === specificId && m.status === "running"
                        ? {
                              ...m,
                              status: "done",
                              summary: "已暂停该条 Agent 思考。",
                              error: undefined,
                              steps: m.steps?.map(s => (s.status === "running" ? { ...s, label: s.label + "（已暂停）", status: "done" } : s)),
                          }
                        : m,
                ),
            );
            message.success("已暂停该条 Agent 思考");
            return;
        }
        for (const ctrl of activeControllersRef.current.values()) {
            ctrl.abort();
        }
        activeControllersRef.current.clear();
        setBusy(false);
        updateMessages(prev =>
            prev.map(m =>
                m.status === "running"
                    ? {
                          ...m,
                          status: "done",
                          summary: "已暂停 Agent 思考。",
                          error: undefined,
                          steps: m.steps?.map(s => (s.status === "running" ? { ...s, label: s.label + "（已暂停）", status: "done" } : s)),
                      }
                    : m,
            ),
        );
        message.success("已停止 Agent 思考");
    };

    const sendInstruction = async (customText?: string) => {
        const activeQuick = customText ? null : selectedQuickPrompt;
        const rawTyped = (customText ?? input).trim();
        if(readingFiles)return;
        if(attachments.some(a=>a.dataUrl)){const model=providerModel(modelSettings.customApi);if(modelSettings.provider==="custom"&&!model?.inputModalities.includes("image")){message.error("请选择模型列表中支持图像输入的API模型后发送图片");return;}}
        if (!rawTyped && !activeQuick && attachments.length === 0) return;
        if (!customText) setInput("");
        setSelectedQuickPrompt(null);

        const displayText = activeQuick
            ? (rawTyped ? `【${activeQuick.label}】${rawTyped}` : `【${activeQuick.label}】`)
            : (rawTyped || "请识别并分析我上传的图片内容");
        const fullInstruction = activeQuick
            ? (rawTyped ? `${activeQuick.text}\n\n【用户补充修改要求（最高优先级）】：\n${rawTyped}` : activeQuick.text)
            : (rawTyped || "请仔细识别并分析我上传的图片内容，结合当前上下文给出解答或修改建议。");
        const allowVoiceDrafts = Boolean(
            activeQuick?.id === "5" ||
            activeQuick?.id === "6" ||
            /SeedAudio|商用音色|情绪配音/i.test(activeQuick?.label || "") ||
            /(SeedAudio|生成.*配音|定制.*音色|补.*配音|做.*配音|配音方案)/i.test(rawTyped)
        );

        const completedMsgs = messages.filter(m => m.status !== "running" && (m.text || m.summary || m.revisedPrompt));
        const lastAssistant = [...completedMsgs].reverse().find(m => m.role === "assistant");
        const snapshotTarget = { ...combinedTarget };
        const snapshotAttachments = [...attachments];
        const sentImages = snapshotAttachments
            .filter(a => a.dataUrl || a.previewUrl)
            .map(a => ({ id: a.id, name: a.name, dataUrl: (a.dataUrl || a.previewUrl)! }));
        if (sentImages.length > 0) {
            setAttachments(prev => prev.filter(a => !a.dataUrl && !a.previewUrl));
        }

        const hasTarget = effectiveTargets.length > 0 && !chatOnlyMode;
        const userMsg: AgentMessage = {
            id: nanoid(),
            role: "user",
            text: displayText,
            targetTitle: chatOnlyMode ? "纯聊天对话" : hasTarget ? snapshotTarget.title : undefined,
            targetId: chatOnlyMode ? undefined : hasTarget ? snapshotTarget.id : undefined,
            targetVideos: chatOnlyMode ? undefined : hasTarget ? effectiveTargets.map(t => ({ id: t.id, title: t.title || "当前提示词框" })) : undefined,
            sentImages: sentImages.length > 0 ? sentImages : undefined,
            createdAt: Date.now(),
        };
        const assistantId = nanoid();
        const activeCustomProvider =
            modelSettings.providers?.find(p => p.id === modelSettings.activeProviderId) ||
            modelSettings.customApi;
        const activeReasoningEffort =
            modelSettings.provider === "codex"
                ? (modelSettings.codexEfforts?.[modelSettings.codexModel || "auto"] || "default")
                : modelSettings.provider === "agy"
                  ? (modelSettings.agyEfforts?.[modelSettings.agyModel || "gemini-4-argon"] || "default")
                  : (activeCustomProvider?.efforts?.[activeCustomProvider?.model || ""] ??
                     (!activeCustomProvider?.efforts ? activeCustomProvider?.reasoningEffort : undefined));

        const initialSteps: AgentStep[] = [
            { label: chatOnlyMode ? "读取当前对话上下文与历史记忆" : hasTarget ? `读取目标视频 ${snapshotTarget.title}` : "读取当前对话上下文与历史记忆", tag: "Canvas", status: "done" },
            { label: "核对当前项目角色与场景资产库", tag: "Assets", status: "done" },
            { label: modelSettings.provider === "custom" ? `调用自定义 API (${activeCustomProvider?.model || "API"})` : modelSettings.provider === "agy" ? `调用本机 Antigravity CLI (${modelSettings.agyModel || "gemini-4-argon"})` : "调用本机 Codex 额度分析并改写提示词", tag: modelSettings.provider === "custom" ? "API" : modelSettings.provider === "agy" ? "AGY" : "Codex", status: "running" },
            { label: "生成回复与提示词建议", tag: "Tool", status: "pending" },
        ];
        const placeholderMsg: AgentMessage = {
            id: assistantId,
            role: "assistant",
            text: "",
            targetTitle: chatOnlyMode ? "纯聊天对话" : hasTarget ? snapshotTarget.title : undefined,
            targetId: chatOnlyMode ? undefined : hasTarget ? snapshotTarget.id : undefined,
            createdAt: Date.now(),
            status: "running",
            steps: initialSteps,
            stepsOpen: true,
            originalPrompt: hasTarget ? snapshotTarget.prompt : (lastAssistant?.revisedPrompt || ""),
        };

        updateMessages(prev => [...prev, userMsg, placeholderMsg]);
        const controller = new AbortController();
        activeControllersRef.current.set(assistantId, controller);
        setBusy(true);

        const origin={projectId, ...snapshotTarget};
        // 根据服务商与思考强度动态计算前端超时兜底，防止误杀深度推演
        const getClientTimeout = () => {
            if (modelSettings.provider === "agy") {
                // agy CLI 服务端限制 180s，前端设置 195s（3分15秒）防止网络/进程挂起
                return {
                    ms: 195000,
                    text: "Antigravity CLI 思考响应超时（已等待超过 3 分钟），建议将思考强度调低后重试",
                };
            }
            if (modelSettings.provider === "codex") {
                // 本机 Codex 服务端限制 20 分钟（1200s），前端留足 20 分 15 秒
                return {
                    ms: 1215000,
                    text: "本机 Codex 响应超时（已等待超过 20 分钟），请检查本机 Codex 运行状态或稍后重试",
                };
            }
            // 自定义 API（如 DeepSeek、Gemini 等）
            const effort = activeReasoningEffort;
            if (effort === "max" || effort === "ultra" || effort === "xhigh") {
                // 极致/超高档位长剧本深度推理（规则第 48 条规定 20 分钟续航）
                return {
                    ms: 1200000,
                    text: "自定义 API 深度思考超时（已等待超过 20 分钟），建议将思考档位调至「高」或「中」后重试",
                };
            }
            if (effort === "high" || effort === "medium") {
                // 高/中档位长剧本推演留足 10 分钟
                return {
                    ms: 600000,
                    text: "自定义 API 思考超时（已等待超过 10 分钟），建议将思考档位调低或稍后重试",
                };
            }
            // 低/极低/默认/关闭思考：5000+字长输入生成留足 5 分钟
            return {
                ms: 300000,
                text: "自定义 API 响应超时（已等待超过 5 分钟），请检查网络连接或对方模型服务器状态",
            };
        };
        const clientTimeoutConfig = getClientTimeout();
        let clientTimedOut = false;
        let clientTimeoutTimer: any = null;

        try {
            clientTimeoutTimer = setTimeout(() => {
                clientTimedOut = true;
                controller.abort();
            }, clientTimeoutConfig.ms);

            const activeAssets = projectAssets
                .filter(a => !elementRules?.[a.id]?.disabled)
                .map(a => ({
                    title: a.title,
                    category: a.category || a.kind,
                    aliases: Array.isArray(a.metadata?.elementAliases) ? a.metadata.elementAliases : [],
                }));

            const history = completedMsgs
                .slice(-8)
                .map(m => ({
                    role: m.role,
                    text:
                        m.role === "user"
                            ? m.text
                            : m.mode === "extract_or_create"
                              ? `${m.summary || ""}\n${(m.revisedPrompt || "").slice(0, 1200)}`.trim()
                              : [m.summary || "", ...(m.changes || []).map(c => `- ${c}`)].filter(Boolean).join("\n"),
                }));

            let res: Response;
            try {
                res = await fetch("/api/codex-agent", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    signal: controller.signal,
                    body: JSON.stringify({
                        instruction: fullInstruction,
                        allowVoiceDrafts,
                        backend: modelSettings.provider === "custom" ? "custom-api" : modelSettings.provider === "agy" ? "agy" : "codex",
                        model: modelSettings.provider === "codex" ? (modelSettings.codexModel || "") : modelSettings.provider === "agy" ? (modelSettings.agyModel || "gemini-4-argon") : undefined,
                        customApi: modelSettings.provider === "custom" ? activeCustomProvider : undefined,
                        targetTitle: chatOnlyMode ? "纯聊天对话" : hasTarget ? snapshotTarget.title : undefined,
                        targetId: chatOnlyMode ? undefined : hasTarget ? snapshotTarget.id : undefined,
                        currentPrompt: hasTarget ? snapshotTarget.prompt : "",
                        globalPrompt: globalPrompt || "",
                        currentParams: hasTarget ? {
                            model: snapshotTarget.model,
                            seconds: snapshotTarget.seconds,
                            size: snapshotTarget.size,
                            resolution: snapshotTarget.resolution,
                        } : {},
                        projectAssets: activeAssets,
                        history,
                        lastAssistantPrompt: lastAssistant?.revisedPrompt || undefined,
                        lastAssistantMode: lastAssistant?.mode || undefined,
                        chatOnlyMode,
                        skillIds,
                        providerId: modelSettings.activeProviderId,
                        reasoningEffort: activeReasoningEffort,
                        attachments: snapshotAttachments.map(({ previewUrl: _, ...rest }) => rest),
                    }),
                });
            } finally {
                clearTimeout(clientTimeoutTimer);
            }
            const rawData = await res.json();
            let data = rawData;
            if (!res.ok || !rawData?.ok) {
                const recoveredFromError = recoverClientAgentPayload(rawData?.error);
                if (recoveredFromError && (recoveredFromError.prompt || recoveredFromError.summary)) {
                    data = {
                        ok: true,
                        ...recoveredFromError,
                    };
                } else {
                    throw new Error(rawData?.error || "Agent 调用失败");
                }
            }

            if(controller.signal.aborted||!activeControllersRef.current.has(assistantId))return;
            const sameTarget =
                latestTarget.current.projectId === origin.projectId &&
                latestTarget.current.id === origin.id &&
                latestTarget.current.prompt === origin.prompt &&
                latestTarget.current.seconds === origin.seconds &&
                latestTarget.current.size === origin.size &&
                latestTarget.current.resolution === origin.resolution &&
                latestTarget.current.model === origin.model;
            const returnedMode: "edit_video" | "extract_or_create" | "chat" =
                chatOnlyMode || !hasTarget
                    ? (data.prompt ? "extract_or_create" : "chat")
                    : data.mode === "chat" || data.mode === "extract_or_create" || data.mode === "edit_video"
                      ? data.mode
                      : /提取|单独.*给我|只.*给我|配音|音色|声线|SeedAudio/iu.test(rawTyped) && !/填入|替换原/u.test(rawTyped)
                        ? "extract_or_create"
                        : "edit_video";
            const isNonVideoEdit = returnedMode === "extract_or_create" || returnedMode === "chat";
            if (isNonVideoEdit) {
                setResultViews(prev => ({ ...prev, [assistantId]: "full" }));
            }
            const shouldAutoApply = autoApplyRef.current && hasTarget && !isNonVideoEdit && sameTarget && Boolean(data.prompt);
            if (shouldAutoApply) {
                onApplyResult({
                    prompt: data.prompt,
                    params: data.params,
                    autoStart: false,
                });
                message.success(`Agent 已将修改后的提示词填入「${snapshotTarget.title}」（可按 Ctrl+Z 撤回）`);
            }

            const baselinePrompt =
                returnedMode === "extract_or_create"
                    ? lastAssistant?.mode === "extract_or_create" && lastAssistant.revisedPrompt
                        ? lastAssistant.revisedPrompt
                        : ""
                    : returnedMode === "chat"
                      ? ""
                      : snapshotTarget.prompt;

            updateMessages(prev =>
                prev.map(m =>
                    m.id === assistantId
                        ? {
                              ...m,
                              status: "done",
                              mode: returnedMode,
                              originalPrompt: baselinePrompt,
                              steps: data.steps || initialSteps.map(s => ({ ...s, status: "done" })),
                              stepsOpen: false,
                              summary: data.summary,
                              changes: data.changes || [],
                              revisedPrompt: data.prompt,
                              revisedParams: data.params,
                              voiceDrafts: allowVoiceDrafts && Array.isArray(data.voiceDrafts) && data.voiceDrafts.length ? data.voiceDrafts : undefined,
                              applied: shouldAutoApply,
                          }
                        : m,
                ),
            );
        } catch (err: any) {
            if (!activeControllersRef.current.has(assistantId)) {
                return;
            }
            const isManualAborted = controller.signal.aborted && !clientTimedOut;
            if (isManualAborted) {
                return;
            }
            const errText = clientTimedOut
                ? clientTimeoutConfig.text
                : (err instanceof Error ? err.message : "调用失败");
            updateMessages(prev =>
                prev.map(m =>
                    m.id === assistantId
                        ? {
                              ...m,
                              status: "error",
                              error: errText,
                              steps: m.steps?.map(s => (s.status === "running" ? { ...s, status: "error", label: s.label.endsWith("（已超时）") || s.label.endsWith("（失败）") ? s.label : s.label + (clientTimedOut ? "（已超时）" : "（失败）") } : s)),
                              stepsOpen: true,
                          }
                        : m,
                ),
            );
            message.error(errText);
        } finally {
            activeControllersRef.current.delete(assistantId);
            setBusy(activeControllersRef.current.size > 0);
        }
    };

    const endResize = () => {
        const drag = resizeRef.current;
        if (!drag) return;
        cancelAnimationFrame(drag.frame);
        if (drag.next !== undefined) setPanelWidth(drag.next);
        resizeRef.current = null;
        setResizing(false);
    };
    const codexReady =
        modelSettings.provider === "custom"
            ? true
            : modelSettings.provider === "agy"
              ? codexStatus?.agy?.available !== false
              : codexStatus?.authenticated !== false;

    const handleAssetDrop = (e: React.DragEvent) => {
        const elemId = e.dataTransfer.getData("application/x-video-element");
        if (elemId) {
            e.preventDefault();
            e.stopPropagation();
            setDraggingFiles(false);
            const found = projectAssets.find(a => a.id === elemId);
            if (found && !busy) {
                void attachAssetToAgent(found);
            }
            return true;
        }
        return false;
    };

    return (
        <motion.aside
            initial={reduceMotion?false:{x:-24,opacity:0}} animate={closing?{x:reduceMotion?0:-20,opacity:0}:{x:0,opacity:1}} transition={reduceMotion?{duration:0}:{type:"spring",stiffness:430,damping:34}}
            onDragOver={e=>{if(e.dataTransfer.types.includes("Files")||e.dataTransfer.types.includes("application/x-video-element")){e.preventDefault();e.stopPropagation();if(!busy)setDraggingFiles(true);}}} onDragLeave={e=>{if(!e.currentTarget.contains(e.relatedTarget as Node))setDraggingFiles(false);}} onDrop={e=>{if(handleAssetDrop(e))return;if(!e.dataTransfer.files.length)return;e.preventDefault();e.stopPropagation();setDraggingFiles(false);if(!busy)void addAttachments(Array.from(e.dataTransfer.files));}} onPaste={e=>{const images=Array.from(e.clipboardData.files).filter(f=>f.type.startsWith("image/"));if(images.length){e.preventDefault();e.stopPropagation();if(!busy)void addAttachments(images);}}}
            data-agent-drop-active={draggingFiles||undefined}
            data-codex-agent-panel
            data-state={closing ? "closing" : "open"}
            data-busy={busy || undefined}
            data-resizing={resizing || undefined}
            inert={closing || undefined}
            aria-label="Agent 创作助手侧栏"
            style={{ width: panelWidth,animation:"none" }}
            className="wb-agent-panel relative flex h-full shrink-0 flex-col border-r border-border bg-card/95"
        >
            {draggingFiles&&<div data-agent-drop-overlay className="pointer-events-none absolute inset-1 z-50 flex items-center justify-center rounded-2xl border-2 border-dashed border-primary bg-card/90 text-sm font-medium text-primary">松开添加 Agent 附件或资产素材</div>}
            {/* Header matching Runow left panel */}
            <header className="wb-agent-head relative flex items-center justify-between gap-2 border-b border-border px-3 py-2.5">
                <div className="flex min-w-0 items-center gap-2.5">
                    <span className="wb-agent-logo flex size-8 shrink-0 items-center justify-center rounded-[10px] bg-primary/15 text-primary">
                        <Bot className="size-4" />
                    </span>
                    <div className="min-w-0 flex-1">
                        <div className="flex min-w-0 items-center gap-1.5">
                            <strong className="shrink-0 text-sm leading-5">Agent 创作助手</strong>
                            <span className="flex min-w-0 items-center gap-1 truncate text-[11px] text-muted-foreground" title={projectName}>
                                <span aria-hidden className="wb-led shrink-0" data-tone={busy ? "busy" : codexReady ? "ok" : "warn"} />
                                <span className="truncate">{busy ? "正在思考…" : modelSettings.provider === "custom" ? "自定义 API" : modelSettings.provider === "agy" ? "Antigravity CLI" : codexStatus?.authenticated !== false ? "本机 Codex" : "请先登录 Codex"}</span>
                            </span>
                        </div>
                        <div className="mt-0.5 flex min-w-0 items-center gap-1.5">
                            <button
                                type="button"
                                aria-label="配置 Agent 模型"
                                onClick={() => {
                                    setTempSettings(modelSettings);
                                    setModelModalOpen(true);
                                }}
                                className="wb-agent-model flex max-w-full items-center gap-1 rounded-full border border-border bg-secondary/80 px-2.5 py-0.5 text-[11px] font-medium text-foreground hover:border-primary hover:text-primary"
                            >
                                <span className="truncate">
                                    {modelSettings.provider === "custom"
                                        ? (modelSettings.customApi?.model || "自定义模型")
                                        : modelSettings.provider === "agy"
                                          ? (modelSettings.agyModel || "gemini-4-argon")
                                          : (codexStatus?.models?.find(m => m.slug === modelSettings.codexModel)?.name || (modelSettings.codexModel || "自动"))}
                                </span>
                                <Settings className="size-2.5 shrink-0 opacity-60" />
                            </button>
                        </div>
                    </div>
                </div>
                <div className="flex shrink-0 items-center gap-0.5">
                    <Tooltip title={sessionsViewOpen ? "返回当前对话" : `历史会话（${projectSessions.length}）`}>
                        <Button
                            size="small"
                            type={sessionsViewOpen ? "primary" : "text"}
                            aria-label="Agent 历史会话"
                            icon={<History className="size-3.5" />}
                            onClick={() => setSessionsViewOpen(v => !v)}
                        >
                            {projectSessions.length > 0 ? <span className="text-[11px]">{projectSessions.length}</span> : null}
                        </Button>
                    </Tooltip>
                    {messages.length > 0 && (
                        <Tooltip title="清空当前会话消息">
                            <Button
                                size="small"
                                type="text"
                                aria-label="清空 Agent 对话"
                                icon={<Trash2 className="size-3.5" />}
                                onClick={startNewSession}
                            />
                        </Tooltip>
                    )}
                    <Tooltip title={wide ? "恢复标准侧栏宽度" : "加宽侧栏，方便查看对话"}>
                        <Button
                            size="small"
                            type="text"
                            aria-label={wide ? "恢复标准侧栏宽度" : "加宽侧栏，方便查看对话"}
                            icon={wide ? <Minimize2 className="size-3.5" /> : <Maximize2 className="size-3.5" />}
                            onClick={() => setPanelWidth(wide ? 380 : 520)}
                        />
                    </Tooltip>
                    <Tooltip title="收起 Agent 侧边栏">
                        <Button
                            size="small"
                            type="text"
                            aria-label="收起 Agent 侧边栏"
                            icon={<PanelLeftClose className="size-4" />}
                            onClick={onClose}
                        />
                    </Tooltip>
                </div>
                <span aria-hidden className="wb-agent-scan" />
            </header>

            {/* Conversation body */}
            <div ref={scrollRef} className="wb-agent-body min-h-0 flex-1 space-y-3 overflow-y-auto p-3">
                {sessionsViewOpen ? (
                    <div data-agent-sessions-view className="space-y-2.5">
                        <div className="flex items-center justify-between">
                            <span className="text-xs font-semibold text-foreground">历史会话（{projectSessions.length}）</span>
                            <Button size="small" type="primary" icon={<MessageSquarePlus className="size-3.5" />} onClick={startNewSession}>
                                新建会话
                            </Button>
                        </div>
                        {sessionsLoadError && (
                            <p className="rounded-xl border border-destructive/30 bg-destructive/10 p-2.5 text-xs text-destructive">
                                ⚠️ 历史会话读取解析异常，已自动开启安全防覆盖保护，禁止写入以防历史会话丢失。
                            </p>
                        )}
                        {projectSessions.length === 0 ? (
                            <p className="rounded-xl border border-dashed border-border p-4 text-center text-xs text-muted-foreground">
                                暂无历史会话记录。发送指令后会自动保存在这里，方便随时找回之前聊过的内容。
                            </p>
                        ) : (
                            projectSessions.map(s => {
                                const isCurrent = s.id === activeSessionId && messages.length > 0;
                                const isEditing = editingSessionId === s.id;
                                return (
                                    <div
                                        key={s.id}
                                        data-agent-session-item={s.id}
                                        onClick={() => {
                                            if (!isEditing) switchSession(s);
                                        }}
                                        className={`group flex cursor-pointer items-start justify-between gap-2 rounded-xl border p-2.5 text-xs transition ${
                                            isCurrent ? "border-primary bg-primary/5" : "border-border bg-background hover:border-primary/50 hover:bg-accent/40"
                                        }`}
                                    >
                                        <div className="min-w-0 flex-1 space-y-1">
                                            {isEditing ? (
                                                <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
                                                    <Input
                                                        size="small"
                                                        aria-label="编辑会话标题"
                                                        value={editingSessionTitle}
                                                        autoFocus
                                                        onChange={e => setEditingSessionTitle(e.target.value)}
                                                        onPressEnter={() => renameSession(s.id, editingSessionTitle)}
                                                    />
                                                    <Button size="small" type="primary" onClick={() => renameSession(s.id, editingSessionTitle)}>
                                                        保存
                                                    </Button>
                                                    <Button size="small" onClick={() => setEditingSessionId(null)}>
                                                        取消
                                                    </Button>
                                                </div>
                                            ) : (
                                                <div className="flex items-center gap-1.5">
                                                    <strong className="truncate text-foreground">{s.title}</strong>
                                                    {isCurrent && <Tag color="processing" className="!m-0 !text-[10px]">当前</Tag>}
                                                </div>
                                            )}
                                            <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
                                                {s.targetTitle && (
                                                    <span data-session-target-badge className="inline-flex items-center gap-1 rounded bg-primary/10 px-1.5 py-0.5 text-[10px] font-medium text-primary">
                                                        <Video className="size-2.5" />
                                                        {s.targetTitle}
                                                    </span>
                                                )}
                                                <span>· {s.messages.length} 条消息</span>
                                                <span>· {new Date(s.updatedAt).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })}</span>
                                            </div>
                                        </div>
                                        <div className="flex shrink-0 items-center gap-0.5">
                                            <button
                                                type="button"
                                                aria-label={"重命名会话 " + s.title}
                                                title="修改此会话标题"
                                                onClick={e => {
                                                    e.stopPropagation();
                                                    setEditingSessionId(s.id);
                                                    setEditingSessionTitle(s.title);
                                                }}
                                                className="rounded p-1 text-muted-foreground opacity-60 hover:bg-accent hover:text-foreground group-hover:opacity-100"
                                            >
                                                <Pencil className="size-3.5" />
                                            </button>
                                            <button
                                                type="button"
                                                aria-label={"删除会话 " + s.title}
                                                title="删除此条会话记录"
                                                onClick={e => {
                                                    e.stopPropagation();
                                                    deleteSession(s.id);
                                                }}
                                                className="rounded p-1 text-muted-foreground opacity-60 hover:bg-destructive/10 hover:text-destructive group-hover:opacity-100"
                                            >
                                                <Trash2 className="size-3.5" />
                                            </button>
                                        </div>
                                    </div>
                                );
                            })
                        )}
                    </div>
                ) : messages.length === 0 ? (
                    <div className="space-y-3">
                        <div data-agent-msg="intro" className="rounded-2xl border border-dashed border-border bg-background/60 p-4 text-xs leading-5 text-muted-foreground">
                            <p className="mb-2 flex items-center gap-1.5 font-semibold text-foreground">
                                <Sparkles className="size-4 text-primary" />
                                怎么用 Agent 改有毛病的视频？
                            </p>
                            <ol className="list-inside list-decimal space-y-1.5">
                                <li>
                                    在右侧任意视频卡片上点 <strong>「发给 Agent」</strong>（或直接载入某组视频）。
                                </li>
                                <li>
                                    在下方直接用口语告诉 Agent 哪里不对，例如：
                                    <span className="mt-1 block rounded-lg bg-secondary/70 px-2.5 py-1.5 text-foreground">
                                        “第2个女生跳舞视频帮我改成男性，去掉多余路人，生成一个4秒的视频，480p”
                                    </span>
                                </li>
                                <li>
                                    Agent 会调用<strong>当前选择的模型接口</strong>自动改好提示词并填入下方提示词框（支持 <kbd>Ctrl+Z</kbd> 撤回）。
                                </li>
                            </ol>
                        </div>
                        {projectSessions.length > 0 && (
                            <div data-agent-recent-sessions className="rounded-2xl border border-border bg-background/70 p-3 text-xs">
                                <div className="mb-2 flex items-center justify-between">
                                    <span className="flex items-center gap-1.5 font-semibold text-foreground">
                                        <History className="size-3.5 text-primary" />
                                        最近聊过的会话（点击可恢复）
                                    </span>
                                    {projectSessions.length > 3 && (
                                        <button type="button" onClick={() => setSessionsViewOpen(true)} className="text-[11px] text-primary hover:underline">
                                            查看全部 ({projectSessions.length})
                                        </button>
                                    )}
                                </div>
                                <div className="space-y-1.5">
                                    {projectSessions.slice(0, 4).map(s => (
                                        <button
                                            key={s.id}
                                            type="button"
                                            onClick={() => switchSession(s)}
                                            className="flex w-full items-center justify-between gap-2 rounded-lg border border-border/60 bg-secondary/40 px-2.5 py-1.5 text-left transition hover:border-primary hover:bg-accent"
                                        >
                                            <span className="truncate font-medium text-foreground">{s.title}</span>
                                            <span className="shrink-0 text-[10px] text-muted-foreground">{s.targetTitle || `${s.messages.length}条`}</span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}
                    </div>
                ) : (
                    messages.map((msg, msgIdx) => {
                        const prevUserMsg = msg.role === "assistant"
                            ? messages.slice(0, msgIdx).reverse().find(m => m.role === "user")
                            : undefined;
                        return msg.role === "user" ? (
                            <div key={msg.id} data-agent-msg="user" className="flex flex-col items-end gap-1.5">
                                <div className="wb-agent-bubble max-w-[90%] rounded-2xl rounded-tr-sm bg-primary px-3.5 py-2.5 text-xs leading-5 text-primary-foreground shadow-xs whitespace-pre-wrap break-words">
                                    <div>{msg.text}</div>
                                    <div className="mt-1 flex justify-end gap-1">
                                        <button
                                            type="button"
                                            aria-label="编辑重发用户指令"
                                            title="把这条指令放回下方输入框，修改后重发"
                                            onClick={() => {
                                                setInput(msg.text || "");
                                                inputRef.current?.focus();
                                                message.success("已将指令放回下方输入框，可直接修改后重发");
                                            }}
                                            className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] opacity-75 transition hover:bg-black/10 hover:opacity-100"
                                        >
                                            <Pencil className="size-2.5" />
                                            编辑重发
                                        </button>
                                        <button
                                            type="button"
                                            aria-label="复制用户指令"
                                            title="复制这条指令"
                                            onClick={() => {
                                                void navigator.clipboard.writeText(msg.text || "");
                                                message.success("已复制发送内容");
                                            }}
                                            className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] opacity-75 transition hover:bg-black/10 hover:opacity-100"
                                        >
                                            <Copy className="size-2.5" />
                                            复制
                                        </button>
                                    </div>
                                </div>
                                {(Boolean(msg.targetVideos?.length || msg.targetTitle) || Boolean(msg.sentImages?.length)) && (
                                    <div data-user-msg-context-row className="flex max-w-[92%] flex-wrap items-center justify-end gap-1.5">
                                        {(msg.targetVideos && msg.targetVideos.length > 0
                                            ? msg.targetVideos
                                            : msg.targetTitle
                                              ? [{ id: msg.targetId, title: msg.targetTitle }]
                                              : []
                                        ).map((vid, vIdx) => (
                                            <button
                                                key={`${msg.id}-vid-${vIdx}`}
                                                type="button"
                                                data-user-msg-video-tag={vid.title}
                                                title={vid.id && onLoadTargetId ? `点击在右侧载入并查看「${vid.title}」` : vid.title}
                                                onClick={() => {
                                                    if (vid.id && onLoadTargetId) {
                                                        void onLoadTargetId(vid.id);
                                                    }
                                                }}
                                                className={`inline-flex items-center gap-1 rounded-full border border-primary/30 bg-primary/10 px-2 py-0.5 text-[11px] font-medium text-primary ${
                                                    vid.id && onLoadTargetId ? "cursor-pointer hover:bg-primary/20" : "cursor-default"
                                                }`}
                                            >
                                                <Video className="size-3" />
                                                {vid.title}
                                            </button>
                                        ))}
                                        {msg.sentImages?.map(img => (
                                            <div
                                                key={img.id}
                                                data-user-msg-sent-image={img.name}
                                                title={`已发送附图：${img.name}`}
                                                className="inline-flex items-center gap-1 rounded-lg border border-border bg-secondary/60 p-0.5 pr-1.5 text-[10px] text-muted-foreground shadow-2xs"
                                            >
                                                <img src={img.dataUrl} alt={img.name} className="size-9 rounded object-cover border border-border/60" />
                                                <span className="max-w-24 truncate">{img.name}</span>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        ) : (
                            <div key={msg.id} data-agent-reply data-agent-msg="assistant" data-status={msg.status} className="wb-agent-reply space-y-2 rounded-2xl border border-border bg-background p-3 text-xs shadow-xs">
                                {/* Runow-style 思路与进度 collapsible card */}
                                {msg.steps && msg.steps.length > 0 && (
                                    <div className="wb-agent-steps rounded-xl border border-border/80 bg-secondary/40 p-2.5">
                                        <button
                                            type="button"
                                            onClick={() =>
                                                updateMessages(prev =>
                                                    prev.map(m => (m.id === msg.id ? { ...m, stepsOpen: !m.stepsOpen } : m)),
                                                )
                                            }
                                            className="flex w-full items-center justify-between gap-2 text-left text-xs font-medium"
                                        >
                                            <span className="flex items-center gap-1.5">
                                                {msg.status === "running" ? (
                                                    <LoaderCircle className="size-3.5 animate-spin text-primary" />
                                                ) : msg.status === "error" ? (
                                                    <span className="text-destructive">!</span>
                                                ) : (
                                                    <Check className="size-3.5 text-emerald-600" />
                                                )}
                                                <span>
                                                    {msg.status === "running"
                                                        ? "思路与进度 · 正在思考改写…"
                                                        : msg.status === "error"
                                                          ? "执行中断"
                                                          : `已完成 ${msg.steps.length} 步 · 思路与进度`}
                                                </span>
                                            </span>
                                            <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                                                {msg.steps.length} 步
                                                {msg.stepsOpen ? <ChevronUp className="size-3.5" /> : <ChevronDown className="size-3.5" />}
                                            </span>
                                        </button>
                                        {msg.stepsOpen && (
                                            <div className="mt-2 space-y-1.5 border-t border-border/60 pt-2">
                                                {msg.steps.map((step, idx) => (
                                                    <div key={idx} data-step-status={step.status} className="wb-agent-step flex items-center justify-between gap-2 text-[11px]">
                                                        <span className="truncate text-foreground/90">{step.label}</span>
                                                        <span className=" flex shrink-0 items-center gap-1.5 text-muted-foreground">
                                                            <span className="rounded bg-background px-1.5 py-0.5 text-[10px]">{step.tag}</span>
                                                            {step.status === "running" ? (
                                                                <LoaderCircle className="size-3 animate-spin text-primary" />
                                                            ) : step.status === "done" ? (
                                                                <Check className="size-3 text-emerald-600" />
                                                            ) : step.status === "error" ? (
                                                                <span className="text-destructive">×</span>
                                                            ) : (
                                                                <span>·</span>
                                                            )}
                                                        </span>
                                                    </div>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                )}

                                {msg.status === "running" && (
                                    <div aria-hidden className="wb-agent-skeleton">
                                        <i />
                                        <i />
                                        <i />
                                    </div>
                                )}

                                {msg.error && (
                                    <div className="flex items-center justify-between gap-2 rounded-lg bg-destructive/10 p-2 text-xs text-destructive">
                                        <p className="whitespace-pre-wrap">{msg.error}</p>
                                        {prevUserMsg?.text && (
                                            <Button
                                                size="small"
                                                aria-label="重试此条 Agent 指令"
                                                disabled={busy}
                                                title={busy ? "当前有正在思考中的任务，请稍候再试" : "重新发送此条指令"}
                                                icon={<RotateCcw className="size-3" />}
                                                onClick={() => void sendInstruction(prevUserMsg.text)}
                                            >
                                                重试
                                            </Button>
                                        )}
                                    </div>
                                )}

                                {msg.summary && <p className="font-medium leading-5 text-foreground">{msg.summary}</p>}

                                {msg.changes && msg.changes.length > 0 && (
                                    <ul className="list-inside list-disc space-y-1 text-muted-foreground">
                                        {msg.changes.map((item, idx) => (
                                            <li key={idx}>{item}</li>
                                        ))}
                                    </ul>
                                )}

                                {msg.revisedParams &&
                                    Object.values(msg.revisedParams).some(Boolean) && (
                                        <div className="flex flex-wrap gap-1">
                                            {msg.revisedParams.model && <Tag>模型：{msg.revisedParams.model}</Tag>}
                                            {msg.revisedParams.seconds && <Tag>时长：{msg.revisedParams.seconds}s</Tag>}
                                            {msg.revisedParams.size && <Tag>画幅：{msg.revisedParams.size}</Tag>}
                                            {msg.revisedParams.resolution && <Tag>清晰度：{msg.revisedParams.resolution}</Tag>}
                                        </div>
                                    )}

                                {msg.revisedPrompt && (() => {
                                    const canDiff = Boolean(msg.originalPrompt && msg.originalPrompt.trim() && msg.originalPrompt !== msg.revisedPrompt);
                                    const view = canDiff ? resultViews[msg.id] || "full" : "full";
                                    return (
                                    <div className="wb-agent-result space-y-2 rounded-xl bg-secondary/60 p-2.5" data-applied={msg.applied || undefined}>
                                        <div className="flex items-center justify-between gap-2">
                                            {canDiff ? (
                                                <div role="tablist" aria-label="修改结果显示方式" className="wb-agent-seg flex rounded-lg bg-background/70 p-0.5 text-[11px]">
                                                    <button type="button" role="tab" aria-selected={view === "full"} onClick={() => setResultViews(prev => ({ ...prev, [msg.id]: "full" }))} className="rounded-md px-2 py-0.5">
                                                        修改后全文
                                                    </button>
                                                    <button type="button" role="tab" aria-selected={view === "diff"} onClick={() => setResultViews(prev => ({ ...prev, [msg.id]: "diff" }))} className="rounded-md px-2 py-0.5">
                                                        修改对比
                                                    </button>
                                                </div>
                                            ) : (
                                                <span className="text-[11px] font-semibold text-muted-foreground">
                                                    {msg.mode === "extract_or_create" ? "独立提取 / 资产提示词（已保留上下文记忆）" : "修改后视频提示词"}
                                                </span>
                                            )}
                                            <div className="flex items-center gap-1">
                                                {prevUserMsg?.text && (
                                                    <Button
                                                        size="small"
                                                        type="text"
                                                        aria-label="重试此条 Agent 指令"
                                                        disabled={busy}
                                                        title={busy ? "当前有正在思考中的任务，请稍候再试" : "重新发送此条指令"}
                                                        icon={<RotateCcw className="size-3" />}
                                                        onClick={() => void sendInstruction(prevUserMsg.text)}
                                                    >
                                                        重试
                                                    </Button>
                                                )}
                                                <Button
                                                    size="small"
                                                    type="text"
                                                    icon={<Copy className="size-3" />}
                                                    onClick={() => {
                                                        navigator.clipboard.writeText(msg.revisedPrompt || "");
                                                        message.success("已复制修改后提示词");
                                                    }}
                                                >
                                                    复制
                                                </Button>
                                            </div>
                                        </div>
                                        {view === "diff" ? (
                                            <AgentPromptDiff before={msg.originalPrompt || ""} after={msg.revisedPrompt} />
                                        ) : (
                                            <p className="max-h-48 overflow-y-auto whitespace-pre-wrap break-words text-xs leading-5">
                                                {msg.revisedPrompt}
                                            </p>
                                        )}
                                        <div className="flex flex-wrap items-center gap-2 pt-1">
                                            <Button
                                                size="small"
                                                type={msg.applied ? "default" : "primary"}
                                                icon={<Check className="size-3.5" />}
                                                onClick={() => {
                                                    onApplyResult({
                                                        prompt: msg.revisedPrompt!,
                                                        params: msg.revisedParams,
                                                        autoStart: false,
                                                    });
                                                    updateMessages(prev =>
                                                        prev.map(m => (m.id === msg.id ? { ...m, applied: true } : m)),
                                                    );
                                                    message.success("已填入下方提示词框，当前参考图片/音频保持不变（支持 Ctrl+Z 撤回）");
                                                }}
                                            >
                                                {msg.applied ? "重新填入提示词框" : "填入提示词框"}
                                            </Button>
                                            <Button
                                                size="small"
                                                type="primary"
                                                icon={<Play className="size-3.5" />}
                                                onClick={() => {
                                                    onApplyResult({
                                                        prompt: msg.revisedPrompt!,
                                                        params: msg.revisedParams,
                                                        autoStart: true,
                                                    });
                                                    updateMessages(prev =>
                                                        prev.map(m => (m.id === msg.id ? { ...m, applied: true } : m)),
                                                    );
                                                }}
                                            >
                                                填入并开始创作
                                            </Button>
                                            {msg.applied && (
                                                <span className="wb-agent-applied inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                                                    <Check className="size-3" />
                                                    已填入提示词框
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                    );
                                })()}
                                {msg.voiceDrafts && msg.voiceDrafts.length > 0 && (
                                    <div className="space-y-2 pt-1">
                                        {msg.voiceDrafts.map((draft, dIdx) => (
                                            <SeedAudioDraftCard
                                                key={`${msg.id}-voice-${dIdx}`}
                                                draft={draft}
                                                projectId={projectId}
                                                onInsertMention={roleName => {
                                                    const tagText = `@音频 ${roleName}`;
                                                    if (!target.prompt.includes(tagText)) {
                                                        onApplyResult({ prompt: `${target.prompt}\n${tagText}`.trim(), autoStart: false });
                                                        message.success(`已在当前提示词末尾关联「${tagText}」`);
                                                    } else {
                                                        message.info(`当前提示词已包含「${tagText}」`);
                                                    }
                                                }}
                                            />
                                        ))}
                                    </div>
                                )}
                            </div>
                        );
                    })
                )}
            </div>

            {/* Bottom input area matching Runow */}
            <footer className="wb-agent-foot border-t border-border bg-background/90 p-3">
                {/* Target video indicator + quick chips */}
                <div className="wb-agent-target mb-2 flex flex-wrap items-center justify-between gap-2 rounded-lg bg-secondary/70 px-2.5 py-1.5 text-xs">
                    {chatOnlyMode ? (
                        <span className="flex min-w-0 items-center gap-1.5 truncate font-medium text-foreground" title="纯聊天问答模式同样保留多轮上下文记忆，仅不携带当前视频原提示词且不自动覆盖右侧提示词框">
                            <span>💬 纯聊天问答（保留多轮记忆 · 不覆写提示词）</span>
                        </span>
                    ) : effectiveTargets.length > 0 ? (
                        <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1">
                            {effectiveTargets.map((t, idx) => (
                                <span
                                    key={t.id || `${t.title}-${idx}`}
                                    data-agent-target-chip={t.id || t.title}
                                    className="inline-flex max-w-full items-center gap-1 rounded-md border border-primary/30 bg-primary/10 px-1.5 py-0.5 text-[11px] font-medium text-primary"
                                    title={`${t.title || "当前提示词框"}（已开启多轮上下文记忆；可在右侧继续点多个视频的 Agent 图标同时关联）`}
                                >
                                    <Video className="size-3 shrink-0" />
                                    <span className="truncate">{t.title || "当前提示词框"}</span>
                                    {t.id && onRemoveTarget && (
                                        <button
                                            type="button"
                                            aria-label={`取消关联 ${t.title}`}
                                            title={`取消关联 ${t.title}`}
                                            onClick={() => onRemoveTarget(t.id!)}
                                            className="ml-0.5 rounded-full px-1 text-primary/70 hover:bg-primary/20 hover:text-primary"
                                        >
                                            ×
                                        </button>
                                    )}
                                </span>
                            ))}
                        </div>
                    ) : (
                        <div className="flex min-w-0 flex-1 flex-wrap items-center gap-1.5">
                            <span className="truncate text-[11px] text-muted-foreground" title="点右侧视频卡片上的机器人图标即可将该视频加入对话；也可点击旁边按钮手动关联当前提示词台">
                                未关联视频（点视频 🤖 图标加入）
                            </span>
                            {onLinkCurrentDraft && (target.id || target.prompt) && (
                                <button
                                    type="button"
                                    data-link-current-draft
                                    onClick={onLinkCurrentDraft}
                                    className="inline-flex items-center gap-1 rounded-md border border-border bg-background/85 px-1.5 py-0.5 text-[11px] font-medium text-foreground transition hover:border-primary hover:text-primary"
                                >
                                    <Video className="size-3 shrink-0" />
                                    <span>关联编辑台{target.title && target.title !== "当前提示词台" ? ` (${target.title})` : ""}</span>
                                </button>
                            )}
                        </div>
                    )}
                    <span className="flex shrink-0 items-center gap-1.5 text-[11px] text-muted-foreground">
                        {!chatOnlyMode && effectiveTargets.length > 0 && (combinedTarget.prompt ? `${combinedTarget.prompt.length} 字` : "空提示词")}
                        <button
                            type="button"
                            data-toggle-agent-chat-mode
                            aria-pressed={chatOnlyMode}
                            title={chatOnlyMode ? "切回关联视频模式（同样支持多轮连续追问，并读取目标视频提示词）" : "切为纯聊天问答（同样支持多轮连续追问，仅不改写右侧视频提示词框）"}
                            onClick={() => setChatOnlyMode(v => !v)}
                            className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 font-semibold transition ${
                                chatOnlyMode ? "bg-primary !text-white shadow-xs hover:opacity-95" : "bg-background/80 text-foreground hover:bg-background hover:text-primary"
                            }`}
                        >
                            {chatOnlyMode ? "📹 重新关联视频" : "💬 切为纯聊天"}
                        </button>
                        {onLocateTarget && effectiveTargets.length > 0 && combinedTarget.id && (
                            <button
                                type="button"
                                aria-label="在视频台定位当前目标"
                                title="在右侧视频台中滚动到并高亮该视频"
                                onClick={onLocateTarget}
                                className="wb-agent-locate inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-foreground hover:bg-background hover:text-primary"
                            >
                                <Crosshair className="size-3" />
                                定位
                            </button>
                        )}
                    </span>
                </div>

                {selectedQuickPrompt && (
                    <div data-selected-quick-prompt className="mb-2 flex items-center justify-between gap-1">
                        <div className="flex flex-1 flex-wrap items-center gap-1 overflow-hidden">
                            <span className="inline-flex items-center gap-1 rounded-full border border-primary/40 bg-primary/10 px-2.5 py-0.5 text-[11px] text-primary">
                                <button
                                    type="button"
                                    disabled={busy}
                                    onClick={() => void sendInstruction()}
                                    title={selectedQuickPrompt.text}
                                    className="font-medium hover:underline disabled:opacity-50"
                                >
                                    {selectedQuickPrompt.label}
                                </button>
                                <button
                                    type="button"
                                    aria-label="取消选中预设提示词"
                                    onClick={() => setSelectedQuickPrompt(null)}
                                    className="ml-0.5 rounded-full px-1 hover:bg-primary/20"
                                >
                                    ×
                                </button>
                            </span>
                        </div>
                    </div>
                )}

                <div onDragOver={e=>{if(!busy&&(e.dataTransfer.types.includes("Files")||e.dataTransfer.types.includes("application/x-video-element"))){e.preventDefault();e.stopPropagation();}}} onDrop={e=>{if(handleAssetDrop(e))return;if(busy||!e.dataTransfer.files.length)return;e.preventDefault();e.stopPropagation();void addAttachments(Array.from(e.dataTransfer.files));}} className="wb-agent-input rounded-2xl border border-border bg-card p-2.5 shadow-xs focus-within:border-primary">
                    <input ref={attachmentInput} type="file" multiple hidden aria-label="Agent 附件选择" accept=".txt,.md,.json,.csv,.srt,.vtt,.docx,.png,.jpg,.jpeg,.webp" onChange={e=>{void addAttachments(Array.from(e.target.files||[]));e.target.value="";}}/>
                    {attachments.length>0&&<div aria-label="Agent 已选附件" className="mb-2 flex flex-wrap items-center gap-1.5">{attachments.map(a=>(a.dataUrl||a.previewUrl)?<div key={a.id} data-agent-image-attachment={a.name} className="group relative inline-flex items-center gap-1.5 rounded-lg border border-border bg-secondary/50 p-1 pr-2 text-xs"><img src={a.dataUrl||a.previewUrl} alt={a.name} className="size-10 rounded object-cover border border-border/60"/><span className="max-w-28 truncate">{a.name}</span><button type="button" aria-label={"移除附件 "+a.name} onClick={()=>setAttachments(prev=>prev.filter(f=>f.id!==a.id))} className="ml-0.5 rounded-full px-1 text-muted-foreground hover:bg-accent hover:text-foreground">×</button></div>:<Tag key={a.id} closable onClose={()=>setAttachments(prev=>prev.filter(f=>f.id!==a.id))}>{a.name}</Tag>)}</div>}
                    <textarea
                        ref={inputRef}
                        aria-label="Agent 修改指令输入"
                        rows={3}
                        value={input}
                        disabled={readingFiles}
                        onChange={e => setInput(e.target.value)}
                        onKeyDown={e => {
                            if (e.key === "Enter" && !e.shiftKey) {
                                e.preventDefault();
                                void sendInstruction();
                            }
                        }}
                        placeholder="描述你想怎么改这条视频提示词（例如：把第2个镜头改成男性、去掉多余动作、改成4秒）…"
                        className="w-full resize-none bg-transparent text-xs leading-5 outline-none placeholder:text-muted-foreground"
                    />
                    <div className="mt-2 border-t border-border/60 pt-2"><AgentInputTools key={projectId+":"+target.id} settings={modelSettings} codexModels={codexStatus?.models||[]} agyStatus={codexStatus?.agy} disabled={readingFiles} onSettings={next=>{setModelSettings(next);localStorage.setItem("xiaoxiao:agent-model-settings",JSON.stringify(clientAgentSettings(next)));}} onNew={startNewSession} onSessions={()=>setSessionsViewOpen(v=>!v)} sessionsCount={projectSessions.length} sessionsOpen={sessionsViewOpen} onAttach={()=>attachmentInput.current?.click()} prompts={quickPrompts} onPrompt={(_text,item)=>{if(item)setSelectedQuickPrompt(item);inputRef.current?.focus();}} onManage={()=>{setEditingPrompts([...quickPrompts]);setManagePromptsOpen(true);}} onAdd={()=>{setEditingPrompts([...quickPrompts,{id:nanoid(),label:"新提示词",text:""}]);setManagePromptsOpen(true);}} skillIds={skillIds} onSkills={setSkillIds}/></div>
                    <div className="mt-2 flex items-center justify-between gap-2">
                        <Checkbox
                            checked={autoApply}
                            onChange={e => setAutoApply(e.target.checked)}
                            className="!text-[11px]"
                        >
                            改完自动填入提示词框
                        </Checkbox>
                        <div className="flex items-center gap-1.5">
                            {busy && (
                                <Tooltip title="点击暂停 Agent 思考">
                                    <button
                                        type="button"
                                        aria-label="暂停 Agent 思考"
                                        onClick={() => stopThinking()}
                                        className="wb-agent-stop relative flex size-7 shrink-0 items-center justify-center rounded-full bg-destructive text-white shadow-sm transition hover:bg-destructive/90"
                                    >
                                        <LoaderCircle className="absolute size-4 animate-spin opacity-80" />
                                        <Square className="size-2 fill-current" />
                                    </button>
                                </Tooltip>
                            )}
                            {(!busy || input.trim() || selectedQuickPrompt || attachments.length > 0) && (
                                <MotionButton whileTap={reduceMotion?undefined:{scale:.88}} transition={{type:"spring",stiffness:500,damping:24}}
                                    type="primary"
                                    shape="circle"
                                    size="small"
                                    aria-label="发送给 Agent"
                                    disabled={(!input.trim() && !selectedQuickPrompt && attachments.length === 0) || readingFiles}
                                    icon={<Send className="size-3.5" />}
                                    onClick={() => void sendInstruction()}
                                />
                            )}
                        </div>
                    </div>
                </div>
            </footer>

            {/* Manage Quick Prompts Modal */}
            <Modal
                title="自定义 Agent 快捷指令"
                open={managePromptsOpen}
                onCancel={() => setManagePromptsOpen(false)}
                footer={
                    <div className="flex items-center justify-between">
                        <Button
                            size="small"
                            icon={<RotateCcw className="size-3.5" />}
                            onClick={() => setEditingPrompts([...DEFAULT_QUICK_PROMPTS])}
                        >
                            恢复默认
                        </Button>
                        <div className="flex items-center gap-2">
                            <Button size="small" onClick={() => setManagePromptsOpen(false)}>
                                取消
                            </Button>
                            <Button
                                size="small"
                                type="primary"
                                onClick={() => {
                                    const cleaned = editingPrompts
                                        .filter(p => p.label.trim())
                                        .map(p => ({ ...p, label: p.label.trim(), text: p.text.trim() }));
                                    setQuickPrompts(cleaned);
                                    try {
                                        localStorage.setItem("xiaoxiao:agent-quick-prompts", JSON.stringify(cleaned));
                                    } catch {}
                                    setManagePromptsOpen(false);
                                    message.success("已保存快捷指令");
                                }}
                            >
                                保存
                            </Button>
                        </div>
                    </div>
                }
            >
                <div className="max-h-[60vh] space-y-3 overflow-y-auto p-1">
                    <p className="text-xs text-muted-foreground">
                        自定义输入框上方的快捷胶囊按钮。点击胶囊即可直接把指令发给 Agent。
                    </p>
                    {editingPrompts.map((item, index) => (
                        <div key={item.id} className="space-y-1.5 rounded-xl border border-border p-2.5 bg-secondary/30">
                            <div className="flex items-center justify-between gap-2">
                                <Input
                                    size="small"
                                    aria-label={`快捷指令名称 ${index + 1}`}
                                    value={item.label}
                                    placeholder="胶囊按钮名称（例如：修动作毛病）"
                                    className="font-medium"
                                    onChange={e => {
                                        const val = e.target.value;
                                        setEditingPrompts(prev => prev.map((p, i) => (i === index ? { ...p, label: val } : p)));
                                    }}
                                />
                                <Button
                                    size="small"
                                    type="text"
                                    danger
                                    icon={<Trash2 className="size-3.5" />}
                                    aria-label={`删除快捷指令 ${index + 1}`}
                                    onClick={() => setEditingPrompts(prev => prev.filter((_, i) => i !== index))}
                                />
                            </div>
                            <Input.TextArea
                                rows={2}
                                size="small"
                                aria-label={`快捷指令内容 ${index + 1}`}
                                value={item.text}
                                placeholder="发给 Agent 的完整修改指令内容…"
                                onChange={e => {
                                    const val = e.target.value;
                                    setEditingPrompts(prev => prev.map((p, i) => (i === index ? { ...p, text: val } : p)));
                                }}
                            />
                        </div>
                    ))}
                    <Button
                        block
                        size="small"
                        icon={<Plus className="size-3.5" />}
                        onClick={() =>
                            setEditingPrompts(prev => [
                                ...prev,
                                { id: nanoid(), label: `快捷指令 ${prev.length + 1}`, text: "" },
                            ])
                        }
                    >
                        添加快捷指令
                    </Button>
                </div>
            </Modal>

            {modelModalOpen&&<AgentProviderSettings settings={modelSettings} models={codexStatus?.models||[]} onCancel={()=>setModelModalOpen(false)} onSave={clean=>{setModelSettings(clean);setTempSettings(clean);localStorage.setItem("xiaoxiao:agent-model-settings",JSON.stringify(clientAgentSettings(clean)));setModelModalOpen(false);}}/>}
            <div
                data-agent-resizer
                role="separator"
                aria-label="调整 Agent 侧栏宽度"
                aria-orientation="vertical"
                aria-valuemin={AGENT_PANEL_MIN}
                aria-valuemax={AGENT_PANEL_MAX}
                aria-valuenow={panelWidth}
                tabIndex={0}
                title="拖动调整 Agent 侧栏宽度；双击恢复标准宽度"
                onDoubleClick={() => setPanelWidth(380)}
                onKeyDown={event => {
                    if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
                    event.preventDefault();
                    setPanelWidth(panelWidth + (event.key === "ArrowRight" ? 20 : -20));
                }}
                onPointerDown={event => {
                    if (event.button !== 0) return;
                    event.preventDefault();
                    event.currentTarget.setPointerCapture(event.pointerId);
                    resizeRef.current = { x: event.clientX, width: panelWidth, frame: 0 };
                    setResizing(true);
                }}
                onPointerMove={event => {
                    const drag = resizeRef.current;
                    if (!drag) return;
                    drag.next = drag.width + event.clientX - drag.x;
                    cancelAnimationFrame(drag.frame);
                    drag.frame = requestAnimationFrame(() => {
                        if (drag.next !== undefined) setPanelWidth(drag.next);
                    });
                }}
                onPointerUp={endResize}
                onPointerCancel={endResize}
                onLostPointerCapture={endResize}
            />
        </motion.aside>
    );
}

function AgentPromptDiff({ before, after }: { before: string; after: string }) {
    const blocks = useMemo(() => diffPromptLines(before, after), [before, after]);
    if (!blocks) return <p className="max-h-48 overflow-y-auto whitespace-pre-wrap break-words text-xs leading-5">{after}</p>;
    if (!blocks.length) return <p className="text-[11px] text-muted-foreground">与发送时的提示词相同，未做文字修改。</p>;
    const stats = diffStats(blocks);
    return (
        <div data-agent-diff className="wb-agent-diff overflow-hidden rounded-lg border border-border bg-background/80">
            <div className="flex items-center gap-2 border-b border-border px-2 py-1 text-[10px] text-muted-foreground">
                <span className="wb-diff-stat" data-kind="add">+{stats.added} 行</span>
                <span className="wb-diff-stat" data-kind="del">−{stats.removed} 行</span>
                <span className="ml-auto">只显示修改处，未改动部分已折叠</span>
            </div>
            <div className="max-h-56 overflow-y-auto py-1 text-xs leading-5">
                {blocks.map((block, index) =>
                    block.kind === "skip" ? (
                        <div key={index} className="wb-diff-skip px-2 text-[10px] text-muted-foreground">… {block.count} 行未改动</div>
                    ) : (
                        <div key={index} className="wb-diff-line flex gap-1.5 px-2" data-kind={block.kind}>
                            <span aria-hidden className="wb-diff-sign w-3 shrink-0 select-none text-center">{block.kind === "add" ? "+" : block.kind === "del" ? "−" : ""}</span>
                            <span className="min-w-0 flex-1 whitespace-pre-wrap break-words">
                                {block.spans ? block.spans.map((span, i) => (span.changed ? <mark key={i}>{span.text}</mark> : <span key={i}>{span.text}</span>)) : block.text || " "}
                            </span>
                        </div>
                    ),
                )}
            </div>
        </div>
    );
}

function SeedAudioDraftCard({
    draft,
    projectId,
    onInsertMention,
}: {
    draft: SeedAudioVoiceDraft;
    projectId: string;
    onInsertMention?: (roleName: string) => void;
}) {
    const { message, modal } = App.useApp();
    const [roleName, setRoleName] = useState(draft.roleName || "路人配音");
    const [scenario, setScenario] = useState<"omni-dubbing" | "text-reading">(draft.scenario === "text-reading" ? "text-reading" : "omni-dubbing");
    const [voiceName, setVoiceName] = useState(draft.voiceName || "");
    const [audioPrompt, setAudioPrompt] = useState(draft.audioPrompt || "");
    const [voices, setVoices] = useState<{ voiceName: string; voiceId: string }[]>([]);
    const [loadingVoices, setLoadingVoices] = useState(false);
    const [task, setTask] = useState<{
        id?: string;
        status?: string;
        credits?: number;
        canvasName?: string;
        audioUrl?: string;
        savedAssetId?: string;
        error?: string;
        busy?: boolean;
    }>({});

    useEffect(() => {
        if (scenario !== "text-reading" || voices.length > 0) return;
        const bridge = (window as any).desktopBridge;
        if (!bridge?.dreaminaAudioVoices) return;
        setLoadingVoices(true);
        void bridge
            .dreaminaAudioVoices({ count: 50 })
            .then((res: any) => {
                const list = Array.isArray(res?.voices) ? res.voices : [];
                setVoices(list);
                if (!voiceName && list[0]?.voiceName) setVoiceName(list[0].voiceName);
            })
            .catch(() => {})
            .finally(() => setLoadingVoices(false));
    }, [scenario, voices.length, voiceName]);

    const confirmAndRun = async (
        taskId: string = task.id || "",
        credits: number = task.credits ?? 0,
        cleanRole: string = roleName.trim() || "路人配音",
        cleanPrompt: string = audioPrompt.trim(),
        targetOutputDir: string = getSavedAudioOutputDir(),
    ) => {
        const bridge = (window as any).desktopBridge;
        if (!bridge?.dreaminaConfirm || !bridge?.dreaminaQuery || !taskId) return;
        setTask(prev => ({ ...prev, id: taskId, busy: true, status: "processing", error: undefined }));
        try {
            await bridge.dreaminaConfirm({ id: taskId, creditCeiling: Math.max(0, credits) });
            for (let i = 0; i < 120; i++) {
                await new Promise(r => setTimeout(r, 2500));
                const q = await bridge.dreaminaQuery(taskId);
                if (q.status === "completed" && q.media?.[0]?.dataUrl) {
                    const media = q.media[0];
                    const savedLocal = await saveDataUrlAsLocalAsset(
                        media.dataUrl,
                        cleanRole,
                        "生成配音与补词",
                        targetOutputDir || undefined,
                    );
                    const playableUrl = savedLocal?.url || media.dataUrl;
                    const newId = useAssetStore.getState().addAsset({
                        title: cleanRole,
                        category: "音频",
                        coverUrl: "",
                        tags: ["SeedAudio 1.0"],
                        kind: "audio",
                        localFile: savedLocal ? { id: savedLocal.id, path: savedLocal.path } : undefined,
                        metadata: {
                            elementPerformer: cleanRole,
                            elementManualCategory: "音频",
                            elementManualGroup: cleanRole,
                            seedAudioPrompt: cleanPrompt,
                            seedAudioGenerated: true,
                            isSeedAudioGenerated: true,
                            savedFolder: targetOutputDir || undefined,
                        },
                        data: {
                            url: playableUrl,
                            dataUrl: media.dataUrl,
                            mimeType: media.mimeType || "audio/mpeg",
                            fileName: `${cleanRole}.mp3`,
                            size: Math.round((media.dataUrl.length * 3) / 4),
                            duration: 4,
                            durationMs: 4000,
                        },
                    });
                    useVideoStudioStore.getState().addElement(newId, projectId);
                    window.dispatchEvent(new CustomEvent("xiaoxiao:flash-asset", { detail: { id: newId, projectId, category: "音频" } }));
                    window.dispatchEvent(new CustomEvent("xiaoxiao:unread-asset-category", { detail: { projectId, category: "音频", id: newId } }));
                    setTask(prev => ({ ...prev, busy: false, status: "completed", audioUrl: playableUrl, savedAssetId: newId }));
                    message.success(`配音「${cleanRole}」已生成并自动添加到资产库 -> 音频！`);
                    return;
                }
                if (q.status === "failed") {
                    throw new Error(q.error?.message || "即梦配音生成失败");
                }
            }
            throw new Error("配音生成等待超时，请稍后在即梦画布核对");
        } catch (err) {
            const msg = err instanceof Error ? err.message : "配音生成失败";
            setTask(prev => ({ ...prev, busy: false, status: "failed", error: msg }));
            message.error(msg);
        }
    };

    const prepareQuote = async () => {
        const bridge = (window as any).desktopBridge;
        if (!bridge?.dreaminaAudioSubmit) {
            message.warning("请在桌面版工作台中使用即梦 SeedAudio 1.0 配音生成功能");
            return;
        }
        if (!audioPrompt.trim()) {
            message.warning("请填写配音提示词或台词");
            return;
        }
        const snapRole = roleName.trim() || "路人配音";
        const snapPrompt = audioPrompt.trim();
        const snapOutputDir = getSavedAudioOutputDir();
        setTask({ busy: true });
        try {
            const res = await bridge.dreaminaAudioSubmit({
                projectKey: projectId,
                title: snapRole,
                prompt: snapPrompt,
                scenario,
                voiceName: scenario === "text-reading" ? voiceName : undefined,
            });
            const credits = res.quote?.credits ?? 0;
            const canvasName = res.canvasName || "";
            setTask({
                id: res.id,
                status: res.status,
                credits,
                canvasName,
                busy: false,
            });
            const confirmed = await new Promise<boolean>(resolve => {
                let settled = false;
                const finish = (v: boolean) => {
                    if (!settled) {
                        settled = true;
                        resolve(v);
                    }
                };
                modal.confirm({
                    title: "即梦 SeedAudio 1.0 配音生成确认",
                    style: { top: 72 },
                    content: (
                        <div className="space-y-1.5 text-xs">
                            <p>入库名称：<strong>{snapRole}</strong></p>
                            <p className="text-muted-foreground">保存文件夹：{snapOutputDir || "工作台默认生成配音目录"}</p>
                            {canvasName && <p className="text-muted-foreground">目标画布：{canvasName}</p>}
                            <p className="font-medium">本次生成将消耗 <strong className="text-primary">{credits}</strong> 积分，确认开始生成吗？</p>
                        </div>
                    ),
                    okText: "确认生成",
                    cancelText: "取消",
                    onOk: () => finish(true),
                    onCancel: () => finish(false),
                });
            });
            if (!confirmed) {
                setTask({ busy: false });
                return;
            }
            void confirmAndRun(res.id, credits, snapRole, snapPrompt, snapOutputDir);
        } catch (err) {
            const msg = err instanceof Error ? err.message : "准备配音节点失败";
            setTask({ error: msg, busy: false });
            message.error(msg);
        }
    };

    return (
        <div data-seed-audio-card className="space-y-2 rounded-xl border border-primary/35 bg-primary/5 p-2.5 text-xs">
            <div className="flex items-center justify-between gap-2">
                <span className="font-semibold text-primary">🎙️ 即梦 SeedAudio 1.0 · 4秒角色配音工坊</span>
                <Select
                    size="small"
                    value={scenario}
                    onChange={val => setScenario(val)}
                    options={[
                        { value: "omni-dubbing", label: "全能配音 (自由声线)" },
                        { value: "text-reading", label: "音色库朗读" },
                    ]}
                    className="w-36 !text-[11px]"
                />
            </div>
            <div className="flex items-center gap-1.5">
                <span className="shrink-0 text-[11px] text-muted-foreground">音频库名称：</span>
                <Input
                    size="small"
                    aria-label="配音角色名称"
                    value={roleName}
                    onChange={e => setRoleName(e.target.value)}
                    placeholder="如：接警员男警 / 路人甲"
                    className="flex-1 !text-xs"
                />
                {scenario === "text-reading" && (
                    <Select
                        size="small"
                        loading={loadingVoices}
                        value={voiceName || undefined}
                        onChange={val => setVoiceName(val)}
                        placeholder="选择音色"
                        options={voices.map(v => ({ value: v.voiceName, label: v.voiceName }))}
                        className="w-28 !text-xs"
                    />
                )}
            </div>
            <Input.TextArea
                rows={2}
                size="small"
                aria-label="SeedAudio 配音提示词"
                value={audioPrompt}
                onChange={e => setAudioPrompt(e.target.value)}
                placeholder="描述声线特征+约4秒（12~18字）台词…"
                className="!text-xs"
            />
            {task.error && <p className="text-[11px] text-destructive">{task.error}</p>}
            {task.audioUrl && (
                <div className="space-y-1.5 rounded-lg bg-background/80 p-2">
                    <audio controls src={task.audioUrl} className="h-8 w-full" />
                    <div className="flex items-center justify-between text-[11px] text-emerald-600">
                        <span>✅ 已存入资产库「音频」：{roleName}</span>
                        {onInsertMention && (
                            <Button size="small" type="link" className="!h-auto !p-0 !text-[11px]" onClick={() => onInsertMention(roleName.trim() || "路人配音")}>
                                @引用到当前提示词
                            </Button>
                        )}
                    </div>
                </div>
            )}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-0.5">
                {task.status === "awaiting_confirmation" ? (
                    <>
                        <span className="text-[11px] text-muted-foreground">
                            {task.canvasName ? `画布：${task.canvasName} · ` : ""}预计消耗 <strong>{task.credits ?? 0}</strong> 积分
                        </span>
                        <Button
                            size="small"
                            type="primary"
                            data-seed-audio-confirm
                            loading={task.busy}
                            onClick={() => void confirmAndRun()}
                        >
                            确认生成4秒配音并入库
                        </Button>
                    </>
                ) : (
                    <>
                        <span className="text-[10px] text-muted-foreground">生成后自动加入当前项目「资产库 → 音频」</span>
                        <Button
                            size="small"
                            type="primary"
                            data-seed-audio-prepare
                            loading={task.busy}
                            onClick={() => void prepareQuote()}
                        >
                            {task.status === "processing" ? "正在生成配音…" : "调用 SeedAudio 1.0 生成"}
                        </Button>
                    </>
                )}
            </div>
        </div>
    );
}
