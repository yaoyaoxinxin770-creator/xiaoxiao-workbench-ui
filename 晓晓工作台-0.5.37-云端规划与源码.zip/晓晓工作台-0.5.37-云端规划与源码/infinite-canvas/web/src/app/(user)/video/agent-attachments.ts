import {unzipSync,strFromU8} from 'fflate';
export type AgentAttachment={id:string;name:string;type:string;text?:string;dataUrl?:string};
export async function readAgentAttachment(file:File):Promise<AgentAttachment>{
 if(file.size>8*1024*1024)throw Error('附件不得超过8MB：'+file.name);
 const item:AgentAttachment={id:crypto.randomUUID(),name:file.name,type:file.type};
 if(/\.(?:png|jpe?g|webp)$/i.test(file.name)){
  if(file.size>3*1024*1024)throw Error('图片附件不得超过3MB');
  item.type=/\.png$/i.test(file.name)?'image/png':/\.webp$/i.test(file.name)?'image/webp':'image/jpeg';
  item.dataUrl=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result));r.onerror=()=>reject(Error('读取图片失败'));r.readAsDataURL(new Blob([file],{type:item.type}));});return item;
 }
 if(/\.docx$/i.test(file.name)){
  const z=unzipSync(new Uint8Array(await file.arrayBuffer()),{filter:f=>f.name==='word/document.xml'&&f.originalSize<=2000000});
  if(!z['word/document.xml'])throw Error('DOCX内容过大或无法读取');
  const xml=new DOMParser().parseFromString(strFromU8(z['word/document.xml']),'application/xml');
  if(xml.getElementsByTagName('parsererror').length)throw Error('DOCX正文格式无效');
  item.text=Array.from(xml.getElementsByTagNameNS('*','p')).map(p=>Array.from(p.getElementsByTagNameNS('*','t')).map(t=>t.textContent||'').join('')).join('\n');
 }else if(/\.(?:txt|md|json|csv|srt|vtt)$/i.test(file.name))item.text=await file.text();else throw Error('暂支持文本、Markdown、DOCX和PNG/JPEG/WebP图片');
 if(!item.text?.trim())throw Error('附件中没有可读取的正文：'+file.name);
 if(item.text.length>60000)throw Error('单个文本附件不得超过6万字');return item;
}
