"use client";
import {writeElementDrag} from "../element-drag";
import {useEffect,useMemo,useRef,useState,type ReactNode} from "react";
import {Drawer,Button,Dropdown,Empty,App} from "antd";
import {Plus,MoreHorizontal,Play,Pause,Star,AtSign,Layers,RefreshCw,ArrowLeft,EyeOff,FolderOpen} from "lucide-react";
import {useAssetStore,type Asset} from "@/stores/use-asset-store";
import {useVideoStudioStore} from "@/stores/use-video-studio-store";
import {groupElements,compareElementOrder,elementPinnedAt,elementGroupSortOrder,sortAssetsBy,isImageAsset,isVideoAsset,elementInfo} from "../element-model";
import {ElementThumbnail} from "./element-asset-card";
import {chooseLocalDirectory,notifyLocalAssetLoadError} from "@/services/api/local-assets";
import {LocalAssetMenu} from "./local-asset-menu";
import {ElementAudioStripCard} from "./element-audio-strip";
import {getSavedAudioOutputDir,setSavedAudioOutputDir} from "./composer-audio-mode";
import {useElementReorder} from "./use-element-reorder";

function ArchiveAudio({asset}:{asset:Extract<Asset,{kind:"audio"}>}){
 const audioUrl=asset.data.url||String((asset.data as any)?.dataUrl||"");
 const fallbackDuration=((asset.data.durationMs||0)/1000)||Number((asset.data as any)?.duration||0);
 const audio=useRef<HTMLAudioElement>(null),[playing,setPlaying]=useState(false),[time,setTime]=useState(0),[duration,setDuration]=useState(fallbackDuration),[error,setError]=useState(false);
 useEffect(()=>{setError(false);if(fallbackDuration>0&&duration<=0)setDuration(fallbackDuration);audio.current?.load();},[audioUrl,fallbackDuration]);
 const format=(n:number)=>Math.floor(n/60)+":"+String(Math.floor(n%60)).padStart(2,"0");
 return <div className="archive-voice" onClick={e=>e.stopPropagation()}><audio ref={audio} preload="metadata" src={audioUrl} onLoadedMetadata={e=>{setError(false);if(Number.isFinite(e.currentTarget.duration)&&e.currentTarget.duration>0)setDuration(e.currentTarget.duration);}} onTimeUpdate={e=>setTime(e.currentTarget.currentTime)} onPlay={()=>setPlaying(true)} onPause={()=>setPlaying(false)} onEnded={()=>setPlaying(false)} onError={()=>{setError(true);if(asset.localFile)notifyLocalAssetLoadError(asset);}}/><button type="button" aria-label={(playing?"暂停 ":"试听 ")+asset.title} onClick={()=>{const a=audio.current;if(a){if(playing)a.pause();else void a.play().catch(()=>setError(true));}}}>{playing?<Pause size={12}/>:<Play size={12}/>}</button><input type="range" aria-label={"试听进度 "+asset.title} min={0} max={duration||1} step={0.1} value={Math.min(time,duration||1)} onChange={e=>{if(audio.current)audio.current.currentTime=Number(e.target.value);setTime(Number(e.target.value));}}/><span className="archive-voice-title" title={asset.title}>{error?"音频无法读取":asset.title}</span><time>{format(playing?time:duration)}</time></div>;
}

export function isGeneratedDubAudio(asset:Extract<Asset,{kind:"audio"}>):boolean{
 const meta=(asset.metadata||{}) as Record<string,any>;
 return Boolean(
  asset.tags?.includes("SeedAudio 1.0")||
  meta.isSeedAudioGenerated||
  meta.seedAudioGenerated||
  meta.seedAudioPrompt||
  meta.generationTaskId||
  meta.taskId||
  meta.source==="dreamina-seed-audio"||
  meta.source==="seed_audio"||
  meta.origin==="seed_audio"||
  asset.source==="dreamina-seed-audio"||
  asset.source==="seed_audio"||
  /-(补词|商用音色|情绪配音)/u.test(asset.title||"")
 );
}

function dedupeAudioList(list:Array<Extract<Asset,{kind:"audio"}>>){
 const seen=new Set<string>();
 return list.filter(a=>{
  const key=a.title.normalize("NFKC").trim().toLowerCase()+"|"+Math.round((a.data.durationMs||0)/200);
  if(seen.has(key))return false;
  seen.add(key);
  return true;
 });
}

type Props={
 items:Asset[];
 catalog:Asset[];
 selectedRole:string;
 inspectedAssetId?:string;
 flashIds?:string[];
 sort?:string;
 onInspect?:(asset:Asset,groupKey:string)=>void;
 onClearRole?:()=>void;
 onAddForRole?:(roleName:string)=>void;
 renderCard:(asset:Asset,eager?:boolean)=>ReactNode;
 selectionFor?:(asset:Asset)=>ReactNode;
 onAdd:(category:string)=>void;
 onEdit:(asset:Asset)=>void;
 onReference:(asset:Asset)=>void;
};

export function ElementArchive({items,catalog,selectedRole,inspectedAssetId,flashIds=[],sort="serial",onInspect,onClearRole,onAddForRole,renderCard,onAdd,onEdit,onReference,selectionFor}:Props){
 const {message}=App.useApp();
 const archiveRootRef=useRef<HTMLDivElement>(null);
 const groups=useMemo(()=>groupElements(items,catalog),[items,catalog]),allGroups=useMemo(()=>groupElements(catalog),[catalog]),[selected,setSelected]=useState("");
 useElementReorder(archiveRootRef,(scope,orderedKeys)=>{
  if(scope.startsWith("group:")){
   const keyToOrder=new Map(orderedKeys.map((k,idx)=>[k,idx+1]));
   const assetOrderMap=new Map<string,number>();
   for(const g of allGroups){
    const ord=keyToOrder.get(g.key);
    if(ord){
     for(const item of g.items)assetOrderMap.set(item.id,ord);
    }
   }
   for(const g of groups){
    const ord=keyToOrder.get(g.key);
    if(ord){
     for(const item of g.items)assetOrderMap.set(item.id,ord);
    }
   }
   if(assetOrderMap.size){
    useAssetStore.setState(s=>({
     assets:s.assets.map(a=>assetOrderMap.has(a.id)?{...a,metadata:{...a.metadata,elementGroupSortOrder:assetOrderMap.get(a.id)}}:a),
    }));
   }
   return;
  }
  const rank=new Map(orderedKeys.map((k,idx)=>[k,idx+1]));
  if(rank.size){
   useAssetStore.setState(s=>({
    assets:s.assets.map(a=>rank.has(a.id)?{...a,metadata:{...a.metadata,elementSortOrder:rank.get(a.id)}}:a),
   }));
  }
 });
 const [variantOffsets,setVariantOffsets]=useState<Record<string,number>>({});
 const [showRoleDisabled,setShowRoleDisabled]=useState(true);
 useEffect(()=>{setShowRoleDisabled(true);},[selectedRole]);
 const rules=useVideoStudioStore(s=>s.projects.find(p=>p.id===s.activeProjectId)?.elementRules);
 const activeProjectId=useVideoStudioStore(s=>s.activeProjectId);
 const allStudioGroups=useVideoStudioStore(s=>s.groups);
 const groupElementIds=useVideoStudioStore(s=>s.groupElementIds);
 const studioGroups=useMemo(()=>allStudioGroups.filter(g=>g.projectId===activeProjectId),[allStudioGroups,activeProjectId]);
 const activeDraft=useVideoStudioStore(s=>s.drafts[s.activeProjectId]);
 const [audioOutputDir,setAudioOutputDir]=useState<string>(()=>getSavedAudioOutputDir());
 useEffect(()=>{
  setAudioOutputDir(getSavedAudioOutputDir());
  const onDirChange=(e:Event)=>{
   const detail=(e as CustomEvent)?.detail;
   setAudioOutputDir(typeof detail?.dir==="string"?detail.dir:getSavedAudioOutputDir());
  };
  window.addEventListener("xiaoxiao:audio-output-dir-changed",onDirChange);
  return ()=>window.removeEventListener("xiaoxiao:audio-output-dir-changed",onDirChange);
 },[]);
 const chooseDubFolder=async()=>{
  const picked=await chooseLocalDirectory(audioOutputDir||undefined,"选择生成配音与台词库保存文件夹（切换文件夹不影响已生成音频链接）");
  if(picked){
   setSavedAudioOutputDir(picked);
   setAudioOutputDir(picked);
   message.success(`已设置生成配音保存文件夹：${picked}`);
  }
 };
 const sceneUsageMap=useMemo(()=>{
  const map=new Map<string,{count:number;recent:boolean;tier:number;label:string}>();
  if(!studioGroups.length)return map;
  const sentGroups=studioGroups.filter(g=>Array.isArray(g.logIds)&&g.logIds.length>0);
  const recentGroupIds=new Set(sentGroups.slice(-3).map(g=>g.id));
  const draftRefIds=new Set<string>([
   ...((activeDraft?.references||[]).map((r:any)=>String(r?.assetId||"")).filter(Boolean)),
   ...(activeDraft?.firstFrame?.assetId?[String(activeDraft.firstFrame.assetId)]:[]),
   ...(activeDraft?.lastFrame?.assetId?[String(activeDraft.lastFrame.assetId)]:[]),
  ]);
  for(const g of groups){
   if(g.category!=="场景")continue;
   const itemIds=new Set(g.items.map(i=>i.id));
   let count=0;
   let recent=g.items.some(i=>draftRefIds.has(i.id));
   for(const sg of sentGroups){
    const scopeIds=groupElementIds[`${activeProjectId}:${sg.id}`]||[];
    const hitGroupElement=scopeIds.some(id=>itemIds.has(id));
    const hitBinding=sg.bindings?Object.entries(sg.bindings).some(([k,id])=>!k.startsWith("omit:")&&itemIds.has(id)):false;
    if(hitGroupElement||hitBinding){
     count++;
     if(recentGroupIds.has(sg.id))recent=true;
    }
   }
   const tier=count>=3?3:recent&&count>0?2:count===0?1:0;
   const label=count>=3?`常用·${count}组`:recent&&count>0?`近期在用·${count}组`:count>0?`已用·${count}组`:"";
   map.set(g.key,{count,recent,tier,label});
  }
  return map;
 },[groups,studioGroups,groupElementIds,activeProjectId,activeDraft?.references,activeDraft?.firstFrame,activeDraft?.lastFrame]);
 const picked=allGroups.find(g=>g.key===selected),voices=picked?.category==="人物"?dedupeAudioList((allGroups.find(g=>g.category==="音频"&&g.name===picked.name)?.items||[]).filter((a):a is Extract<Asset,{kind:"audio"}>=>a.kind==="audio"&&!rules?.[a.id]?.disabled)):[];
 const sections=[...new Set(groups.map(g=>g.category))];
 const activeRoleGroup=selectedRole?allGroups.find(g=>g.key===selectedRole):undefined;

 if(activeRoleGroup){
  const roleVisuals=sortAssetsBy(items.filter(a=>a.kind!=="audio"),sort,rules);
  const disabledVisuals=sortAssetsBy(activeRoleGroup.items.filter(a=>a.kind!=="audio"&&Boolean(rules?.[a.id]?.disabled)),sort,rules);
  const roleAudios = sortAssetsBy(dedupeAudioList(items.filter((a): a is Extract<Asset, { kind: "audio" }> => a.kind === "audio")), sort, rules) as Extract<Asset, { kind: "audio" }>[];
  return <div ref={archiveRootRef} className="asset-archive" data-element-archive data-role-showcase={activeRoleGroup.name}>
   <div className="archive-content">
    <section className="archive-section" data-archive-category="人物">
     <div className="wb-role-showcase-head">
      <div className="flex min-w-0 items-baseline gap-2.5">
       <h2 className="archive-heading !m-0">{activeRoleGroup.name}</h2>
       <span className="text-xs text-muted-foreground">共 {roleVisuals.length} 张展示图{roleAudios.length?` · ${roleAudios.length} 条配音声线`:""}</span>
      </div>
      <div className="flex flex-wrap items-center gap-2">
       {disabledVisuals.length>0&&<Button size="small" type={showRoleDisabled?"default":"text"} icon={<EyeOff className="size-3.5"/>} onClick={()=>setShowRoleDisabled(v=>!v)}>{showRoleDisabled?`收起已禁用 (${disabledVisuals.length})`:`查看已禁用 (${disabledVisuals.length})`}</Button>}
       {onClearRole&&<Button size="small" icon={<ArrowLeft className="size-3.5"/>} onClick={onClearRole}>返回全部</Button>}
       <Button size="small" type="primary" icon={<Plus className="size-3.5"/>} onClick={()=>onAddForRole?onAddForRole(activeRoleGroup.name):onAdd("人物")}>添加「{activeRoleGroup.name}」设定图</Button>
      </div>
     </div>
     {roleVisuals.length===0?<Empty description="当前角色没有启用的展示图"/>:<div className="wb-role-showcase-grid">
      {roleVisuals.map((a,idx)=><LocalAssetMenu key={a.id} asset={a} hideRelink hideRolePin><article data-archive-card={a.id} data-element-sort-key={a.id} data-element-sort-scope={"role:"+activeRoleGroup.key} data-asset-flash={flashIds.includes(a.id)?"true":undefined} className="group relative wb-role-showcase-card" draggable onDragStart={event=>{writeElementDrag(event.dataTransfer,a);}}>
       {selectionFor?.(a)}<button type="button" aria-label={"预览 "+a.title} title="点击放大查看高清大图（长按可拖动调整顺序）" className="wb-role-showcase-thumb" onClick={()=>{onInspect?.(a,activeRoleGroup.key);onEdit(a);}}>
        <ElementThumbnail asset={a} eager={idx<8}/>
        {Number(rules?.[a.id]?.priority)>0&&<span className="archive-priority"><Star size={10}/>优先{rules?.[a.id]?.priority}</span>}
       </button>
       <div className="wb-role-showcase-foot">
        <span className="min-w-0 flex-1 truncate text-xs font-semibold" title={a.title}>{a.title}</span>
        <button type="button" className="wb-inline-primary-btn" disabled={Boolean(rules?.[a.id]?.disabled)} onClick={e=>{e.stopPropagation();onReference(a);}}><AtSign size={12}/>引用</button>
       </div>
      </article></LocalAssetMenu>)}
     </div>}
     {showRoleDisabled&&disabledVisuals.length>0&&<div className="mt-5 border-t border-border pt-4">
      <h3 className="mb-3 text-xs font-semibold text-muted-foreground">已禁用的备用图（点击可查看大图或重新启用）</h3>
      <div className="wb-role-showcase-grid">
       {disabledVisuals.map(a=><LocalAssetMenu key={a.id} asset={a} hideRelink hideRolePin><article data-disabled-asset={a.id} data-asset-flash={flashIds.includes(a.id)?"true":undefined} className="group relative wb-role-showcase-card">
        <button type="button" aria-label={"预览 "+a.title} className="wb-role-showcase-thumb" onClick={()=>{onInspect?.(a,activeRoleGroup.key);onEdit(a);}}>
         <ElementThumbnail asset={a}/>
        </button>
        <div className="wb-role-showcase-foot">
         <span className="min-w-0 flex-1 truncate text-xs text-muted-foreground" title={a.title}>{a.title}（已禁用）</span>
        </div>
       </article></LocalAssetMenu>)}
      </div>
     </div>}
    </section>
    {roleAudios.length>0&&<section className="archive-section" data-archive-category="音频">
     <h2 className="archive-heading">配音声线<span>{roleAudios.length} 条声纹</span></h2>
     <div className="wb-audio-grid">
      {roleAudios.map(audioAsset=><ElementAudioStripCard key={audioAsset.id} asset={audioAsset} sortScope={"audio:role:"+activeRoleGroup.key} flash={flashIds.includes(audioAsset.id)} selection={selectionFor?.(audioAsset)} roleName={activeRoleGroup.name} selected={inspectedAssetId===audioAsset.id} onInspect={()=>onInspect?.(audioAsset,activeRoleGroup.key)} onEdit={()=>onEdit(audioAsset)} onReference={()=>onReference(audioAsset)}/>)}
     </div>
    </section>}
   </div>
  </div>;
 }

 return <div ref={archiveRootRef} className="asset-archive" data-element-archive><div className="archive-content">{!groups.length&&<Empty description="没有符合筛选条件的素材"/>}{sections.map(section=>{
 const audioItems=section==="音频"?groups.filter(g=>g.category==="音频").flatMap(g=>dedupeAudioList(g.items.filter((a):a is Extract<Asset,{kind:"audio"}>=>a.kind==="audio")).map(audioAsset=>({audioAsset,roleName:g.name,groupKey:g.key}))):[];
 const sourceItems=section==="音频"?sortAssetsBy(audioItems.filter(item=>!isGeneratedDubAudio(item.audioAsset)).map(i=>i.audioAsset),sort,rules).map(a=>audioItems.find(i=>i.audioAsset.id===a.id)!):[];
 const voicePrintItems=sourceItems;
 const generatedDubItems=section==="音频"?sortAssetsBy(audioItems.filter(item=>isGeneratedDubAudio(item.audioAsset)).map(i=>i.audioAsset),sort,rules).map(a=>audioItems.find(i=>i.audioAsset.id===a.id)!):[];
 const sectionGroups=groups.filter(g=>g.category===section).sort((a,b)=>{
  if(sort==="name")return a.name.localeCompare(b.name,"zh-CN",{numeric:true});
  if(sort==="newest"){const timeA=Math.max(0,...a.items.map(item=>Date.parse(item.createdAt)||0)),timeB=Math.max(0,...b.items.map(item=>Date.parse(item.createdAt)||0));return timeB-timeA;}
  if(sort==="oldest"){const timeA=Math.min(...a.items.map(item=>Date.parse(item.createdAt)||Infinity)),timeB=Math.min(...b.items.map(item=>Date.parse(item.createdAt)||Infinity));return timeA-timeB;}
  if(sort==="used"){const usedA=Math.max(0,...a.items.map(item=>elementInfo(item).lastUsedAt)),usedB=Math.max(0,...b.items.map(item=>elementInfo(item).lastUsedAt));return usedB-usedA;}
  const pinDiff=Math.max(0,...b.items.map(elementPinnedAt))-Math.max(0,...a.items.map(elementPinnedAt));
  if(pinDiff!==0)return pinDiff;
  const prioA=Math.max(0,...a.items.map(item=>Number(rules?.[item.id]?.priority)||0));
  const prioB=Math.max(0,...b.items.map(item=>Number(rules?.[item.id]?.priority)||0));
  if(prioB!==prioA)return prioB-prioA;
  const sortValsA=a.items.map(elementGroupSortOrder).filter(n=>n>0);
  const sortValsB=b.items.map(elementGroupSortOrder).filter(n=>n>0);
  const gSortA=sortValsA.length?Math.min(...sortValsA):0;
  const gSortB=sortValsB.length?Math.min(...sortValsB):0;
  if(gSortA>0||gSortB>0){
   const gDiff=(gSortA||999999)-(gSortB||999999);
   if(gDiff!==0)return gDiff;
  }
  if(section!=="场景"||!sceneUsageMap.size)return 0;
  const uA=sceneUsageMap.get(a.key)||{tier:1,count:0};
  const uB=sceneUsageMap.get(b.key)||{tier:1,count:0};
  if(uB.tier!==uA.tier)return uB.tier-uA.tier;
  if(uB.count!==uA.count)return uB.count-uA.count;
  return a.name.localeCompare(b.name,"zh-CN",{numeric:true});
 });

 if(section==="视频"){
  const isVid=(g:(typeof sectionGroups)[0])=>g.items.some(isVideoAsset)||!g.items.every(isImageAsset);
  const videoGroups=sectionGroups.filter(isVid);
  const imageGroups=sectionGroups.filter(g=>!isVid(g));
  const totalVideos=videoGroups.reduce((acc,g)=>acc+g.items.filter(isVideoAsset).length,0);
  const totalImages=imageGroups.reduce((acc,g)=>acc+g.items.filter(isImageAsset).length,0);

  const renderVideoCategoryCard=(g:(typeof sectionGroups)[0],idx:number,badgeText:"视频"|"图片")=>{
   const family=allGroups.find(v=>v.key===g.key)||g;
   const orderedPictures=sortAssetsBy(g.items.filter(a=>isImageAsset(a)),sort,rules);
   const offset=variantOffsets[g.key]||0;
   const cover=orderedPictures.length?orderedPictures[offset%orderedPictures.length]:sortAssetsBy(g.items,sort,rules)[0]||g.items[0];
   const hasStack=orderedPictures.length>1;
   const isCardSelected=selected===g.key||selectedRole===g.key;
   const isGroupPinned=family.items.some(a=>elementPinnedAt(a)>0);
   const isGroupFlashed=g.items.some(a=>flashIds.includes(a.id));
   const toggleGroupPin=()=>{
    const next=isGroupPinned?0:Date.now(),ids=new Set(family.items.map(item=>item.id));
    useAssetStore.setState(s=>({
     assets:s.assets.map(a=>ids.has(a.id)?{...a,metadata:{...a.metadata,elementPinnedAt:next}}:a),
    }));
    message.success(isGroupPinned?"已取消置顶":"已置顶视频素材");
   };

   return <LocalAssetMenu key={g.key} asset={cover} hideRelink><article data-archive-card={g.key} data-element-card={cover.id} data-element-sort-key={g.key} data-element-sort-scope={"group:视频"} data-asset-flash={isGroupFlashed?"true":undefined} data-has-stack={hasStack||undefined} data-selected={isCardSelected} className={"group relative archive-group "+(hasStack?"has-variant-stack ":"")} draggable onDragStart={event=>{writeElementDrag(event.dataTransfer,cover);}} onClick={()=>onInspect?.(cover,g.key)}>
   {selectionFor?.(cover)}<div className="archive-group-cover-wrap">
    <button type="button" className="archive-group-cover" aria-label={"预览 "+g.name} title="点击放大查看高清大图" onClick={e=>{e.stopPropagation();onInspect?.(cover,g.key);onEdit(cover);}}>
     <ElementThumbnail asset={cover} eager={idx<6}/>
     {Number(rules?.[cover.id]?.priority)>0&&<span className="archive-priority"><Star size={10}/>优先{rules?.[cover.id]?.priority}</span>}
    </button>
    {hasStack&&<button type="button" data-variant-cycle={g.key} aria-label={"切换变体 "+g.name} title="点击在卡片上切换变体封面" className="wb-stack-cycle-pill" onClick={e=>{e.stopPropagation();const next=(offset+1)%orderedPictures.length;setVariantOffsets(prev=>({...prev,[g.key]:next}));onInspect?.(orderedPictures[next],g.key);}}><Layers size={11}/><span>{(offset%orderedPictures.length)+1}/{orderedPictures.length}</span><RefreshCw size={10}/></button>}
   </div>
   <div className="archive-group-main"><div className="archive-title-row"><button type="button" data-archive-group={g.key} aria-label={"查看素材归档 "+g.name} className="archive-title" title={g.name} onClick={e=>{e.stopPropagation();setSelected(g.key);}}>{cover.title}</button>{isGroupPinned&&<span data-pinned-badge title="已置顶" aria-label="已置顶" className="inline-flex shrink-0 items-center justify-center rounded bg-amber-500/18 px-1 py-0.5 text-[11px] font-semibold text-amber-700 ring-1 ring-amber-500/35 dark:text-amber-300">📌</span>}<span className="archive-kind">{badgeText}</span><Dropdown trigger={["click"]} menu={{items:[{key:"pin",label:isGroupPinned?"取消置顶":"置顶视频素材"},{key:"detail",label:"展开全部变体抽屉"},{key:"edit",label:"大图查看与编辑"},{key:"use",label:"引用当前素材",disabled:Boolean(rules?.[cover.id]?.disabled)}],onClick:({key})=>key==="pin"?toggleGroupPin():key==="detail"?setSelected(g.key):key==="edit"?onEdit(cover):onReference(cover)}}><button type="button" aria-label={g.name+" 更多操作"} className="archive-more" onClick={e=>e.stopPropagation()}><MoreHorizontal size={17}/></button></Dropdown></div>
   <span className="archive-meta">{`分组：${g.name}（共 ${orderedPictures.length?orderedPictures.length+" 张":g.items.length+" 份素材"}）`}</span>
   <div className="archive-quick-row"><button type="button" className="wb-inline-ghost-btn" onClick={e=>{e.stopPropagation();setSelected(g.key);}}>全部参考</button><button type="button" className="wb-inline-primary-btn" disabled={Boolean(rules?.[cover.id]?.disabled)} onClick={e=>{e.stopPropagation();onReference(cover);}}><AtSign size={12}/>引用</button></div>
   </div></article></LocalAssetMenu>;
  };

  return <section key={section} className="archive-section" data-archive-category="视频">
   <div className="space-y-6" data-video-category-subgroups>
    <div data-video-subgroup="video">
     <div className="mb-3 flex items-center justify-between">
      <h2 className="archive-heading !m-0">视频<span>{totalVideos} 个视频</span></h2>
     </div>
     {videoGroups.length>0?(
      <div className="archive-grid">
       {videoGroups.map((g,i)=>renderVideoCategoryCard(g,i,"视频"))}
      </div>
     ):(
      <p className="text-xs text-muted-foreground">暂无视频素材</p>
     )}
    </div>
    <div data-video-subgroup="image" className="border-t border-border/80 pt-4">
     <div className="mb-3 flex items-center justify-between">
      <h2 className="archive-heading !m-0">图片<span>{totalImages} 张图片（视频截帧与参考图）</span></h2>
     </div>
     {imageGroups.length>0?(
      <div className="archive-grid">
       {imageGroups.map((g,i)=>renderVideoCategoryCard(g,i,"图片"))}
      </div>
     ):(
      <p className="text-xs text-muted-foreground">暂无截帧或图片素材</p>
     )}
    </div>
   </div>
  </section>;
 }
 return <section key={section} className="archive-section" data-archive-category={section}>{section==="音频"?<><div className="mb-3 flex flex-wrap items-center justify-between gap-2"><h2 className="archive-heading !m-0">生成配音与台词库<span>{audioItems.length} 条音频（{sourceItems.length} 条可引用声源 · {generatedDubItems.length} 条已生成）</span></h2><div className="flex items-center gap-1.5"><Button size="small" data-archive-dub-folder-btn icon={<FolderOpen className="size-3.5"/>} onClick={()=>void chooseDubFolder()} title={audioOutputDir?`当前新生成配音将保存到：${audioOutputDir}（切换文件夹不会影响已生成音频在工作台的链接）`:"选择新生成配音的保存文件夹（切换文件夹不会丢失已有音频链接）"}>{audioOutputDir?`保存至：${audioOutputDir.split(/[\\/]/).filter(Boolean).pop()||audioOutputDir}`:"选择保存文件夹"}</Button>{audioOutputDir&&<Button size="small" type="text" title="恢复默认保存目录" onClick={()=>{setSavedAudioOutputDir("");setAudioOutputDir("");message.success("已恢复默认配音保存目录");}}>恢复默认</Button>}</div></div><div data-audio-subgroup="source" className="mt-2 space-y-2"><div className="flex items-center justify-between border-b border-border/60 pb-1.5"><h3 className="text-xs font-semibold text-foreground flex items-center gap-1.5"><span>🎙️ 可引用声源</span><span className="text-[11px] font-normal text-muted-foreground">（{sourceItems.length} 条 · 可作为声线或参考音色引用）</span></h3></div>{sourceItems.length>0?<div className="wb-audio-grid">{sourceItems.map(({audioAsset,roleName,groupKey})=><ElementAudioStripCard key={audioAsset.id} asset={audioAsset} sortScope="audio:source" flash={flashIds.includes(audioAsset.id)} selection={selectionFor?.(audioAsset)} roleName={roleName} selected={inspectedAssetId===audioAsset.id} onInspect={()=>onInspect?.(audioAsset,groupKey)} onEdit={()=>onEdit(audioAsset)} onReference={()=>onReference(audioAsset)}/>)}</div>:<p className="text-xs text-muted-foreground py-2">暂无可引用声源素材。从外部拖入音频或在角色库添加的声线将归入此处，可直接作为参考音色引用。</p>}</div><div data-audio-subgroup="generated" className="mt-5 border-t border-border/80 pt-4 space-y-2"><div className="flex items-center justify-between border-b border-border/60 pb-1.5"><h3 className="text-xs font-semibold text-foreground flex items-center gap-1.5"><span>✨ 已生成</span><span className="text-[11px] font-normal text-muted-foreground">（{generatedDubItems.length} 条 · 即梦 SeedAudio 生成回传的配音与台词）</span></h3></div>{generatedDubItems.length>0?<div className="wb-audio-grid">{generatedDubItems.map(({audioAsset,roleName,groupKey})=><ElementAudioStripCard key={audioAsset.id} asset={audioAsset} sortScope="audio:dub" flash={flashIds.includes(audioAsset.id)} selection={selectionFor?.(audioAsset)} roleName={roleName} selected={inspectedAssetId===audioAsset.id} onInspect={()=>onInspect?.(audioAsset,groupKey)} onEdit={()=>onEdit(audioAsset)} onReference={()=>onReference(audioAsset)}/>)}</div>:<p className="text-xs text-muted-foreground py-2">暂无即梦 SeedAudio 生成的配音或台词，可在右侧提示词面板切到「音频」模式创作，生成后自动归入此处并保存到选定文件夹。</p>}</div></>:<><h2 className="archive-heading">{section}<span>{sectionGroups.length+(section==="人物"?" 个角色":section==="场景"?" 组空间":" 组")}</span></h2><div className="archive-grid">{sectionGroups.map((g,i)=>{
 const family=allGroups.find(v=>v.key===g.key)||g;
 const orderedPictures=sortAssetsBy(g.items.filter(a=>isImageAsset(a)),sort,rules);
 const offset=variantOffsets[g.key]||0;
 const cover=orderedPictures.length?orderedPictures[offset%orderedPictures.length]:sortAssetsBy(g.items,sort,rules)[0]||g.items[0];
 const hasStack=orderedPictures.length>1;
 const voice=dedupeAudioList((section==="人物"?allGroups.find(v=>v.category==="音频"&&v.name===g.name)?.items||[]:g.items).filter((a):a is Extract<Asset,{kind:"audio"}>=>a.kind==="audio"&&!rules?.[a.id]?.disabled));
 const disabled=family.items.filter(a=>rules?.[a.id]?.disabled).length;
 const isCardSelected=selected===g.key||selectedRole===g.key;
 const isGroupPinned=family.items.some(a=>elementPinnedAt(a)>0);
 const isGroupFlashed=g.items.some(a=>flashIds.includes(a.id));
 const sceneUsage=section==="场景"?sceneUsageMap.get(g.key):undefined;
 const toggleGroupPin=()=>{const next=isGroupPinned?0:Date.now(),ids=new Set(family.items.map(item=>item.id));useAssetStore.setState(s=>({assets:s.assets.map(a=>ids.has(a.id)?{...a,metadata:{...a.metadata,...(section==="人物"?{elementRolePinnedAt:next}:{}),elementPinnedAt:next}}:a)}));message.success(isGroupPinned?"已取消置顶":`已置顶${section}`);};

 return <LocalAssetMenu key={g.key} asset={cover} hideRelink><article data-archive-card={g.key} data-element-card={cover.id} data-element-sort-key={g.key} data-element-sort-scope={"group:"+section} data-asset-flash={isGroupFlashed?"true":undefined} data-has-stack={hasStack||undefined} data-selected={isCardSelected} className={"group relative archive-group "+(hasStack?"has-variant-stack ":"")+(section==="场景"?"archive-scene":"")} draggable onDragStart={event=>{writeElementDrag(event.dataTransfer,cover);}} onClick={()=>onInspect?.(cover,g.key)}>
 {selectionFor?.(cover)}<div className="archive-group-cover-wrap">
  <button type="button" className="archive-group-cover" aria-label={"预览 "+g.name} title="点击放大查看高清大图" onClick={e=>{e.stopPropagation();onInspect?.(cover,g.key);onEdit(cover);}}>
   <ElementThumbnail asset={cover} eager={i<6}/>
   {Number(rules?.[cover.id]?.priority)>0&&<span className="archive-priority"><Star size={10}/>优先{rules?.[cover.id]?.priority}</span>}
  </button>
  {hasStack&&<button type="button" data-variant-cycle={g.key} aria-label={"切换变体 "+g.name} title="点击在卡片上切换变体封面" className="wb-stack-cycle-pill" onClick={e=>{e.stopPropagation();const next=(offset+1)%orderedPictures.length;setVariantOffsets(prev=>({...prev,[g.key]:next}));onInspect?.(orderedPictures[next],g.key);}}><Layers size={11}/><span>{(offset%orderedPictures.length)+1}/{orderedPictures.length}</span><RefreshCw size={10}/></button>}
 </div>
 <div className="archive-group-main"><div className="archive-title-row"><button type="button" data-archive-group={g.key} aria-label={"查看素材归档 "+g.name} className="archive-title" title={g.name} onClick={e=>{e.stopPropagation();setSelected(g.key);}}>{cover.title}</button>{isGroupPinned&&<span data-pinned-badge title="已置顶" aria-label="已置顶" className="inline-flex shrink-0 items-center justify-center rounded bg-amber-500/18 px-1 py-0.5 text-[11px] font-semibold text-amber-700 ring-1 ring-amber-500/35 dark:text-amber-300">📌</span>}{sceneUsage?.label&&<span data-scene-usage-badge className={`inline-flex shrink-0 items-center rounded px-1.5 py-0.5 text-[10px] font-medium ${sceneUsage.tier>=3?"bg-emerald-500/15 text-emerald-700 dark:text-emerald-300":sceneUsage.tier===2?"bg-sky-500/15 text-sky-700 dark:text-sky-300":"bg-muted text-muted-foreground"}`}>{sceneUsage.label}</span>}{section==="人物"?<span className="archive-kind">人物</span>:<span className="archive-kind">{section}</span>}<Dropdown trigger={["click"]} menu={{items:[{key:"pin",label:isGroupPinned?"取消置顶":`置顶${section}`},{key:"detail",label:"展开全部变体抽屉"},{key:"edit",label:"大图查看与编辑"},{key:"use",label:"引用当前素材",disabled:Boolean(rules?.[cover.id]?.disabled)}],onClick:({key})=>key==="pin"?toggleGroupPin():key==="detail"?setSelected(g.key):key==="edit"?onEdit(cover):onReference(cover)}}><button type="button" aria-label={g.name+" 更多操作"} className="archive-more" onClick={e=>e.stopPropagation()}><MoreHorizontal size={17}/></button></Dropdown></div>
 <span className="archive-meta">{`分组：${g.name}（共 ${orderedPictures.length?orderedPictures.length+" 张":g.items.length+" 份素材"}）`}{section==="人物"&&voice.length?" · "+voice.length+" 个音色":""}</span>
 {section==="人物"&&orderedPictures.length>1&&<div className="archive-miniatures">{orderedPictures.slice(0,4).map((a,idx)=><button type="button" key={a.id} data-active={a.id===cover.id||undefined} aria-label={"切换参考 "+a.title} title={a.title+"（点击放大查看）"} onClick={e=>{e.stopPropagation();setVariantOffsets(prev=>({...prev,[g.key]:idx}));onInspect?.(a,g.key);onEdit(a);}}><ElementThumbnail asset={a}/></button>)}{disabled>0&&<button type="button" className="archive-disabled" onClick={e=>{e.stopPropagation();setSelected(g.key);}}>+{disabled} 已禁用</button>}</div>}
 {voice.slice(0,1).map(a=><ArchiveAudio key={a.id} asset={a}/>)}

 <div className="archive-quick-row"><button type="button" className="wb-inline-ghost-btn" onClick={e=>{e.stopPropagation();setSelected(g.key);}}>全部参考</button><button type="button" className="wb-inline-primary-btn" disabled={Boolean(rules?.[cover.id]?.disabled)} onClick={e=>{e.stopPropagation();onReference(cover);}}><AtSign size={12}/>引用</button></div>
 </div></article></LocalAssetMenu>;
 })}{(section==="人物"||section==="场景"||section==="道具")&&<button type="button" className="archive-add" onClick={()=>onAdd(section)}><Plus size={21}/>{section==="人物"?"新建角色":section==="道具"?"新建道具":"新建场景"}</button>}</div></>}</section>;})}</div>
 <Drawer open={Boolean(picked)} onClose={()=>setSelected("")} title={picked?.name||"素材档案"} width={420} zIndex={900} destroyOnHidden>{picked&&<><p className="archive-meta mb-4">{picked.category} · {picked.items.length} 份素材</p>{picked.items.find(a=>a.kind==="image")&&<div className="archive-detail-cover"><ElementThumbnail asset={picked.items.find(a=>a.kind==="image")!} eager/></div>}<h3 className="archive-detail-heading">参考素材</h3><div className="archive-detail-grid">{[...sortAssetsBy(picked.items,sort,rules)].map((a,i)=>renderCard(a,i<4))}</div>{voices.length>0&&<section className="mt-6"><h3 className="mb-3 font-semibold">音色</h3>{voices.map(a=><div key={a.id} className="mb-4">{a.kind==="audio"&&<ArchiveAudio asset={a}/>}<Button size="small" className="mt-2" onClick={()=>onReference(a)}>引用音色</Button></div>)}</section>}</>}</Drawer></div>;
}
