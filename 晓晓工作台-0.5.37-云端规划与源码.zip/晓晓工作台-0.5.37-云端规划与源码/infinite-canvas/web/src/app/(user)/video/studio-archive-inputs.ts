import type { GenerationLog } from "./page";
import { placementFor, type Placement } from "./studio-model";

// Task progress, timers and errors do not change the files to archive.
// Keep file identity and destination in the key so new results and moves sync immediately.
export function studioArchiveInputs(logs: GenerationLog[], projectId: string, placements: Record<string, Placement>) {
    return JSON.stringify(logs.flatMap(log => {
        if (!log.video) return [];
        const placement = placementFor(placements, log.id);
        if (placement.projectId !== projectId) return [];
        return [[log.id, log.title, log.prompt, log.video, log.task?.id, placement.folderId]];
    }));
}
