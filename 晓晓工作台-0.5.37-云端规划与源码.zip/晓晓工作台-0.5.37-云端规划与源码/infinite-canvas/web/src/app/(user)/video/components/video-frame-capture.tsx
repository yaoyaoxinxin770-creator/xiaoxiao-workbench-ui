"use client";
import {useEffect,useState,type RefObject} from 'react';
import {App,Button} from 'antd';
import {Play,Pause,Volume2,VolumeX,Maximize2,Bot,Camera} from 'lucide-react';
import {useAssetStore} from '@/stores/use-asset-store';
import {useVideoStudioStore} from '@/stores/use-video-studio-store';
import {uploadImage} from '@/services/image-storage';
import {placementFor} from '../studio-model';
import {showStudioAsset} from '../asset-navigation';
import {captureVideoFrame,seekVideoFrame,frameAssetTitle} from '../video-frame';
import type {GenerationLog} from '../page';
export function VideoFrameCapture({log,playerRef,onClose,speed=1,onSpeedChange,metaText}:{log:GenerationLog;playerRef:RefObject<HTMLVideoElement|null>;onClose:()=>void;speed?:number;onSpeedChange?:(value:number)=>void;metaText?:string}){
 const {message}=App.useApp(),[time,setTime]=useState(0),[duration,setDuration]=useState(0),[playing,setPlaying]=useState(false),[muted,setMuted]=useState(false),[saving,setSaving]=useState(false),[sendingAgent,setSendingAgent]=useState(false),fps=log.task?.interpolatedFps||30;
 useEffect(()=>{
  const video=playerRef.current;if(!video)return;
  const update=()=>{setTime(video.currentTime);setDuration(Number.isFinite(video.duration)?video.duration:0);setPlaying(!video.paused&&!video.ended);setMuted(video.muted);};
  update();
  video.addEventListener('timeupdate',update);video.addEventListener('loadedmetadata',update);video.addEventListener('play',update);video.addEventListener('pause',update);video.addEventListener('ended',update);video.addEventListener('volumechange',update);
  return()=>{video.removeEventListener('timeupdate',update);video.removeEventListener('loadedmetadata',update);video.removeEventListener('play',update);video.removeEventListener('pause',update);video.removeEventListener('ended',update);video.removeEventListener('volumechange',update);};
 },[log.id,playerRef]);
 const seek=(value:number)=>{if(saving||sendingAgent)return;const video=playerRef.current;if(video){const clamped=Math.max(0,Math.min(value,Math.max(0,duration-0.001)));setTime(clamped);video.pause();video.currentTime=clamped;}};
 const togglePlay=()=>{const video=playerRef.current;if(!video)return;if(video.paused||video.ended){void video.play().catch(()=>{});}else{video.pause();}};
 const toggleMute=()=>{const video=playerRef.current;if(!video)return;video.muted=!video.muted;setMuted(video.muted);};
 const requestFull=()=>{const video=playerRef.current;if(!video)return;if(video.requestFullscreen)void video.requestFullscreen().catch(()=>{});};
 const format=(t:number)=>String(Math.floor(t/60)).padStart(2,'0')+':'+String(Math.floor(t%60)).padStart(2,'0')+'.'+String(Math.floor((t%1)*fps)).padStart(2,'0');
 const resolveProjectId=()=>{
  const state=useVideoStudioStore.getState();
  const group=state.groups.find(g=>g.logIds.includes(log.id));
  const rawPlacement=state.placements[log.id];
  return rawPlacement?.projectId||group?.projectId||state.activeProjectId||placementFor(state.placements,log.id).projectId;
 };
 const navigateToAsset = (projectId: string, assetId: string) => {
  onClose();
  window.dispatchEvent(new CustomEvent('xiaoxiao:close-video-detail'));
  showStudioAsset({ projectId, id: assetId, category: '视频' });
 };
 const ensureSavedFrameAsset = async (video: HTMLVideoElement, frameTime: number) => {
  const assets = useAssetStore.getState().assets;
  const title = frameAssetTitle(log.prompt || log.title, frameTime, fps, assets.map(a => a.title));
  const projectId = resolveProjectId();
  const targetMs = Math.round(frameTime * 1000);

  const existing = assets.find(a =>
   a.category === '视频' &&
   (a.title === title || a.title === `${title}.png` ||
    (a.metadata?.sourceLogId === log.id && Math.abs(Number(a.metadata?.frameTimeMs || 0) - targetMs) < 40))
  );

  if (existing) {
   useVideoStudioStore.getState().addElement(existing.id, projectId);
   const existingDataUrl = (existing.data && 'dataUrl' in existing.data ? String(existing.data.dataUrl) : '') || existing.coverUrl || '';
   return {
    id: existing.id,
    title: existing.title.replace(/\.png$/i, ''),
    dataUrl: existingDataUrl,
    projectId,
    reused: true,
   };
  }

  await seekVideoFrame(video, frameTime);
  const blob = await captureVideoFrame(video, frameTime);
  const file = new File([blob], `${title}.png`, { type: 'image/png' });
  const image = await uploadImage(file, { localOnly: true });

  const id = useAssetStore.getState().addAsset({
   kind: 'image',
   title,
   category: '视频',
   tags: [],
   coverUrl: image.url,
   data: { ...image, dataUrl: image.url },
   metadata: {
    source: '视频截帧',
    sourceLogId: log.id,
    frameTimeMs: targetMs,
    elementManualCategory: '视频',
    elementManualGroup: '',
   },
  });

  useVideoStudioStore.getState().addElement(id, projectId);
  window.dispatchEvent(new CustomEvent('xiaoxiao:unread-asset-category', { detail: { category: '视频', projectId, assetId: id } }));

  return {
   id,
   title,
   dataUrl: image.url,
   projectId,
   reused: false,
  };
 };
 const save = async () => {
  const video = playerRef.current;
  if (!video || !duration) {
   message.info('请等待视频画面加载完成');
   return;
  }
  setSaving(true);
  try {
   video.pause();
   const frameTime = video.currentTime;
   const saved = await ensureSavedFrameAsset(video, frameTime);
   const msgKey = `frame-save-${saved.id}`;
   message.success({
    key: msgKey,
    duration: 8,
    content: (
     <span className="inline-flex items-center gap-2">
      <span>已保存到资产库（视频）</span>
      <button
       type="button"
       style={{ WebkitAppRegion: 'no-drag', pointerEvents: 'auto', cursor: 'pointer' } as any}
       className="inline-flex cursor-pointer items-center rounded bg-primary/15 px-2 py-0.5 text-xs font-semibold text-primary transition hover:bg-primary/25 hover:underline"
       onClick={e => {
        e.stopPropagation();
        e.preventDefault();
        message.destroy(msgKey);
        navigateToAsset(saved.projectId, saved.id);
       }}
      >
       去查看
      </button>
     </span>
    ),
   });
  } catch (e) {
   message.error(e instanceof Error ? e.message : '截帧失败');
  } finally {
   setSaving(false);
  }
 };
 const captureToAgent = async () => {
  const video = playerRef.current;
  if (!video || !duration) {
   message.info('请等待视频画面加载完成');
   return;
  }
  setSendingAgent(true);
  try {
   video.pause();
   const frameTime = video.currentTime;
   const saved = await ensureSavedFrameAsset(video, frameTime);

   const framePayload = {
    id: saved.id,
    title: `${saved.title}.png`,
    kind: 'image',
    category: '视频截帧',
    dataUrl: saved.dataUrl,
    coverUrl: saved.dataUrl,
    data: { dataUrl: saved.dataUrl, url: saved.dataUrl },
    silent: true,
   };

   window.dispatchEvent(new CustomEvent('xiaoxiao:send-to-agent', {
    detail: { logId: log.id, attachAsset: framePayload }
   }));
   window.dispatchEvent(new CustomEvent('xiaoxiao:close-video-detail'));
   onClose();

   const msgKey = `frame-agent-${saved.id}`;
   message.success({
    key: msgKey,
    duration: 8,
    content: (
     <span className="inline-flex items-center gap-2">
      <span>已截取当前帧「{saved.title}」，已附带到 Agent 并存入资产库（视频）</span>
      <button
       type="button"
       style={{ WebkitAppRegion: 'no-drag', pointerEvents: 'auto', cursor: 'pointer' } as any}
       className="inline-flex cursor-pointer items-center rounded bg-primary/15 px-2 py-0.5 text-xs font-semibold text-primary transition hover:bg-primary/25 hover:underline"
       onClick={e => {
        e.stopPropagation();
        e.preventDefault();
        message.destroy(msgKey);
        navigateToAsset(saved.projectId, saved.id);
       }}
      >
       去查看
      </button>
     </span>
    ),
   });
  } catch (e) {
   message.error(e instanceof Error ? e.message : '截取发给 Agent 失败');
  } finally {
   setSendingAgent(false);
  }
 };
 return <section data-video-frame-capture tabIndex={0} aria-label="视频截帧控制" className="space-y-2 border-t border-border bg-background px-3.5 py-2.5 text-xs outline-none" onKeyDown={e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();seek(time+(e.key==='ArrowLeft'?-1:1)*(e.shiftKey?1:1/fps));}else if(e.key===' '){e.preventDefault();togglePlay();}}}>
  <div className="flex items-center gap-2.5">
   <button type="button" aria-label={playing?'暂停视频':'播放视频'} onClick={togglePlay} className="inline-flex size-7 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-sm transition hover:opacity-90">
    {playing?<Pause className="size-3.5"/>:<Play className="size-3.5 translate-x-[0.5px]"/>}
   </button>
   <input aria-label="截帧时间轴" type="range" disabled={saving||sendingAgent} className="h-1.5 flex-1 cursor-pointer accent-[var(--primary)]" min={0} max={duration||0.01} step={1/fps} value={Math.min(time,duration)} onChange={e=>seek(Number(e.target.value))}/>
   <span className="shrink-0 font-mono text-[11px] text-muted-foreground">{format(time)} / {format(duration)}</span>
   <button type="button" aria-label={muted?'取消静音':'静音'} onClick={toggleMute} className="inline-flex size-6 shrink-0 items-center justify-center rounded text-muted-foreground hover:bg-secondary hover:text-foreground">
    {muted?<VolumeX className="size-3.5"/>:<Volume2 className="size-3.5"/>}
   </button>
   <button type="button" aria-label="全屏播放" onClick={requestFull} className="inline-flex size-6 shrink-0 items-center justify-center rounded text-muted-foreground hover:bg-secondary hover:text-foreground">
    <Maximize2 className="size-3.5"/>
   </button>
  </div>
  <div className="flex flex-wrap items-center justify-between gap-2">
   <div className="flex flex-wrap items-center gap-1.5">
    <Button size="small" disabled={saving||sendingAgent} aria-label="后退1秒" onClick={()=>seek(time-1)}>−1秒</Button>
    <Button size="small" disabled={saving||sendingAgent} aria-label="上一帧" onClick={()=>seek(time-1/fps)}>上一帧</Button>
    <Button size="small" disabled={saving||sendingAgent} aria-label="下一帧" onClick={()=>seek(time+1/fps)}>下一帧</Button>
    <Button size="small" disabled={saving||sendingAgent} aria-label="前进1秒" onClick={()=>seek(time+1)}>+1秒</Button>
    <Button size="small" type="primary" icon={<Camera className="size-3.5"/>} loading={saving} onClick={()=>void save()}>保存到资产库</Button>
    <Button size="small" data-capture-to-agent icon={<Bot className="size-3.5"/>} loading={sendingAgent} onClick={()=>void captureToAgent()}>截取当前帧发给 Agent</Button>
   </div>
   <div className="flex items-center gap-2.5 text-[11px] text-muted-foreground">
    {metaText&&<span>{metaText}</span>}
    {onSpeedChange&&(
     <label className="flex items-center gap-1.5">
      <span>倍速</span>
      <select aria-label="视频详情播放速度" className="rounded border border-border bg-background px-1.5 py-0.5 text-xs text-foreground" value={speed} onChange={event=>onSpeedChange(Number(event.target.value))}>
       {[0.5,0.75,1,1.25,1.5,2].map(value=><option key={value} value={value}>{value}×</option>)}
      </select>
     </label>
    )}
   </div>
  </div>
 </section>;
}
