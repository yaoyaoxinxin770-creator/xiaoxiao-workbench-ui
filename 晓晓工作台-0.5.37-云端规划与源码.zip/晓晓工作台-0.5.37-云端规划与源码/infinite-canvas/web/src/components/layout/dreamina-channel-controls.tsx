"use client";
import {useCallback,useEffect,useRef,useState} from "react";
import {App,Button,Modal,Popover,Select} from "antd";
import {useConfigStore} from "@/stores/use-config-store";
import {workbench} from "@/services/api/workbench";
import {DreaminaAccountManager,type DreaminaAccountList} from "./dreamina-account-manager";
import {DreaminaCanvasManager,type CanvasTarget} from "./dreamina-canvas-manager";
import {useVideoStudioStore} from "@/stores/use-video-studio-store";
import {DreaminaDraftManager} from "./dreamina-draft-manager";
import {DreaminaLegacyAgentControls} from "./dreamina-legacy-agent-controls";
import {PippitVideoChannelDetails} from "./pippit-video-channel-details";
type Version="canvas"|"legacy";
type Status={logged_in:boolean;balance:number|null;accountId?:string};
export function DreaminaVideoChannel(){
 const projectKey=useVideoStudioStore(s=>s.activeProjectId);
 const [pippitOpen,setPippitOpen]=useState(false),[draftOpen,setDraftOpen]=useState(false),[canvasOpen,setCanvasOpen]=useState(false),[target,setTarget]=useState<CanvasTarget|null>(null);
 const {message,modal}=App.useApp(),config=useConfigStore(s=>s.config),provider=useConfigStore(s=>s.generationProvider),setProvider=useConfigStore(s=>s.setGenerationProvider),setCatalog=useConfigStore(s=>s.setDreaminaCatalog),update=useConfigStore(s=>s.updateConfig);
 const version=config.dreaminaVersion||"canvas",active=config.videoStudioProvider==="dreamina",profile=config.dreaminaAccountProfile||"default";
 const [accounts,setAccountState]=useState<DreaminaAccountList>({activeProfile:"default",accounts:[{profile:"default",name:"原有账号",category:"默认"}]}),[managerOpen,setManagerOpen]=useState(false),[switching,setSwitching]=useState(false);
 const setAccounts=useCallback((value:DreaminaAccountList)=>setAccountState(previous=>(value.revision||0)>=(previous.revision||0)?value:previous),[]);
 const [states,setStates]=useState<Record<string,{status?:Status;error?:string;loading?:boolean}>>({}),[statusOpen,setStatusOpen]=useState(false),[challenge,setChallenge]=useState<{url:string;code:string;version:Version;profile:string}|null>(null);
 const cache=useRef<Record<string,{statusAt:number;modelsAt:number}>>({}),pending=useRef<Record<string,Promise<void>|undefined>>({});
 const key=(v:Version,p:string)=>v==="legacy"?v:v+":"+p;
 const patch=(v:Version,p:string,value:Partial<{status:Status;error:string;loading:boolean}>)=>setStates(s=>({...s,[key(v,p)]:{...s[key(v,p)],...value}}));
 useEffect(()=>{let alive=true;workbench().dreaminaAccounts().then(value=>{if(!alive)return;setAccounts(value);update("dreaminaAccountProfile",value.activeProfile);}).catch(e=>message.error(e.message));return()=>{alive=false;};},[update,message]);
 const refresh=useCallback((v:Version,force=false,models=true,p=useConfigStore.getState().config.dreaminaAccountProfile||"default"):Promise<void>=>{
  const k=key(v,p),record=cache.current[k]||(cache.current[k]={statusAt:0,modelsAt:0});if(pending.current[k])return pending.current[k];
  const now=Date.now(),needStatus=force||now-record.statusAt>60000,needModels=models&&(force||now-record.modelsAt>300000);
  if(v==="canvas"&&workbench().dreaminaCanvasSettings){
   workbench().dreaminaCanvasSettings({profile:p,projectKey}).then(t=>{if(t)setTarget(t);}).catch(()=>{});
  }
  if(!needStatus&&!needModels)return Promise.resolve();
  patch(v,p,{error:"",loading:true});
  const request=(async()=>{try{await Promise.all([
   needModels?workbench().dreaminaModels(v,p).then(catalog=>{const c=useConfigStore.getState().config;if((c.dreaminaVersion||"canvas")===v&&(v==="legacy"||(c.dreaminaAccountProfile||"default")===p))setCatalog(catalog,v);record.modelsAt=Date.now();}):Promise.resolve(),
   needStatus?workbench().dreaminaStatus(v,p).then(result=>{patch(v,p,{status:result});record.statusAt=Date.now();if(v==="canvas")void workbench().dreaminaAccounts().then(setAccounts);}):Promise.resolve()
  ]);}catch(e){patch(v,p,{error:e instanceof Error?e.message:"即梦连接失败"});}finally{patch(v,p,{loading:false});delete pending.current[k];}})();pending.current[k]=request;return request;
 },[setCatalog,projectKey]);
 useEffect(()=>{if(!active)return;void refresh(version,false,true,profile);const changed=()=>void refresh(version,true,false,profile);window.addEventListener("dreamina-credits-changed",changed);return()=>window.removeEventListener("dreamina-credits-changed",changed);},[active,version,profile,refresh]);
 useEffect(()=>{if(!challenge)return;let running=false,cancelled=false;const timer=window.setInterval(async()=>{if(running)return;running=true;try{const s=await workbench().dreaminaCheckLogin(challenge.version,challenge.profile);if(!cancelled&&s.logged_in){patch(challenge.version,challenge.profile,{status:s,error:""});const k=key(challenge.version,challenge.profile);cache.current[k]={statusAt:Date.now(),modelsAt:0};setChallenge(null);if(challenge.version==="canvas")setAccounts(await workbench().dreaminaAccounts());void refresh(challenge.version,true,true,challenge.profile);message.success("即梦授权成功");}}catch(e){if(!cancelled)patch(challenge.version,challenge.profile,{error:e instanceof Error?e.message:"授权查询失败"});}finally{running=false;}},3000);return()=>{cancelled=true;window.clearInterval(timer);};},[challenge,message,refresh]);
 useEffect(()=>{const dialogs=new Map<{destroy:()=>void},()=>void>();const confirm=(event:Event)=>{const {task,resolve,prompt,projectKey:taskProjectKey,groupNumber}=(event as CustomEvent).detail;const state=useVideoStudioStore.getState(),matchedGroup=state.groups.find(g=>(!taskProjectKey||g.projectId===taskProjectKey)&&(prompt&&g.prompt?.trim()===String(prompt).trim()||groupNumber&&g.number===groupNumber));const badgeNumber=groupNumber||(matchedGroup?.number?String(matchedGroup.number).padStart(2,"0"):"");const badgeTitle=matchedGroup?.title&&matchedGroup.title!==matchedGroup.number?matchedGroup.title:"";const dialog=modal.confirm({title:"即梦新版生成确认",content:<div className="space-y-2">{badgeNumber&&<p className="flex items-center gap-1.5"><span>所属视频组：</span><span data-confirm-video-group={badgeNumber} data-confirm-video-group-body={badgeNumber} className="inline-flex items-center rounded-md px-2 py-0.5 font-mono text-xs font-bold" style={{background:"#ffc93c",color:"#1b1a17",border:"1.5px solid #1b1a17"}}>#{badgeNumber}{badgeTitle?` ${badgeTitle}`:""}</span></p>}{task.accountName&&<p>使用账号：{task.accountName}</p>}{task.canvasName&&<p>目标画布：{task.canvasName}</p>}<p>{task.model} · 1 个视频节点</p><p>本次最多消耗 {task.quote.credits} 积分。</p><a href={task.canvasUrl} target="_blank" rel="noopener noreferrer">查看已保存的画布草稿</a></div>,okText:"确认生成",cancelText:"取消",onOk:()=>{dialogs.delete(dialog);resolve(task.quote.credits);},onCancel:()=>{dialogs.delete(dialog);resolve(undefined);}});dialogs.set(dialog,()=>resolve(undefined));};window.addEventListener("dreamina-confirm-generation",confirm);return()=>{window.removeEventListener("dreamina-confirm-generation",confirm);for(const [dialog,cancel] of dialogs){cancel();dialog.destroy();}};},[modal]);
 const choose=(next:"dreamina"|"pippit"|"other")=>{setPippitOpen(next==="pippit"&&(!pippitOpen||active||provider!=="pippit"));setStatusOpen(next==="dreamina"&&(!active||!statusOpen));if(next==="dreamina"){if(!active)update("videoStudioProvider","dreamina");void refresh(version);}else{update("videoStudioProvider",undefined);setProvider(next);if(next==="other")useConfigStore.getState().openConfigDialog(false);}};
 const inspect=(event:React.MouseEvent,next:'dreamina'|'pippit'|'other')=>{event.preventDefault();setPippitOpen(next==='pippit');setStatusOpen(next==='dreamina');if(next==='dreamina')void refresh(version,false,false,profile);if(next==='other')window.dispatchEvent(new Event('workbench:inspect-other-settings'));};
 const login=async(p=profile,v=version)=>{patch(v,p,{loading:true});try{const result=await workbench().dreaminaLogin(v,p);if(result.logged_in){message.success("已复用即梦登录状态");void refresh(v,true,false,p);}else if(result.reused){patch(v,p,{status:{logged_in:false,balance:null},error:"旧版本地授权已复用，生成服务账号权限待确认"});message.warning("旧版生成服务未返回有效账号，请核对旧版账号权限。");}else setChallenge({url:result.url,code:result.code,version:v,profile:p});}catch(e){message.error(e instanceof Error?e.message:"即梦授权失败");}finally{patch(v,p,{loading:false});}};
 const select=async(p:string)=>{setSwitching(true);try{const value=await workbench().dreaminaAccountSelect(p);setAccounts(value);setCatalog({models:[],modelCapabilities:{},specs:{}},"canvas");update("dreaminaAccountProfile",p);update("dreaminaVersion","canvas");cache.current[key("canvas",p)]={statusAt:0,modelsAt:0};if(pending.current[key("canvas",p)])await pending.current[key("canvas",p)];await refresh("canvas",true,true,p);message.success("已切换即梦账号，后续任务使用新选择");}catch(e){message.error(e instanceof Error?e.message:"账号切换失败");throw e;}finally{setSwitching(false);}};
 const {status,error,loading}=states[key(version,profile)]||{};
 useEffect(()=>{
  if(version!=="canvas")setTarget(null);
 },[profile,projectKey,version]);
 useEffect(()=>{
  let alive=true;
  if(version==="canvas"&&(active||statusOpen)&&workbench().dreaminaCanvasSettings){
   void workbench().dreaminaCanvasSettings({profile,projectKey}).then(t=>{
    if(alive&&t)setTarget(t);
   }).catch(()=>{});
  }
  return()=>{alive=false;};
 },[profile,projectKey,version,active,statusOpen]);
 const [frameOpen,setFrameOpen]=useState(false),[frameStatus,setFrameStatus]=useState<{profile:string;accountName:string;enabled:boolean;loginWindowOpen:boolean}|null>(null),[frameBusy,setFrameBusy]=useState(false);
 const frameSettings=async()=>{setFrameOpen(true);setFrameBusy(true);try{setFrameStatus(await workbench().dreaminaInterpolationStatus({profile}));}catch(e){message.error(e instanceof Error?e.message:'官方补帧设置读取失败');}finally{setFrameBusy(false);}};
 const frameAction=async(action:'open'|'confirm')=>{if(!frameStatus)return;setFrameBusy(true);try{const p={profile:frameStatus.profile,projectKey,sameAccountConfirmed:true};setFrameStatus(await (action==='open'?workbench().dreaminaInterpolationOpen(p):workbench().dreaminaInterpolationConfirm(p)));if(action==='confirm')message.success('已启用官方后台补帧；待补帧视频会自动继续');}catch(e){message.error(e instanceof Error?e.message:'官方补帧设置失败');}finally{setFrameBusy(false);}};
 const groups=[...new Set(accounts.accounts.map(a=>a.category))];
 const details=<div className="w-80 space-y-3 text-sm"><div role="group" aria-label="即梦版本" className="inline-flex items-center gap-1">{([['canvas','新版'],['legacy','旧版']] as const).map(([v,label])=><button type="button" key={v} aria-pressed={version===v} className="rounded px-2 py-1 hover:bg-accent" style={{opacity:version===v?1:.5,fontWeight:version===v?600:400}} onClick={()=>{update("dreaminaVersion",v);setChallenge(null);void refresh(v);}}>{label}</button>)}</div>
  {version==="canvas"&&<div className="flex items-center gap-2"><Select aria-label="当前即梦账号" className="min-w-0 flex-1" value={profile} disabled={switching} options={groups.map(g=>({label:g,options:accounts.accounts.filter(a=>a.category===g).map(a=>({value:a.profile,label:a.name}))}))} onChange={p=>void select(p).catch(()=>{})}/><Button size="small" onClick={()=>{setStatusOpen(false);setManagerOpen(true);}}>账号管理</Button></div>}
  {version==="canvas"&&<div className="flex items-center gap-2"><span className="min-w-0 flex-1 truncate" title={target?.projectId}>{target?((target.locked?"已锁定：":"画布：")+(target.name||target.projectId)):"未指定画布"}</span><Button size="small" onClick={()=>{setStatusOpen(false);setCanvasOpen(true);}}>画布管理</Button></div>}
  {version==="canvas"&&<p className="text-xs text-muted-foreground">回传按提示词栏的补帧选择执行。不补帧直接回传；30 / 60 FPS 使用官方后台会话。</p>}
   {version==="canvas"&&<Button size="small" onClick={()=>{setStatusOpen(false);void frameSettings();}}>官方补帧设置</Button>}
   {version==="canvas"&&<Button size="small" onClick={()=>{setStatusOpen(false);setDraftOpen(true);}}>准备画布草稿</Button>}
  {version==="legacy"&&<><Select aria-label="即梦旧版创作方式" className="w-full" value={config.dreaminaLegacyMode||"direct"} onChange={value=>update("dreaminaLegacyMode",value)} options={[{value:"direct",label:"CLI 直接生成"},{value:"agent",label:"旧画布 Agent 模式"}]}/>{config.dreaminaLegacyMode==="agent"&&<DreaminaLegacyAgentControls/>}</>}
  <p role="status">{error||(status?.logged_in?status.balance===null?"已授权，余额暂不可用":"即梦余额 "+status.balance.toLocaleString():loading?"正在检查即梦…":"即梦账号状态未确认")}</p><div className="flex gap-2"><Button size="small" loading={loading} onClick={()=>void refresh(version,true)}>刷新</Button>{!status?.logged_in&&<Button size="small" loading={loading} onClick={()=>void login()}>检查授权</Button>}</div><p className="text-xs text-muted-foreground">{version==="canvas"?"新版：在协同画布中生成，提交前确认积分。":"旧版：使用旧 CLI 的模型和授权，暂不支持独立多账号。"}</p></div>;
 return <div data-testid="video-cli-channel" className="inline-flex items-center gap-2 text-xs" role="group" aria-label="视频生成渠道">
  {([['pippit','小云雀'],['dreamina','即梦 CLI'],['other','其他渠道']] as const).map(([key,label])=>{const button=<button type="button" aria-pressed={active?key==='dreamina':key===provider} className="px-1 py-1 transition hover:opacity-100" style={{color:"inherit",opacity:(active?key==='dreamina':key===provider)?1:.5,fontWeight:(active?key==='dreamina':key===provider)?600:400}} onContextMenu={event=>inspect(event,key)} title="左键切换渠道，右键仅查看设置" onClick={()=>choose(key)}>{label}</button>;return key==='dreamina'?<Popover key={key} open={statusOpen} onOpenChange={open=>{if(!open)setStatusOpen(false);}} trigger={[]} placement="bottom" content={details}>{button}</Popover>:key==='pippit'?<Popover key={key} open={pippitOpen} onOpenChange={open=>{if(!open)setPippitOpen(false);}} trigger={[]} placement="bottom" content={<PippitVideoChannelDetails onClose={()=>setPippitOpen(false)}/>}>{button}</Popover>:<span key={key} className="inline-flex">{button}</span>;})}
  <Modal title="官方后台补帧" open={frameOpen} onCancel={()=>setFrameOpen(false)} footer={null}><div className="space-y-3"><p>当前账号：{frameStatus?.accountName||'正在检查…'}</p><p>CLI 授权和网页登录彼此独立。请在独立官方窗口登录与此 CLI 相同的即梦账号，然后回到这里确认。</p><p>启用后，工作台会按各任务选择在隐藏网页中执行官方 30 / 60 FPS 补帧，并只回传补帧后的视频。不会操作你的鼠标或切换工作窗口。</p><p>该账号待补帧的视频也会自动继续；补帧是否成功以官网新产物为准。</p><p role="status">{frameStatus?.enabled?'已启用后台补帧':frameStatus?.loginWindowOpen?'网页登录窗口已打开，等待你完成登录并确认':'尚未启用；不会自动弹出登录窗口'}</p><div className="flex flex-wrap gap-2"><Button disabled={!frameStatus} loading={frameBusy} onClick={()=>void frameAction('open')}>打开官方网页登录</Button><Button type="primary" disabled={!frameStatus?.loginWindowOpen} loading={frameBusy} onClick={()=>void frameAction('confirm')}>我已登录同一账号，启用后台补帧</Button></div></div></Modal>
  <DreaminaDraftManager open={draftOpen} onClose={()=>setDraftOpen(false)} profile={profile}/>
  <DreaminaCanvasManager open={canvasOpen} onClose={()=>setCanvasOpen(false)} profile={profile} accountName={accounts.accounts.find(a=>a.profile===profile)?.name||profile} onChange={setTarget}/>
  <DreaminaAccountManager open={managerOpen} onClose={()=>setManagerOpen(false)} data={accounts} onChange={setAccounts} onSelect={select} onAuthorize={p=>login(p,"canvas")}/>
  <Modal title={challenge?.version==="legacy"?"即梦旧版授权":"即梦新版授权 · "+(accounts.accounts.find(a=>a.profile===challenge?.profile)?.name||"")} open={Boolean(challenge)} footer={null} onCancel={()=>setChallenge(null)}><p>打开官方授权页，验证码：<strong>{challenge?.code}</strong></p><a href={challenge?.url} target="_blank" rel="noopener noreferrer">打开即梦官方授权页</a><p className="mt-3 text-muted-foreground">请在官网选择本次要添加的账号。授权完成后会自动确认登录。</p></Modal>
 </div>;
}
